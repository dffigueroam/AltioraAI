// Datos simulados basados en el esquema de Prisma
const mockUsers = [
  {
    id: 1,
    email: "alice@example.com",
    name: "Alice",
    posts: [
      {
        id: 1,
        title: "Introducción a Prisma",
        content: "Prisma es un ORM moderno para Node.js y TypeScript",
        published: true,
        authorId: 1,
      },
      {
        id: 2,
        title: "Separando frontend y backend",
        content: "Es una buena práctica para mantener tu código organizado",
        published: true,
        authorId: 1,
      },
    ],
  },
  {
    id: 2,
    email: "bob@example.com",
    name: "Bob",
    posts: [
      {
        id: 3,
        title: "APIs simuladas",
        content: "Cómo crear endpoints simulados para desarrollo frontend",
        published: true,
        authorId: 2,
      },
    ],
  },
  {
    id: 3,
    email: "carol@example.com",
    name: "Carol",
    posts: [],
  },
]

// Función que simula una petición a la API
export async function mockFetchUsers() {
  // Simula un retraso de red
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Devuelve los datos simulados
  return mockUsers
}

// Función para obtener un usuario específico por ID
export async function mockFetchUserById(id: number) {
  await new Promise((resolve) => setTimeout(resolve, 500))

  const user = mockUsers.find((user) => user.id === id)

  if (!user) {
    throw new Error("Usuario no encontrado")
  }

  return user
}
