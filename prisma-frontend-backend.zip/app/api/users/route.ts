import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

// Inicializa Prisma Client
const prisma = new PrismaClient()

// Endpoint real que usa Prisma para obtener usuarios
export async function GET() {
  try {
    // Consulta a la base de datos usando Prisma
    const users = await prisma.user.findMany({
      include: {
        posts: true,
      },
    })

    return NextResponse.json(users)
  } catch (error) {
    console.error("Error fetching users:", error)
    return NextResponse.json({ error: "Error al obtener usuarios" }, { status: 500 })
  }
}
