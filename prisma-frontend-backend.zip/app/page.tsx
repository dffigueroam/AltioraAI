"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { mockFetchUsers } from "@/lib/mock-api"

// Tipo de datos basado en el esquema de Prisma
type User = {
  id: number
  email: string
  name: string | null
  posts?: Post[]
}

type Post = {
  id: number
  title: string
  content: string | null
  published: boolean
  authorId: number | null
}

export default function Home() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [useMock, setUseMock] = useState(true)

  useEffect(() => {
    async function fetchData() {
      setLoading(true)
      try {
        // Usa el API simulado o el real según el estado
        const data = useMock ? await mockFetchUsers() : await fetch("/api/users").then((res) => res.json())

        setUsers(data)
      } catch (error) {
        console.error("Error fetching users:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [useMock])

  return (
    <main className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Usuarios</h1>
        <Button onClick={() => setUseMock(!useMock)} variant={useMock ? "outline" : "default"}>
          {useMock ? "Usar API Real" : "Usar API Simulado"}
        </Button>
      </div>

      {loading ? (
        <p className="text-center py-10">Cargando usuarios...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map((user) => (
            <Card key={user.id}>
              <CardHeader>
                <CardTitle>{user.name || "Sin nombre"}</CardTitle>
                <CardDescription>{user.email}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {user.posts?.length ? `${user.posts.length} publicaciones` : "Sin publicaciones"}
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Ver detalles
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </main>
  )
}
