"use client"

import { useState, useCallback, useRef, useEffect } from "react"

interface ApiOptions {
  onSuccess?: (data: any) => void
  onError?: (error: Error) => void
  initialData?: any[]
}

export function useApi(endpoint: string, options: ApiOptions = {}) {
  // Inicializar con un array vacío o datos iniciales proporcionados
  const [data, setData] = useState<any[]>(options.initialData || [])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)

  // Usar useRef para evitar que las opciones cambien en cada renderizado
  const optionsRef = useRef(options)
  const endpointRef = useRef(endpoint)

  // Actualizar las referencias solo cuando cambian los valores
  useEffect(() => {
    optionsRef.current = options
    endpointRef.current = endpoint
  }, [options, endpoint])

  // Función para obtener todos los datos
  const fetchData = useCallback(async () => {
    if (isLoading) return // Evitar múltiples llamadas simultáneas

    setIsLoading(true)
    setError(null)

    try {
      // Simular datos para desarrollo si no hay API real
      if (process.env.NODE_ENV === "development" && !globalThis.fetch) {
        // Datos de ejemplo para desarrollo
        const mockData = getMockData(endpointRef.current)
        setData(mockData)
        setIsInitialized(true)
        optionsRef.current.onSuccess?.(mockData)
        return mockData
      }

      const response = await fetch(`/api/${endpointRef.current}`)
      if (!response.ok) {
        throw new Error(`Error al obtener datos: ${response.statusText}`)
      }

      const result = await response.json()
      setData(Array.isArray(result) ? result : [])
      setIsInitialized(true)
      optionsRef.current.onSuccess?.(result)
      return result
    } catch (err) {
      console.error("Error fetching data:", err)
      const error = err instanceof Error ? err : new Error(String(err))
      setError(error)
      optionsRef.current.onError?.(error)

      // En desarrollo, usar datos de ejemplo si hay un error
      if (process.env.NODE_ENV === "development") {
        const mockData = getMockData(endpointRef.current)
        setData(mockData)
        setIsInitialized(true)
        return mockData
      }

      throw error
    } finally {
      setIsLoading(false)
    }
  }, [isLoading]) // Added isLoading dependency

  // Función para obtener un elemento por ID
  const fetchItem = useCallback(
    async (id: string) => {
      if (isLoading) return

      setIsLoading(true)
      setError(null)

      try {
        const response = await fetch(`/api/${endpointRef.current}/${id}`)
        if (!response.ok) {
          throw new Error(`Error al obtener el elemento: ${response.statusText}`)
        }

        const result = await response.json()
        optionsRef.current.onSuccess?.(result)
        return result
      } catch (err) {
        console.error("Error fetching item:", err)
        const error = err instanceof Error ? err : new Error(String(err))
        setError(error)
        optionsRef.current.onError?.(error)
        throw error
      } finally {
        setIsLoading(false)
      }
    },
    [isLoading],
  ) // Added isLoading dependency

  // Función para crear un nuevo elemento
  const createItem = useCallback(
    async (itemData: any) => {
      if (isLoading) return

      setIsLoading(true)
      setError(null)

      try {
        // En desarrollo, simular la creación
        if (process.env.NODE_ENV === "development" && !globalThis.fetch) {
          const newItem = {
            id: Date.now().toString(),
            ...itemData,
            createdAt: new Date().toISOString(),
          }

          setData((prevData) => [...prevData, newItem])
          optionsRef.current.onSuccess?.(newItem)
          return newItem
        }

        const response = await fetch(`/api/${endpointRef.current}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(itemData),
        })

        if (!response.ok) {
          throw new Error(`Error al crear el elemento: ${response.statusText}`)
        }

        const result = await response.json()
        setData((prevData) => [...prevData, result])
        optionsRef.current.onSuccess?.(result)
        return result
      } catch (err) {
        console.error("Error creating item:", err)
        const error = err instanceof Error ? err : new Error(String(err))
        setError(error)
        optionsRef.current.onError?.(error)

        // En desarrollo, simular la creación incluso con error
        if (process.env.NODE_ENV === "development") {
          const newItem = {
            id: Date.now().toString(),
            ...itemData,
            createdAt: new Date().toISOString(),
          }

          setData((prevData) => [...prevData, newItem])
          return newItem
        }

        throw error
      } finally {
        setIsLoading(false)
      }
    },
    [isLoading],
  ) // Added isLoading dependency

  // Función para actualizar un elemento existente
  const updateItem = useCallback(
    async (id: string, itemData: any) => {
      if (isLoading) return

      setIsLoading(true)
      setError(null)

      try {
        const response = await fetch(`/api/${endpointRef.current}/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(itemData),
        })

        if (!response.ok) {
          throw new Error(`Error al actualizar el elemento: ${response.statusText}`)
        }

        const result = await response.json()
        setData((prevData) => prevData.map((item) => (item.id === id ? result : item)))
        optionsRef.current.onSuccess?.(result)
        return result
      } catch (err) {
        console.error("Error updating item:", err)
        const error = err instanceof Error ? err : new Error(String(err))
        setError(error)
        optionsRef.current.onError?.(error)
        throw error
      } finally {
        setIsLoading(false)
      }
    },
    [isLoading],
  ) // Added isLoading dependency

  // Función para eliminar un elemento
  const deleteItem = useCallback(
    async (id: string) => {
      if (isLoading) return

      setIsLoading(true)
      setError(null)

      try {
        const response = await fetch(`/api/${endpointRef.current}/${id}`, {
          method: "DELETE",
        })

        if (!response.ok) {
          throw new Error(`Error al eliminar el elemento: ${response.statusText}`)
        }

        setData((prevData) => prevData.filter((item) => item.id !== id))
        optionsRef.current.onSuccess?.({ id })
        return { success: true, id }
      } catch (err) {
        console.error("Error deleting item:", err)
        const error = err instanceof Error ? err : new Error(String(err))
        setError(error)
        optionsRef.current.onError?.(error)
        throw error
      } finally {
        setIsLoading(false)
      }
    },
    [isLoading],
  ) // Added isLoading dependency

  // Cargar datos iniciales si no se proporcionaron
  useEffect(() => {
    if (!isInitialized && !options.initialData) {
      fetchData().catch(console.error)
    }
  }, [fetchData, isInitialized, options.initialData])

  return {
    data,
    isLoading,
    error,
    isInitialized,
    fetchData,
    fetchItem,
    createItem,
    updateItem,
    deleteItem,
  }
}

// Función para obtener datos de ejemplo según el endpoint
function getMockData(endpoint: string) {
  switch (endpoint) {
    case "events":
      return [
        {
          id: "1",
          titulo: "Exposición de Ciencias",
          fecha: "2024-03-15",
          hora: "09:00",
          tipo: "academico",
          estado: "próximo",
          descripcion: "Presentación de proyectos científicos",
          lugar: "Auditorio Principal",
        },
        {
          id: "2",
          titulo: "Reunión de Padres",
          fecha: "2024-03-20",
          hora: "14:30",
          tipo: "administrativo",
          estado: "próximo",
          descripcion: "Entrega de informes del primer periodo",
          lugar: "Salón Múltiple",
        },
        {
          id: "3",
          titulo: "Torneo Interescolar de Fútbol",
          fecha: "2024-03-18",
          hora: "15:00",
          tipo: "competencia",
          estado: "próximo",
          descripcion: "Partido semifinal contra Colegio San José",
          lugar: "Campo Deportivo Principal",
          categoria: "Sub-15",
          deporte: "Fútbol",
        },
        {
          id: "4",
          titulo: "Pruebas de Rendimiento Físico",
          fecha: "2024-03-25",
          hora: "10:00",
          tipo: "evaluacion",
          estado: "próximo",
          descripcion: "Evaluación trimestral de capacidades físicas",
          lugar: "Gimnasio",
          categoria: "General",
          deporte: "Múltiple",
        },
        {
          id: "5",
          titulo: "Competencia de Natación",
          fecha: "2024-04-05",
          hora: "09:00",
          tipo: "competencia",
          estado: "programado",
          descripcion: "Campeonato regional de natación",
          lugar: "Piscina Olímpica Municipal",
          categoria: "Juvenil",
          deporte: "Natación",
        },
      ]
    default:
      return []
  }
}

