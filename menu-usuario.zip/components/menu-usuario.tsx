"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  BookOpen,
  Brain,
  Calendar,
  GraduationCap,
  Heart,
  Home,
  MessageSquare,
  Settings,
  Users,
  ChevronDown,
  Trophy,
  CheckIcon as Exam,
  CalendarIcon as Meeting,
  Music,
  Shield,
  Book,
  FileText,
  Ruler,
  Activity,
  Award,
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

type UserRole = "estudiante" | "profesor" | "padre" | "directivo"

const menuItems = {
  estudiante: [
    { icon: Home, label: "Inicio", href: "/dashboard" },
    { icon: BookOpen, label: "Mis Cursos", href: "/dashboard/cursos" },
    { icon: Brain, label: "Evaluaciones", href: "/dashboard/evaluaciones" },
    {
      icon: Calendar,
      label: "Eventos",
      submenu: [
        { icon: Calendar, label: "Calendario Académico", href: "/dashboard/eventos/academico" },
        { icon: Music, label: "Eventos Culturales", href: "/dashboard/eventos/culturales" },
        { icon: Trophy, label: "Eventos Deportivos", href: "/dashboard/eventos/deportivos" },
        { icon: Exam, label: "Exámenes Programados", href: "/dashboard/eventos/examenes" },
        { icon: Meeting, label: "Reuniones", href: "/dashboard/eventos/reuniones" },
      ],
    },
    { icon: Heart, label: "Bienestar", href: "/dashboard/bienestar" },
    {
      icon: Trophy,
      label: "Formación Deportiva",
      submenu: [
        { icon: Users, label: "Mi Club Deportivo", href: "/dashboard/deportes/club" },
        { icon: Ruler, label: "Medidas Físicas", href: "/dashboard/deportes/medidas" },
        { icon: Activity, label: "Tests Físicos", href: "/dashboard/deportes/tests" },
        { icon: Award, label: "Récords de Juego", href: "/dashboard/deportes/records" },
        { icon: Calendar, label: "Calendario Deportivo", href: "/dashboard/deportes/calendario" },
      ],
    },
    { icon: MessageSquare, label: "Mensajes", href: "/dashboard/mensajes" },
  ],
  profesor: [
    { icon: Home, label: "Inicio", href: "/dashboard" },
    { icon: Users, label: "Mis Estudiantes", href: "/dashboard/estudiantes" },
    { icon: BookOpen, label: "Cursos", href: "/dashboard/cursos" },
    { icon: BarChart3, label: "Análisis", href: "/dashboard/analisis" },
    {
      icon: Calendar,
      label: "Eventos",
      submenu: [
        { icon: Users, label: "Reuniones de Profesores", href: "/dashboard/eventos/reuniones-profesores" },
        { icon: Shield, label: "Eventos de Capacitación", href: "/dashboard/eventos/capacitacion" },
        { icon: Calendar, label: "Calendario Académico", href: "/dashboard/eventos/academico" },
        { icon: Music, label: "Eventos Culturales", href: "/dashboard/eventos/culturales" },
        { icon: Trophy, label: "Eventos Deportivos", href: "/dashboard/eventos/deportivos" },
      ],
    },
  ],
  padre: [
    { icon: Home, label: "Inicio", href: "/dashboard" },
    { icon: GraduationCap, label: "Progreso Académico", href: "/dashboard/progreso" },
    { icon: Heart, label: "Bienestar Emocional", href: "/dashboard/bienestar" },
    { icon: MessageSquare, label: "Comunicaciones", href: "/dashboard/comunicaciones" },
    {
      icon: Calendar,
      label: "Eventos",
      submenu: [
        { icon: Users, label: "Reuniones de Padres", href: "/dashboard/eventos/reuniones-padres" },
        { icon: Book, label: "Entrega de Notas", href: "/dashboard/eventos/entrega-notas" },
        { icon: Calendar, label: "Calendario Académico", href: "/dashboard/eventos/academico" },
        { icon: Music, label: "Eventos Culturales", href: "/dashboard/eventos/culturales" },
        { icon: Trophy, label: "Eventos Deportivos", href: "/dashboard/eventos/deportivos" },
      ],
    },
  ],
  directivo: [
    { icon: Home, label: "Dashboard", href: "/dashboard" },
    { icon: BarChart3, label: "Estadísticas", href: "/dashboard/estadisticas" },
    { icon: Users, label: "Gestión de Usuarios", href: "/dashboard/usuarios" },
    { icon: Settings, label: "Configuración", href: "/dashboard/configuracion" },
    {
      icon: Calendar,
      label: "Eventos",
      submenu: [
        { icon: Calendar, label: "Eventos Institucionales", href: "/dashboard/eventos/institucional" },
        { icon: Users, label: "Reuniones Directivas", href: "/dashboard/eventos/reuniones-directivas" },
        { icon: Shield, label: "Eventos de Capacitación", href: "/dashboard/eventos/capacitacion" },
        { icon: Book, label: "Eventos Académicos", href: "/dashboard/eventos/academicos" },
        { icon: FileText, label: "Actos Administrativos", href: "/dashboard/eventos/administrativos" },
      ],
    },
  ],
}

export function MenuUsuario() {
  const [role, setRole] = useState<UserRole>("estudiante")
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null)

  const toggleSubmenu = (label: string) => {
    setOpenSubmenu(openSubmenu === label ? null : label)
  }

  return (
    <div className="flex h-screen">
      <div className="w-64 bg-gray-100 p-4">
        <div className="mb-4">
          <select
            className="w-full p-2 border rounded"
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
          >
            <option value="estudiante">Estudiante</option>
            <option value="profesor">Profesor</option>
            <option value="padre">Padre</option>
            <option value="directivo">Directivo</option>
          </select>
        </div>
        <nav>
          <ul className="space-y-1">
            {menuItems[role].map((item, index) => (
              <li key={index}>
                {"submenu" in item ? (
                  <div className="space-y-1">
                    <Button
                      variant="ghost"
                      className={cn(
                        "w-full justify-between",
                        openSubmenu === item.label && "bg-accent text-accent-foreground",
                      )}
                      onClick={() => toggleSubmenu(item.label)}
                    >
                      <span className="flex items-center">
                        <item.icon className="mr-2 h-4 w-4" />
                        {item.label}
                      </span>
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 transition-transform duration-200",
                          openSubmenu === item.label ? "rotate-180" : "",
                        )}
                      />
                    </Button>
                    <div
                      className={cn(
                        "overflow-hidden transition-all duration-200 ease-in-out",
                        openSubmenu === item.label ? "max-h-96" : "max-h-0",
                      )}
                    >
                      <ul className="space-y-1 pl-6">
                        {item.submenu.map((subItem, subIndex) => (
                          <li key={subIndex}>
                            <Button asChild variant="ghost" className="w-full justify-start h-9">
                              <Link href={subItem.href}>
                                <subItem.icon className="mr-2 h-4 w-4" />
                                {subItem.label}
                              </Link>
                            </Button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <Button asChild variant="ghost" className="w-full justify-start">
                    <Link href={item.href}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Link>
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="flex-1 p-4">
        <h1 className="text-2xl font-bold mb-4">Contenido Principal</h1>
        <p>El contenido de la página se mostrará aquí según la selección del menú.</p>
      </div>
    </div>
  )
}

