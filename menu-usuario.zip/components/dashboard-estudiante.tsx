"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Heart, ThumbsUp, ThumbsDown } from "lucide-react"

export function DashboardEstudiante() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [sentimiento, setSentimiento] = useState<"positivo" | "neutral" | "negativo">("neutral")
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")

  // Ejemplos de entradas para mostrar
  const ejemplos = [
    "Hoy tuve un día con muchas cosas por hacer y necesité ayuda.",
    "Hoy tuve un altercado con mi papá.",
    "Siento que no he dormido lo suficiente.",
    "Me fue muy bien en el examen de matemáticas.",
    "Estoy preocupado por el proyecto grupal.",
  ]

  const handleGuardarEntrada = () => {
    alert("Entrada guardada: " + titulo)
    setTitulo("")
    setContenido("")
    setSentimiento("neutral")
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <div className="w-16 h-16 bg-gray-200 rounded-full mr-4"></div>
        <div>
          <h1 className="text-2xl font-bold">Bienvenida, Ana García</h1>
          <p className="text-gray-500">Estudiante</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium text-gray-500">Mis Cursos</h3>
            <p className="text-2xl font-bold">5 activos</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium text-gray-500">Estado de Conducta</h3>
            <p className="text-2xl font-bold">Excelente</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium text-gray-500">Plan de Mejoramiento</h3>
            <p className="text-2xl font-bold">80% completado</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium text-gray-500">Nivel de Estrés</h3>
            <p className="text-2xl font-bold">Bajo</p>
          </CardContent>
        </Card>
      </div>

      {/* Diario De Emociones - Siempre visible */}
      <div className="mt-8 mb-16">
        <h2 className="text-2xl font-bold mb-4">Diario De Emociones</h2>
        <Card className="mb-4">
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="titulo">Título de tu entrada</Label>
              <Input
                id="titulo"
                placeholder="Resume en una frase cómo te sientes"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contenido">Cuéntanos más</Label>
              <Textarea
                id="contenido"
                placeholder="Describe cómo te sientes, qué ha pasado hoy o cualquier cosa que quieras compartir..."
                value={contenido}
                onChange={(e) => setContenido(e.target.value)}
                rows={6}
              />

              {!contenido && (
                <div className="mt-2">
                  <p className="text-sm text-muted-foreground mb-2">Ejemplos:</p>
                  <div className="flex flex-wrap gap-2">
                    {ejemplos.map((ejemplo, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setContenido(ejemplo)}
                        className="text-xs"
                      >
                        {ejemplo}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>¿Cómo te hace sentir?</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={sentimiento === "positivo" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setSentimiento("positivo")}
                >
                  <ThumbsUp className="h-4 w-4 mr-2" />
                  Bien
                </Button>
                <Button
                  type="button"
                  variant={sentimiento === "neutral" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setSentimiento("neutral")}
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Neutral
                </Button>
                <Button
                  type="button"
                  variant={sentimiento === "negativo" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => setSentimiento("negativo")}
                >
                  <ThumbsDown className="h-4 w-4 mr-2" />
                  Mal
                </Button>
              </div>
            </div>

            <Button onClick={handleGuardarEntrada} disabled={!contenido || !titulo} className="w-full">
              Guardar en mi diario
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Barra de navegación inferior */}
      <div className="bg-gray-100 border-t fixed bottom-0 left-0 right-0 z-10">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex overflow-x-auto">
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-gray-600">
              Acciones Pendientes
            </button>
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-gray-600">Eventos</button>
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-gray-600">
              Enlaces de Interés
            </button>
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-gray-600">Deportes</button>
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-blue-600 border-t-2 border-blue-600">
              Diario De Emociones
            </button>
            <button className="flex-1 py-3 px-2 text-sm text-center whitespace-nowrap text-gray-600">
              Gestión sugerida de la IA
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

