"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, ArrowDown, ArrowUp, Clock, Edit, MessageSquare, UserPlus } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface EstudianteEstadoEmocional {
  id: string
  nombre: string
  estado: string
  fecha: string
  recomendacion: string
  tipo: "urgente" | "seguimiento" | "normal"
  asignado?: string
  notas?: string[]
}

const estudiantesIniciales: EstudianteEstadoEmocional[] = [
  {
    id: "est1",
    nombre: "Ana García",
    estado: "Estrés Pre-Evento",
    fecha: "24/2/2024",
    recomendacion: "Programar una reunión con el estudiante y el departamento de orientación.",
    tipo: "urgente",
    asignado: "",
    notas: [],
  },
  {
    id: "est2",
    nombre: "Carlos Rodríguez",
    estado: "Ansiedad Pre-Evento",
    fecha: "23/2/2024",
    recomendacion: "Hacer seguimiento del progreso en las próximas semanas.",
    tipo: "seguimiento",
    asignado: "",
    notas: [],
  },
  {
    id: "est3",
    nombre: "María López",
    estado: "Estilo de Aprendizaje",
    fecha: "22/2/2024",
    recomendacion: "",
    tipo: "normal",
    asignado: "",
    notas: [],
  },
]

export function EstadoEmocionalAlumnos() {
  const [estudiantes, setEstudiantes] = useState<EstudianteEstadoEmocional[]>(estudiantesIniciales)
  const [estudianteSeleccionado, setEstudianteSeleccionado] = useState<EstudianteEstadoEmocional | null>(null)
  const [dialogoGestionAbierto, setDialogoGestionAbierto] = useState(false)
  const [dialogoReasignarAbierto, setDialogoReasignarAbierto] = useState(false)
  const [dialogoNotasAbierto, setDialogoNotasAbierto] = useState(false)
  const [nuevaNota, setNuevaNota] = useState("")
  const [nuevoEstado, setNuevoEstado] = useState<"urgente" | "seguimiento" | "normal">("urgente")
  const [nuevoAsignado, setNuevoAsignado] = useState("")

  const urgentes = estudiantes.filter((e) => e.tipo === "urgente").length
  const seguimiento = estudiantes.filter((e) => e.tipo === "seguimiento").length

  // Función para abrir el diálogo de gestión
  const abrirGestion = (estudiante: EstudianteEstadoEmocional) => {
    setEstudianteSeleccionado(estudiante)
    setNuevoEstado(estudiante.tipo)
    setDialogoGestionAbierto(true)
  }

  // Función para abrir el diálogo de reasignación
  const abrirReasignar = (estudiante: EstudianteEstadoEmocional) => {
    setEstudianteSeleccionado(estudiante)
    setNuevoAsignado(estudiante.asignado || "")
    setDialogoReasignarAbierto(true)
  }

  // Función para abrir el diálogo de notas
  const abrirNotas = (estudiante: EstudianteEstadoEmocional) => {
    setEstudianteSeleccionado(estudiante)
    setNuevaNota("")
    setDialogoNotasAbierto(true)
  }

  // Función para actualizar el estado de un estudiante
  const actualizarEstado = () => {
    if (!estudianteSeleccionado) return

    const estudiantesActualizados = estudiantes.map((est) => {
      if (est.id === estudianteSeleccionado.id) {
        return {
          ...est,
          tipo: nuevoEstado,
        }
      }
      return est
    })

    setEstudiantes(estudiantesActualizados)
    setDialogoGestionAbierto(false)
  }

  // Función para reasignar un estudiante
  const reasignarEstudiante = () => {
    if (!estudianteSeleccionado) return

    const estudiantesActualizados = estudiantes.map((est) => {
      if (est.id === estudianteSeleccionado.id) {
        return {
          ...est,
          asignado: nuevoAsignado,
        }
      }
      return est
    })

    setEstudiantes(estudiantesActualizados)
    setDialogoReasignarAbierto(false)
  }

  // Función para agregar una nota
  const agregarNota = () => {
    if (!estudianteSeleccionado || !nuevaNota.trim()) return

    const fechaActual = new Date().toLocaleDateString()
    const notaCompleta = `[${fechaActual}] ${nuevaNota}`

    const estudiantesActualizados = estudiantes.map((est) => {
      if (est.id === estudianteSeleccionado.id) {
        return {
          ...est,
          notas: [...(est.notas || []), notaCompleta],
        }
      }
      return est
    })

    setEstudiantes(estudiantesActualizados)
    setNuevaNota("")
    setDialogoNotasAbierto(false)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-blue-700">Acciones Pendientes</h1>
        <p className="text-gray-600">
          Estudiantes que requieren atención especial basada en su estado emocional y académico
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl text-blue-700">Estado Emocional Alumnos - 3A</CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Resultados recientes de evaluaciones emocionales y estilos de aprendizaje
              </p>
            </div>
            <div className="flex gap-2">
              <Badge variant="destructive">{urgentes} Urgentes</Badge>
              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                {seguimiento} Atención
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {estudiantes.map((estudiante) => (
            <div
              key={estudiante.id}
              className={`p-4 rounded-lg ${
                estudiante.tipo === "urgente"
                  ? "bg-red-50"
                  : estudiante.tipo === "seguimiento"
                    ? "bg-yellow-50"
                    : "bg-green-50"
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {estudiante.tipo === "urgente" && <AlertTriangle className="h-5 w-5 text-red-500" />}
                    <h3 className="font-semibold">{estudiante.nombre}</h3>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span>{estudiante.estado}</span>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{estudiante.fecha}</span>
                    </div>
                  </div>
                  {estudiante.recomendacion && (
                    <p className="text-sm mt-2">
                      <span className="font-medium">Recomendación:</span> {estudiante.recomendacion}
                    </p>
                  )}
                  {estudiante.asignado && (
                    <p className="text-sm mt-1">
                      <span className="font-medium">Asignado a:</span>{" "}
                      {estudiante.asignado === "profesor"
                        ? "Profesor (Tú)"
                        : estudiante.asignado === "psicologo"
                          ? "Psicólogo/a"
                          : estudiante.asignado === "orientador"
                            ? "Orientador/a"
                            : "Sin asignar"}
                    </p>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div>
                    {estudiante.tipo === "urgente" && (
                      <Badge variant="destructive" className="flex items-center gap-1">
                        <ArrowDown className="h-4 w-4" />
                        Requiere atención inmediata
                      </Badge>
                    )}
                    {estudiante.tipo === "seguimiento" && (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        <Clock className="h-4 w-4 mr-1" />
                        Necesita seguimiento
                      </Badge>
                    )}
                    {estudiante.tipo === "normal" && (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        <ArrowUp className="h-4 w-4 mr-1" />
                        Estado normal
                      </Badge>
                    )}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => abrirGestion(estudiante)}
                    >
                      <Edit className="h-4 w-4" />
                      <span className="hidden sm:inline">Gestionar</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => abrirReasignar(estudiante)}
                    >
                      <UserPlus className="h-4 w-4" />
                      <span className="hidden sm:inline">Reasignar</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                      onClick={() => abrirNotas(estudiante)}
                    >
                      <MessageSquare className="h-4 w-4" />
                      <span className="hidden sm:inline">Notas</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ayúdanos a Mejorar</CardTitle>
          <p className="text-sm text-gray-600">
            Como educador, tu opinión es fundamental. Comparte tu experiencia con la plataforma.
          </p>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            Calificar la Plataforma
          </Button>
        </CardContent>
      </Card>

      {/* Diálogo para gestionar estado */}
      <Dialog open={dialogoGestionAbierto} onOpenChange={setDialogoGestionAbierto}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Gestionar Estado Emocional</DialogTitle>
            <DialogDescription>Actualiza el estado emocional del estudiante según tu evaluación.</DialogDescription>
          </DialogHeader>
          {estudianteSeleccionado && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">Estudiante: {estudianteSeleccionado.nombre}</h3>
                <p className="text-sm text-gray-500">Estado actual: {estudianteSeleccionado.estado}</p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Actualizar nivel de atención</label>
                <Select value={nuevoEstado} onValueChange={(value) => setNuevoEstado(value as any)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="urgente">Requiere atención inmediata</SelectItem>
                    <SelectItem value="seguimiento">Necesita seguimiento</SelectItem>
                    <SelectItem value="normal">Estado normal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogoGestionAbierto(false)}>
              Cancelar
            </Button>
            <Button onClick={actualizarEstado}>Guardar cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para reasignar */}
      <Dialog open={dialogoReasignarAbierto} onOpenChange={setDialogoReasignarAbierto}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reasignar Estudiante</DialogTitle>
            <DialogDescription>Asigna el seguimiento del estudiante a ti mismo o a otro profesional.</DialogDescription>
          </DialogHeader>
          {estudianteSeleccionado && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">Estudiante: {estudianteSeleccionado.nombre}</h3>
                <p className="text-sm text-gray-500">
                  Actualmente asignado a:{" "}
                  {estudianteSeleccionado.asignado === "profesor"
                    ? "Profesor (Tú)"
                    : estudianteSeleccionado.asignado === "psicologo"
                      ? "Psicólogo/a"
                      : estudianteSeleccionado.asignado === "orientador"
                        ? "Orientador/a"
                        : "Sin asignar"}
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Asignar a</label>
                <Select value={nuevoAsignado} onValueChange={setNuevoAsignado}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un responsable" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="profesor">Profesor (Tú)</SelectItem>
                    <SelectItem value="psicologo">Psicólogo/a</SelectItem>
                    <SelectItem value="orientador">Orientador/a</SelectItem>
                    <SelectItem value="">Sin asignar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogoReasignarAbierto(false)}>
              Cancelar
            </Button>
            <Button onClick={reasignarEstudiante}>Asignar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para notas */}
      <Dialog open={dialogoNotasAbierto} onOpenChange={setDialogoNotasAbierto}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Notas de Seguimiento</DialogTitle>
            <DialogDescription>Revisa y agrega notas sobre el progreso del estudiante.</DialogDescription>
          </DialogHeader>
          {estudianteSeleccionado && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">Estudiante: {estudianteSeleccionado.nombre}</h3>
                <p className="text-sm text-gray-500">Estado: {estudianteSeleccionado.estado}</p>
              </div>

              <Tabs defaultValue="historial">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="historial">Historial de Notas</TabsTrigger>
                  <TabsTrigger value="agregar">Agregar Nota</TabsTrigger>
                </TabsList>
                <TabsContent value="historial" className="space-y-4 mt-4">
                  {estudianteSeleccionado.notas && estudianteSeleccionado.notas.length > 0 ? (
                    <div className="space-y-3">
                      {estudianteSeleccionado.notas.map((nota, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-md">
                          <p className="text-sm">{nota}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No hay notas de seguimiento registradas.</p>
                  )}
                </TabsContent>
                <TabsContent value="agregar" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Nueva nota</label>
                    <textarea
                      className="w-full min-h-[100px] p-3 border rounded-md"
                      placeholder="Escribe una nota sobre el progreso o estado del estudiante..."
                      value={nuevaNota}
                      onChange={(e) => setNuevaNota(e.target.value)}
                    ></textarea>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogoNotasAbierto(false)}>
              Cancelar
            </Button>
            <Button onClick={agregarNota}>Guardar Nota</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

