"use client"

import React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Bug, Clock, FileWarning, RotateCcw, Search, Shield, UserX } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { AdminLog, SystemReport } from "@/types/admin"

// Datos de ejemplo
const mockLogs: AdminLog[] = [
  {
    id: "1",
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutos atrás
    action: "delete",
    userId: "prof123",
    userRole: "profesor",
    description: "Eliminación de clase de matemáticas del grupo 10A",
    status: "pending",
    priority: "high",
    affectedArea: "classes",
    details: {
      previousState: {
        className: "Matemáticas 10A",
        date: "2024-02-26",
        teacher: "Juan Pérez",
      },
      reason: "Solicitud del profesor por error en la programación",
    },
  },
  {
    id: "2",
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hora atrás
    action: "reassign",
    userId: "dir456",
    userRole: "directivo",
    description: "Reasignación de profesor de Física",
    status: "resolved",
    priority: "medium",
    affectedArea: "teachers",
    details: {
      previousState: { teacher: "María Rodríguez", group: "11B" },
      newState: { teacher: "Carlos López", group: "11B" },
      reason: "Licencia médica del profesor original",
    },
  },
]

const mockReports: SystemReport[] = [
  {
    id: "1",
    reportedBy: {
      id: "user123",
      name: "Ana García",
      role: "profesor",
    },
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    category: "bug",
    title: "Error al cargar calificaciones",
    description: "El sistema muestra error 500 al intentar cargar las calificaciones del grupo 9B",
    status: "open",
    priority: "high",
    attachments: ["error-screenshot.png"],
  },
  {
    id: "2",
    reportedBy: {
      id: "user456",
      name: "Carlos Martínez",
      role: "directivo",
    },
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    category: "security",
    title: "Acceso no autorizado detectado",
    description: "Se detectaron intentos de acceso inusuales desde una IP desconocida",
    status: "in_progress",
    priority: "critical",
    assignedTo: "admin",
  },
]

// Placeholder component for IncidentsManager
const IncidentsManager = () => {
  return <div>Incidents Manager Content</div>
}

export function AdminDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterPriority, setFilterPriority] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")

  const getStatusColor = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      resolved: "bg-green-100 text-green-800",
      in_progress: "bg-blue-100 text-blue-800",
      open: "bg-purple-100 text-purple-800",
      closed: "bg-gray-100 text-gray-800",
    }
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getPriorityColor = (priority: string) => {
    const colors = {
      low: "bg-blue-100 text-blue-800",
      medium: "bg-yellow-100 text-yellow-800",
      high: "bg-orange-100 text-orange-800",
      critical: "bg-red-100 text-red-800",
    }
    return colors[priority as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getActionIcon = (action: string) => {
    const icons = {
      delete: UserX,
      modify: FileWarning,
      reassign: RotateCcw,
      report: AlertTriangle,
    }
    return icons[action as keyof typeof icons] || AlertTriangle
  }

  const getCategoryIcon = (category: string) => {
    const icons = {
      bug: Bug,
      security: Shield,
      performance: Clock,
      feature: FileWarning,
      other: AlertTriangle,
    }
    return icons[category as keyof typeof icons] || AlertTriangle
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("es", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const filteredLogs = mockLogs.filter((log) => {
    const matchesSearch =
      log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userId.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPriority = filterPriority === "all" || log.priority === filterPriority
    const matchesStatus = filterStatus === "all" || log.status === filterStatus
    return matchesSearch && matchesPriority && matchesStatus
  })

  const filteredReports = mockReports.filter((report) => {
    const matchesSearch =
      report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPriority = filterPriority === "all" || report.priority === filterPriority
    const matchesStatus = filterStatus === "all" || report.status === filterStatus
    return matchesSearch && matchesPriority && matchesStatus
  })

  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-[#1E40AF]">Panel de Administración</CardTitle>
          <CardDescription>Gestión de incidencias, reportes y cambios del sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 space-y-4">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <Input
                  placeholder="Buscar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                  prefix={<Search className="h-4 w-4 text-gray-400" />}
                />
              </div>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Filtrar por prioridad" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las prioridades</SelectItem>
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="critical">Crítica</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Filtrar por estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="in_progress">En progreso</SelectItem>
                  <SelectItem value="resolved">Resuelto</SelectItem>
                  <SelectItem value="closed">Cerrado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="logs" className="space-y-4">
            <TabsList>
              <TabsTrigger value="logs">Registro de Cambios</TabsTrigger>
              <TabsTrigger value="reports">Reportes del Sistema</TabsTrigger>
              <TabsTrigger value="incidents">Incidencias</TabsTrigger>
            </TabsList>

            <TabsContent value="logs">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Acción</TableHead>
                    <TableHead>Usuario</TableHead>
                    <TableHead>Descripción</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Prioridad</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="whitespace-nowrap">{formatDate(log.timestamp)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {React.createElement(getActionIcon(log.action), { className: "h-4 w-4" })}
                          <span className="capitalize">{log.action}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{log.userId}</span>
                          <span className="text-sm text-gray-500">{log.userRole}</span>
                        </div>
                      </TableCell>
                      <TableCell>{log.description}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(log.status)}>{log.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getPriorityColor(log.priority)}>{log.priority}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">
                          Ver detalles
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="reports">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Categoría</TableHead>
                    <TableHead>Reportado por</TableHead>
                    <TableHead>Título</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Prioridad</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell className="whitespace-nowrap">{formatDate(report.timestamp)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {React.createElement(getCategoryIcon(report.category), {
                            className: "h-4 w-4",
                          })}
                          <span className="capitalize">{report.category}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{report.reportedBy.name}</span>
                          <span className="text-sm text-gray-500">{report.reportedBy.role}</span>
                        </div>
                      </TableCell>
                      <TableCell>{report.title}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getPriorityColor(report.priority)}>{report.priority}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">
                          Ver detalles
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="incidents">
              <IncidentsManager />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

