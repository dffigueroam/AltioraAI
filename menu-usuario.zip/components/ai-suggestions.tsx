"use client"

import { useState } from "react"
import type { AISuggestion } from "@/services/ai-suggestions"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight, AlertTriangle, Clock, Lightbulb } from "lucide-react"
import Link from "next/link"

interface AISuggestionsProps {
  suggestions: AISuggestion[]
  title?: string
  description?: string
}

export function AISuggestions({
  suggestions,
  title = "Gestión sugerida por IA",
  description = "Recomendaciones personalizadas basadas en análisis de datos",
}: AISuggestionsProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id)
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "alta":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "media":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200"
      case "baja":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "alta":
        return <AlertTriangle className="h-4 w-4 mr-1" />
      case "media":
        return <Clock className="h-4 w-4 mr-1" />
      case "baja":
        return <Lightbulb className="h-4 w-4 mr-1" />
      default:
        return null
    }
  }

  const formatDate = (date: Date) => {
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return "Hoy"
    } else if (diffDays === 1) {
      return "Ayer"
    } else {
      return `Hace ${diffDays} días`
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
          <p className="text-muted-foreground">{description}</p>
        </div>
      </div>

      {suggestions.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">No hay sugerencias disponibles en este momento.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
          {suggestions.map((suggestion) => (
            <Card
              key={suggestion.id}
              className={`cursor-pointer transition-all duration-200 ${expandedId === suggestion.id ? "border-primary" : ""}`}
              onClick={() => toggleExpand(suggestion.id)}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{suggestion.title}</CardTitle>
                  <Badge className={`${getPriorityColor(suggestion.priority)} flex items-center`}>
                    {getPriorityIcon(suggestion.priority)}
                    Prioridad {suggestion.priority}
                  </Badge>
                </div>
                <CardDescription className="flex justify-between">
                  <span>{suggestion.category}</span>
                  <span>{formatDate(suggestion.createdAt)}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className={`text-sm ${expandedId === suggestion.id ? "" : "line-clamp-2"}`}>
                  {suggestion.description}
                </p>
              </CardContent>
              {expandedId === suggestion.id && (
                <CardFooter className="pt-0">
                  <Button asChild variant="outline" className="w-full mt-2">
                    <Link href={suggestion.actionLink}>
                      <span className="flex items-center justify-center">
                        {suggestion.actionText}
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </span>
                    </Link>
                  </Button>
                </CardFooter>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

