"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Search, AlertCircle, BookOpen, ChevronDown } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Tipos de datos
interface Materia {
  id: string
  nombre: string
  profesor: string
  promedio: number
}

interface Alumno {
  id: string
  nombre: string
  estadoEmocional: "bueno" | "regular" | "malo"
  materiasPerdidas: Materia[]
  asistencia: number
}

// Datos de ejemplo
const alumnosEjemplo: Alumno[] = [
  {
    id: "1",
    nombre: "Ana García",
    estadoEmocional: "bueno",
    materiasPerdidas: [],
    asistencia: 95,
  },
  {
    id: "2",
    nombre: "Carlos Rodríguez",
    estadoEmocional: "regular",
    materiasPerdidas: [
      { id: "m1", nombre: "Matemáticas", profesor: "Javier Méndez", promedio: 2.8 },
      { id: "m2", nombre: "Física", profesor: "Laura Sánchez", promedio: 2.5 },
    ],
    asistencia: 85,
  },
  {
    id: "3",
    nombre: "María López",
    estadoEmocional: "malo",
    materiasPerdidas: [
      { id: "m1", nombre: "Matemáticas", profesor: "Javier Méndez", promedio: 2.9 },
      { id: "m3", nombre: "Química", profesor: "Pedro Ramírez", promedio: 2.7 },
      { id: "m4", nombre: "Historia", profesor: "Carmen Jiménez", promedio: 2.4 },
    ],
    asistencia: 70,
  },
  {
    id: "4",
    nombre: "Juan Martínez",
    estadoEmocional: "bueno",
    materiasPerdidas: [{ id: "m2", nombre: "Física", profesor: "Laura Sánchez", promedio: 2.6 }],
    asistencia: 90,
  },
  {
    id: "5",
    nombre: "Sofía Hernández",
    estadoEmocional: "regular",
    materiasPerdidas: [],
    asistencia: 88,
  },
]

export function TableroGrupo() {
  const [alumnos, setAlumnos] = useState<Alumno[]>(alumnosEjemplo)
  const [busqueda, setBusqueda] = useState("")
  const [alumnoSeleccionado, setAlumnoSeleccionado] = useState<Alumno | null>(null)
  const [mostrarMateriasPerdidas, setMostrarMateriasPerdidas] = useState(false)

  // Filtrar alumnos por búsqueda
  const alumnosFiltrados = alumnos.filter(
    (alumno) =>
      alumno.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      alumno.materiasPerdidas.some((materia) => materia.nombre.toLowerCase().includes(busqueda.toLowerCase())),
  )

  // Obtener color según estado emocional
  const getColorEstadoEmocional = (estado: string) => {
    switch (estado) {
      case "bueno":
        return "bg-green-100 text-green-800"
      case "regular":
        return "bg-yellow-100 text-yellow-800"
      case "malo":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Obtener texto según estado emocional
  const getTextoEstadoEmocional = (estado: string) => {
    switch (estado) {
      case "bueno":
        return "Bueno"
      case "regular":
        return "Regular"
      case "malo":
        return "Necesita atención"
      default:
        return "Desconocido"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tablero de Grupo - 10A</CardTitle>
          <CardDescription>Visualización general del estado de los alumnos del grupo</CardDescription>
          <div className="relative mt-2">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar alumno o materia..."
              className="pl-8"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Estado Emocional</TableHead>
                <TableHead>Materias Perdidas</TableHead>
                <TableHead>Asistencia</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {alumnosFiltrados.map((alumno) => (
                <TableRow key={alumno.id}>
                  <TableCell className="font-medium">{alumno.nombre}</TableCell>
                  <TableCell>
                    <Badge className={getColorEstadoEmocional(alumno.estadoEmocional)}>
                      {getTextoEstadoEmocional(alumno.estadoEmocional)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {alumno.materiasPerdidas.length > 0 ? (
                      <div className="flex items-center gap-2">
                        <Badge variant="destructive">
                          {alumno.materiasPerdidas.length}{" "}
                          {alumno.materiasPerdidas.length === 1 ? "materia" : "materias"}
                        </Badge>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => setAlumnoSeleccionado(alumno)}
                            >
                              <ChevronDown className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-md">
                            <DialogHeader>
                              <DialogTitle>Materias perdidas - {alumno.nombre}</DialogTitle>
                              <DialogDescription>Detalle de las materias con promedio insuficiente</DialogDescription>
                            </DialogHeader>
                            <div className="max-h-[60vh] overflow-auto">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Materia</TableHead>
                                    <TableHead>Profesor</TableHead>
                                    <TableHead>Promedio</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {alumno.materiasPerdidas.map((materia) => (
                                    <TableRow key={materia.id}>
                                      <TableCell className="font-medium">{materia.nombre}</TableCell>
                                      <TableCell>{materia.profesor}</TableCell>
                                      <TableCell className="text-red-600 font-semibold">
                                        {materia.promedio.toFixed(1)}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <DialogFooter>
                              <Button type="button" variant="outline" onClick={() => {}}>
                                Crear caso de seguimiento
                              </Button>
                              <Button type="button">Contactar acudiente</Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                    ) : (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Al día
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={alumno.asistencia < 80 ? "destructive" : "outline"}
                      className={
                        alumno.asistencia >= 90
                          ? "bg-green-50 text-green-700 border-green-200"
                          : alumno.asistencia >= 80
                            ? "bg-yellow-50 text-yellow-700 border-yellow-200"
                            : "bg-red-50 text-red-700 border-red-200"
                      }
                    >
                      {alumno.asistencia}%
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          Acciones
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {}}>
                          <AlertCircle className="mr-2 h-4 w-4" />
                          Crear caso
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {}}>
                          <BookOpen className="mr-2 h-4 w-4" />
                          Ver desempeño
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Componente para mostrar estadísticas generales del grupo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Estado Emocional</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-2xl font-bold">{alumnos.filter((a) => a.estadoEmocional === "bueno").length}</p>
                <p className="text-xs text-muted-foreground">Alumnos en buen estado</p>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{alumnos.filter((a) => a.estadoEmocional === "malo").length}</p>
                <p className="text-xs text-muted-foreground">Necesitan atención</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Rendimiento Académico</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-2xl font-bold">{alumnos.filter((a) => a.materiasPerdidas.length === 0).length}</p>
                <p className="text-xs text-muted-foreground">Alumnos al día</p>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{alumnos.filter((a) => a.materiasPerdidas.length > 0).length}</p>
                <p className="text-xs text-muted-foreground">Con materias perdidas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Asistencia</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-2xl font-bold">
                  {Math.round(alumnos.reduce((acc, alumno) => acc + alumno.asistencia, 0) / alumnos.length)}%
                </p>
                <p className="text-xs text-muted-foreground">Promedio del grupo</p>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{alumnos.filter((a) => a.asistencia < 80).length}</p>
                <p className="text-xs text-muted-foreground">Asistencia crítica</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

