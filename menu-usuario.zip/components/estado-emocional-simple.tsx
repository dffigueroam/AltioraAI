"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, ArrowDown, ArrowUp, Clock, Heart, UserPlus, CheckCircle, MessageSquare } from "lucide-react"

interface EstudianteEstadoEmocional {
  id: string
  nombre: string
  estado: string
  fecha: string
  recomendacion: string
  tipo: "urgente" | "seguimiento" | "normal"
  asignado?: string
  notas?: string[]
}

const estudiantesIniciales: EstudianteEstadoEmocional[] = [
  {
    id: "est1",
    nombre: "Ana García",
    estado: "Estrés Pre-Evento",
    fecha: "24/2/2024",
    recomendacion: "Programar una reunión con el estudiante y el departamento de orientación.",
    tipo: "urgente",
    asignado: "",
    notas: [],
  },
  {
    id: "est2",
    nombre: "Carlos Rodríguez",
    estado: "Ansiedad Pre-Evento",
    fecha: "23/2/2024",
    recomendacion: "Hacer seguimiento del progreso en las próximas semanas.",
    tipo: "seguimiento",
    asignado: "",
    notas: [],
  },
  {
    id: "est3",
    nombre: "María López",
    estado: "Estilo de Aprendizaje",
    fecha: "22/2/2024",
    recomendacion: "",
    tipo: "normal",
    asignado: "",
    notas: [],
  },
]

export function EstadoEmocionalSimple() {
  const [estudiantes, setEstudiantes] = useState<EstudianteEstadoEmocional[]>(estudiantesIniciales)

  const urgentes = estudiantes.filter((e) => e.tipo === "urgente").length
  const seguimiento = estudiantes.filter((e) => e.tipo === "seguimiento").length

  // Asignar al profesor
  const asignarProfesor = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, asignado: "profesor" } : est)))
  }

  // Asignar al psicólogo
  const asignarPsicologo = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, asignado: "psicologo" } : est)))
  }

  // Marcar como atendido
  const marcarAtendido = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, tipo: "normal" } : est)))
  }

  // Agregar nota
  const agregarNota = (id: string) => {
    const estudiante = estudiantes.find((est) => est.id === id)
    if (!estudiante) return

    const nota = prompt(`Añadir nota para ${estudiante.nombre}:`)
    if (!nota) return

    const fechaActual = new Date().toLocaleDateString()
    const notaCompleta = `[${fechaActual}] ${nota}`

    setEstudiantes((prev) =>
      prev.map((est) => (est.id === id ? { ...est, notas: [...(est.notas || []), notaCompleta] } : est)),
    )
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-blue-700">Acciones Pendientes</h1>
        <p className="text-gray-600">
          Estudiantes que requieren atención especial basada en su estado emocional y académico
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl text-blue-700">Estado Emocional Alumnos - 3A</CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Resultados recientes de evaluaciones emocionales y estilos de aprendizaje
              </p>
            </div>
            <div className="flex gap-2">
              <Badge variant="destructive">{urgentes} Urgentes</Badge>
              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                {seguimiento} Atención
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {estudiantes.map((estudiante) => (
            <div
              key={estudiante.id}
              className={`p-4 rounded-lg ${
                estudiante.tipo === "urgente"
                  ? "bg-red-50"
                  : estudiante.tipo === "seguimiento"
                    ? "bg-yellow-50"
                    : "bg-green-50"
              }`}
            >
              <div className="flex flex-col gap-3">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      {estudiante.tipo === "urgente" && <AlertTriangle className="h-5 w-5 text-red-500" />}
                      <h3 className="font-semibold">{estudiante.nombre}</h3>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <span>{estudiante.estado}</span>
                      <span>•</span>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{estudiante.fecha}</span>
                      </div>
                    </div>
                    {estudiante.recomendacion && (
                      <p className="text-sm mt-2">
                        <span className="font-medium">Recomendación:</span> {estudiante.recomendacion}
                      </p>
                    )}
                    {estudiante.asignado && (
                      <p className="text-sm mt-1">
                        <span className="font-medium">Asignado a:</span>{" "}
                        {estudiante.asignado === "profesor"
                          ? "Profesor (Tú)"
                          : estudiante.asignado === "psicologo"
                            ? "Psicólogo/a"
                            : "Sin asignar"}
                      </p>
                    )}
                  </div>
                  <div>
                    {estudiante.tipo === "urgente" && (
                      <Badge variant="destructive" className="flex items-center gap-1">
                        <ArrowDown className="h-4 w-4" />
                        Requiere atención inmediata
                      </Badge>
                    )}
                    {estudiante.tipo === "seguimiento" && (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        <Clock className="h-4 w-4 mr-1" />
                        Necesita seguimiento
                      </Badge>
                    )}
                    {estudiante.tipo === "normal" && (
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                        <ArrowUp className="h-4 w-4 mr-1" />
                        Estado normal
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Notas */}
                {estudiante.notas && estudiante.notas.length > 0 && (
                  <div className="mt-2 p-3 bg-white rounded-md border border-gray-100">
                    <h4 className="text-sm font-medium mb-2">Notas de seguimiento:</h4>
                    <div className="space-y-2">
                      {estudiante.notas.map((nota, index) => (
                        <p key={index} className="text-sm text-gray-600">
                          {nota}
                        </p>
                      ))}
                    </div>
                  </div>
                )}

                {/* Acciones */}
                {(estudiante.tipo === "urgente" || estudiante.tipo === "seguimiento") && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {!estudiante.asignado && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-blue-50"
                          onClick={() => asignarProfesor(estudiante.id)}
                        >
                          <Heart className="mr-2 h-4 w-4 text-blue-600" />
                          Atender yo mismo
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => asignarPsicologo(estudiante.id)}>
                          <UserPlus className="mr-2 h-4 w-4" />
                          Derivar a psicólogo
                        </Button>
                      </>
                    )}

                    {estudiante.asignado === "profesor" && (
                      <>
                        <Button variant="outline" size="sm" onClick={() => agregarNota(estudiante.id)}>
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Añadir nota
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-green-50"
                          onClick={() => marcarAtendido(estudiante.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Marcar como atendido
                        </Button>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ayúdanos a Mejorar</CardTitle>
          <p className="text-sm text-gray-600">
            Como educador, tu opinión es fundamental. Comparte tu experiencia con la plataforma.
          </p>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            Calificar la Plataforma
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

