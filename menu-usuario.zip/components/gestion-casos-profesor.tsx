"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { AlertCircle, BookOpen, Calendar, CheckCircle, Clock, FileText, Filter, Plus, Search, User } from "lucide-react"

// Tipos para las materias perdidas
interface MateriaPerdida {
  nombre: string
  promedio: number
  profesor: string
}

// Tipos para los casos
interface Caso {
  id: string
  estudiante: string
  curso: string
  tipo: "emocional" | "académico" | "conductual" | "familiar" | "salud"
  prioridad: "alta" | "media" | "baja"
  estado: "abierto" | "seguimiento" | "derivado" | "cerrado"
  fechaCreacion: string
  descripcion: string
  materiasPerdidas: MateriaPerdida[]
}

// Datos de ejemplo
const casosDePrueba: Caso[] = [
  {
    id: "1",
    estudiante: "Ana García",
    curso: "10°A",
    tipo: "académico",
    prioridad: "alta",
    estado: "abierto",
    fechaCreacion: "2023-05-15",
    descripcion: "Bajo rendimiento académico en múltiples materias. Requiere plan de acción inmediato.",
    materiasPerdidas: [
      { nombre: "Matemáticas", promedio: 2.8, profesor: "Carlos Ramírez" },
      { nombre: "Física", promedio: 2.5, profesor: "Laura Mendoza" },
      { nombre: "Química", promedio: 2.9, profesor: "Javier López" },
    ],
  },
  {
    id: "2",
    estudiante: "Miguel Rodríguez",
    curso: "9°B",
    tipo: "emocional",
    prioridad: "media",
    estado: "seguimiento",
    fechaCreacion: "2023-05-10",
    descripcion: "Muestra signos de ansiedad. Se ha contactado a los padres.",
    materiasPerdidas: [{ nombre: "Historia", promedio: 2.9, profesor: "Patricia Gómez" }],
  },
  {
    id: "3",
    estudiante: "Sofía Martínez",
    curso: "11°A",
    tipo: "conductual",
    prioridad: "baja",
    estado: "derivado",
    fechaCreacion: "2023-05-08",
    descripcion: "Problemas de conducta en clase. Derivado a psicología.",
    materiasPerdidas: [],
  },
  {
    id: "4",
    estudiante: "Carlos López",
    curso: "10°B",
    tipo: "académico",
    prioridad: "alta",
    estado: "abierto",
    fechaCreacion: "2023-05-14",
    descripcion: "Riesgo de pérdida del año escolar. Requiere intervención urgente.",
    materiasPerdidas: [
      { nombre: "Matemáticas", promedio: 2.3, profesor: "Carlos Ramírez" },
      { nombre: "Física", promedio: 2.1, profesor: "Laura Mendoza" },
      { nombre: "Química", promedio: 2.4, profesor: "Javier López" },
      { nombre: "Inglés", promedio: 2.7, profesor: "María Sánchez" },
    ],
  },
  {
    id: "5",
    estudiante: "Laura Gómez",
    curso: "9°A",
    tipo: "familiar",
    prioridad: "media",
    estado: "seguimiento",
    fechaCreacion: "2023-05-09",
    descripcion: "Situación familiar compleja afectando rendimiento. En seguimiento con trabajo social.",
    materiasPerdidas: [
      { nombre: "Lenguaje", promedio: 2.8, profesor: "Elena Vargas" },
      { nombre: "Ciencias Sociales", promedio: 2.9, profesor: "Roberto Díaz" },
    ],
  },
]

export function GestionCasosProfesor() {
  const [casos, setCasos] = useState<Caso[]>(casosDePrueba)
  const [filtroTipo, setFiltroTipo] = useState<string>("todos")
  const [filtroEstado, setFiltroEstado] = useState<string>("todos")
  const [filtroPrioridad, setFiltroPrioridad] = useState<string>("todos")
  const [busqueda, setBusqueda] = useState<string>("")
  const [casoSeleccionado, setCasoSeleccionado] = useState<Caso | null>(null)
  const [dialogoDetalle, setDialogoDetalle] = useState<boolean>(false)

  // Filtrar casos según los criterios seleccionados
  const casosFiltrados = casos.filter((caso) => {
    return (
      (filtroTipo === "todos" || caso.tipo === filtroTipo) &&
      (filtroEstado === "todos" || caso.estado === filtroEstado) &&
      (filtroPrioridad === "todos" || caso.prioridad === filtroPrioridad) &&
      (busqueda === "" ||
        caso.estudiante.toLowerCase().includes(busqueda.toLowerCase()) ||
        caso.curso.toLowerCase().includes(busqueda.toLowerCase()) ||
        caso.descripcion.toLowerCase().includes(busqueda.toLowerCase()) ||
        caso.materiasPerdidas.some((materia) => materia.nombre.toLowerCase().includes(busqueda.toLowerCase())))
    )
  })

  // Estadísticas de casos
  const estadisticas = {
    total: casos.length,
    abiertos: casos.filter((caso) => caso.estado === "abierto").length,
    seguimiento: casos.filter((caso) => caso.estado === "seguimiento").length,
    derivados: casos.filter((caso) => caso.estado === "derivado").length,
    cerrados: casos.filter((caso) => caso.estado === "cerrado").length,
    prioridadAlta: casos.filter((caso) => caso.prioridad === "alta").length,
  }

  // Función para mostrar detalles de un caso
  const verDetalleCaso = (caso: Caso) => {
    setCasoSeleccionado(caso)
    setDialogoDetalle(true)
  }

  // Función para obtener el color de la badge según la prioridad
  const getColorPrioridad = (prioridad: string) => {
    switch (prioridad) {
      case "alta":
        return "bg-red-500"
      case "media":
        return "bg-yellow-500"
      case "baja":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  // Función para obtener el color de la badge según el estado
  const getColorEstado = (estado: string) => {
    switch (estado) {
      case "abierto":
        return "bg-blue-500"
      case "seguimiento":
        return "bg-purple-500"
      case "derivado":
        return "bg-orange-500"
      case "cerrado":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Gestión de Casos</CardTitle>
          <CardDescription>
            Administre y haga seguimiento a los casos de estudiantes que requieren atención especial
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="todos">
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="todos">Todos los Casos</TabsTrigger>
                <TabsTrigger value="academicos">Académicos</TabsTrigger>
                <TabsTrigger value="emocionales">Emocionales</TabsTrigger>
                <TabsTrigger value="conductuales">Conductuales</TabsTrigger>
              </TabsList>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Nuevo Caso
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <p className="text-sm font-medium text-gray-500">Total Casos</p>
                  <p className="text-3xl font-bold">{estadisticas.total}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <p className="text-sm font-medium text-gray-500">Abiertos</p>
                  <p className="text-3xl font-bold">{estadisticas.abiertos}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <p className="text-sm font-medium text-gray-500">En Seguimiento</p>
                  <p className="text-3xl font-bold">{estadisticas.seguimiento}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <p className="text-sm font-medium text-gray-500">Derivados</p>
                  <p className="text-3xl font-bold">{estadisticas.derivados}</p>
                </CardContent>
              </Card>
              <Card className="bg-red-50">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <p className="text-sm font-medium text-gray-500">Prioridad Alta</p>
                  <p className="text-3xl font-bold text-red-600">{estadisticas.prioridadAlta}</p>
                </CardContent>
              </Card>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar por estudiante, curso o descripción..."
                  className="pl-8"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Select value={filtroTipo} onValueChange={setFiltroTipo}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos los tipos</SelectItem>
                    <SelectItem value="emocional">Emocional</SelectItem>
                    <SelectItem value="académico">Académico</SelectItem>
                    <SelectItem value="conductual">Conductual</SelectItem>
                    <SelectItem value="familiar">Familiar</SelectItem>
                    <SelectItem value="salud">Salud</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filtroEstado} onValueChange={setFiltroEstado}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos los estados</SelectItem>
                    <SelectItem value="abierto">Abierto</SelectItem>
                    <SelectItem value="seguimiento">En seguimiento</SelectItem>
                    <SelectItem value="derivado">Derivado</SelectItem>
                    <SelectItem value="cerrado">Cerrado</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filtroPrioridad} onValueChange={setFiltroPrioridad}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Prioridad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todas</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="media">Media</SelectItem>
                    <SelectItem value="baja">Baja</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsContent value="todos">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Curso</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Prioridad</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Materias Perdidas</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {casosFiltrados.length > 0 ? (
                    casosFiltrados.map((caso) => (
                      <TableRow key={caso.id}>
                        <TableCell className="font-medium">{caso.estudiante}</TableCell>
                        <TableCell>{caso.curso}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {caso.tipo}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getColorPrioridad(caso.prioridad)} text-white capitalize`}>
                            {caso.prioridad}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getColorEstado(caso.estado)} text-white capitalize`}>
                            {caso.estado}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {caso.materiasPerdidas.length > 0 ? (
                            <Badge variant="outline" className="bg-red-50 text-red-700">
                              {caso.materiasPerdidas.length}{" "}
                              {caso.materiasPerdidas.length === 1 ? "materia" : "materias"}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              Ninguna
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{caso.fechaCreacion}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => verDetalleCaso(caso)}>
                            Ver detalles
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-4">
                        No se encontraron casos que coincidan con los filtros seleccionados.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="academicos">
              <Table>
                {/* Similar a la tabla anterior pero filtrada por tipo académico */}
                <TableHeader>
                  <TableRow>
                    <TableHead>Estudiante</TableHead>
                    <TableHead>Curso</TableHead>
                    <TableHead>Prioridad</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Materias Perdidas</TableHead>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {casosFiltrados
                    .filter((caso) => caso.tipo === "académico")
                    .map((caso) => (
                      <TableRow key={caso.id}>
                        <TableCell className="font-medium">{caso.estudiante}</TableCell>
                        <TableCell>{caso.curso}</TableCell>
                        <TableCell>
                          <Badge className={`${getColorPrioridad(caso.prioridad)} text-white capitalize`}>
                            {caso.prioridad}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getColorEstado(caso.estado)} text-white capitalize`}>
                            {caso.estado}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {caso.materiasPerdidas.length > 0 ? (
                            <Badge variant="outline" className="bg-red-50 text-red-700">
                              {caso.materiasPerdidas.length}{" "}
                              {caso.materiasPerdidas.length === 1 ? "materia" : "materias"}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              Ninguna
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{caso.fechaCreacion}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => verDetalleCaso(caso)}>
                            Ver detalles
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TabsContent>

            {/* Contenido similar para las otras pestañas */}
          </Tabs>
        </CardContent>
      </Card>

      {/* Diálogo de detalle de caso */}
      <Dialog open={dialogoDetalle} onOpenChange={setDialogoDetalle}>
        <DialogContent className="max-w-4xl">
          {casoSeleccionado && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center">
                  <User className="mr-2 h-5 w-5" />
                  Caso de {casoSeleccionado.estudiante} - {casoSeleccionado.curso}
                </DialogTitle>
                <DialogDescription>Creado el {casoSeleccionado.fechaCreacion}</DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center">
                  <Badge className={`${getColorPrioridad(casoSeleccionado.prioridad)} text-white capitalize mr-2`}>
                    {casoSeleccionado.prioridad}
                  </Badge>
                  <span className="text-sm">Prioridad</span>
                </div>
                <div className="flex items-center">
                  <Badge className={`${getColorEstado(casoSeleccionado.estado)} text-white capitalize mr-2`}>
                    {casoSeleccionado.estado}
                  </Badge>
                  <span className="text-sm">Estado</span>
                </div>
                <div className="flex items-center">
                  <Badge variant="outline" className="capitalize mr-2">
                    {casoSeleccionado.tipo}
                  </Badge>
                  <span className="text-sm">Tipo de caso</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2 flex items-center">
                    <FileText className="mr-2 h-4 w-4" /> Descripción del caso
                  </h3>
                  <p className="text-sm bg-gray-50 p-3 rounded-md">{casoSeleccionado.descripcion}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2 flex items-center">
                    <BookOpen className="mr-2 h-4 w-4" /> Materias Perdidas
                  </h3>
                  {casoSeleccionado.materiasPerdidas.length > 0 ? (
                    <div className="bg-gray-50 p-3 rounded-md">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Materia</TableHead>
                            <TableHead>Promedio</TableHead>
                            <TableHead>Profesor</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {casoSeleccionado.materiasPerdidas.map((materia, index) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{materia.nombre}</TableCell>
                              <TableCell className="text-red-600 font-medium">{materia.promedio.toFixed(1)}</TableCell>
                              <TableCell>{materia.profesor}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-sm bg-gray-50 p-3 rounded-md">
                      El estudiante no está perdiendo ninguna materia actualmente.
                    </p>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2 flex items-center">
                    <Clock className="mr-2 h-4 w-4" /> Historial de seguimiento
                  </h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="space-y-3">
                      <div className="border-l-2 border-blue-500 pl-3">
                        <p className="text-xs text-gray-500">15/05/2023 - Profesor Javier Martínez</p>
                        <p className="text-sm">Se abre caso por bajo rendimiento académico en múltiples materias.</p>
                      </div>
                      <div className="border-l-2 border-blue-500 pl-3">
                        <p className="text-xs text-gray-500">17/05/2023 - Profesor Javier Martínez</p>
                        <p className="text-sm">Se contacta a los padres para programar reunión.</p>
                      </div>
                      <div className="border-l-2 border-blue-500 pl-3">
                        <p className="text-xs text-gray-500">20/05/2023 - Profesor Javier Martínez</p>
                        <p className="text-sm">Reunión con padres. Se acuerda plan de refuerzo académico.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2 flex items-center">
                    <Calendar className="mr-2 h-4 w-4" /> Acciones planificadas
                  </h3>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <p className="text-sm">Reunión con padres - Completada el 20/05/2023</p>
                      </div>
                      <div className="flex items-center">
                        <AlertCircle className="h-4 w-4 text-yellow-500 mr-2" />
                        <p className="text-sm">Evaluación de progreso - Pendiente para el 05/06/2023</p>
                      </div>
                      <div className="flex items-center">
                        <AlertCircle className="h-4 w-4 text-yellow-500 mr-2" />
                        <p className="text-sm">Reunión de seguimiento con padres - Pendiente para el 10/06/2023</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <DialogFooter className="flex justify-between items-center">
                <div>
                  <Select>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Cambiar estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="abierto">Abierto</SelectItem>
                      <SelectItem value="seguimiento">En seguimiento</SelectItem>
                      <SelectItem value="derivado">Derivar a psicología</SelectItem>
                      <SelectItem value="cerrado">Cerrar caso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Button variant="outline" className="mr-2">
                    Añadir nota
                  </Button>
                  <Button>Programar acción</Button>
                </div>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

