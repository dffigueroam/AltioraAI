"use client"

import { useState } from "react"
import type { Psychologist } from "@/types/psychologist"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Mail, Phone, MapPin, Award } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface PerfilPsicologoProps {
  psychologist: Psychologist
  editable?: boolean
}

export function PerfilPsicologo({ psychologist, editable = false }: PerfilPsicologoProps) {
  const [isEditing, setIsEditing] = useState(false)

  const specialtyLabels = {
    clinical: "Psicología Clínica",
    educational: "Psicología Educativa",
    developmental: "Psicología del Desarrollo",
    counseling: "Orientación Psicológica",
  }

  const handleSaveChanges = () => {
    // Aquí iría la lógica para guardar los cambios
    setIsEditing(false)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={`/placeholder.svg?height=64&width=64`} alt={psychologist.name} />
                <AvatarFallback>
                  {psychologist.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-2xl">{psychologist.name}</CardTitle>
                <CardDescription className="text-lg">
                  <Badge variant="outline" className="mr-2">
                    {specialtyLabels[psychologist.specialty]}
                  </Badge>
                  Psicólogo Escolar
                </CardDescription>
              </div>
            </div>
            {editable && (
              <Button variant="outline" onClick={() => setIsEditing(!isEditing)}>
                {isEditing ? "Cancelar" : "Editar Perfil"}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="info">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="info">Información</TabsTrigger>
              <TabsTrigger value="schedule">Horario</TabsTrigger>
              <TabsTrigger value="qualifications">Cualificaciones</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 pt-4">
              {isEditing ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo Electrónico</Label>
                      <Input id="email" defaultValue={psychologist.contactInfo.email} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input id="phone" defaultValue={psychologist.contactInfo.phone} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="office">Oficina</Label>
                    <Input id="office" defaultValue={psychologist.contactInfo.office} />
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 mr-2 text-muted-foreground" />
                    <span>{psychologist.contactInfo.email}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 mr-2 text-muted-foreground" />
                    <span>{psychologist.contactInfo.phone}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2 text-muted-foreground" />
                    <span>{psychologist.contactInfo.office}</span>
                  </div>
                </div>
              )}

              <div className="pt-2">
                <h3 className="text-lg font-medium mb-2">Grados Asignados</h3>
                <div className="flex flex-wrap gap-2">
                  {psychologist.assignedGrades.map((grade) => (
                    <Badge key={grade} variant="secondary">
                      {grade}
                    </Badge>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="schedule" className="space-y-4 pt-4">
              <div className="space-y-3">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-muted-foreground" />
                  <span>Días de atención: {psychologist.availability.days.join(", ")}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-muted-foreground" />
                  <span>Horario: {psychologist.availability.hours}</span>
                </div>
              </div>

              {isEditing && (
                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <Label htmlFor="days">Días de Atención</Label>
                    <Input id="days" defaultValue={psychologist.availability.days.join(", ")} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hours">Horario</Label>
                    <Input id="hours" defaultValue={psychologist.availability.hours} />
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="qualifications" className="space-y-4 pt-4">
              <div className="space-y-3">
                <h3 className="text-lg font-medium mb-2">Certificaciones</h3>
                <div className="space-y-2">
                  {psychologist.certifications.map((cert, index) => (
                    <div key={index} className="flex items-center">
                      <Award className="h-5 w-5 mr-2 text-muted-foreground" />
                      <span>{cert}</span>
                    </div>
                  ))}
                </div>
              </div>

              {isEditing && (
                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <Label htmlFor="certifications">Certificaciones</Label>
                    <Textarea id="certifications" defaultValue={psychologist.certifications.join("\n")} rows={4} />
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
        {isEditing && (
          <CardFooter>
            <Button onClick={handleSaveChanges}>Guardar Cambios</Button>
          </CardFooter>
        )}
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Estadísticas de Atención</CardTitle>
          <CardDescription>Resumen de casos atendidos y en seguimiento</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-muted rounded-lg p-4 text-center">
              <h3 className="text-2xl font-bold">24</h3>
              <p className="text-muted-foreground">Casos Activos</p>
            </div>
            <div className="bg-muted rounded-lg p-4 text-center">
              <h3 className="text-2xl font-bold">18</h3>
              <p className="text-muted-foreground">Sesiones Esta Semana</p>
            </div>
            <div className="bg-muted rounded-lg p-4 text-center">
              <h3 className="text-2xl font-bold">142</h3>
              <p className="text-muted-foreground">Casos Completados</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

