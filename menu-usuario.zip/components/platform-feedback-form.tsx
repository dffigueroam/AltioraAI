"use client"
import { useState, useEffect } from "react"
import { StarIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { cn } from "@/lib/utils"

const FEEDBACK_INTERVAL = 30 * 24 * 60 * 60 * 1000 // 30 días en milisegundos

const formSchema = z.object({
  performanceRating: z.number().min(1).max(5),
  intuitivenessRating: z.number().min(1).max(5),
  interactivityRating: z.number().min(1).max(5),
  designRating: z.number().min(1).max(5),
  supportRating: z.number().min(1).max(5),
  improvements: z.string().optional(),
})

export function PlatformFeedbackForm() {
  const [isOpen, setIsOpen] = useState(false)
  const [showTrigger, setShowTrigger] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      performanceRating: 0,
      intuitivenessRating: 0,
      interactivityRating: 0,
      designRating: 0,
      supportRating: 0,
      improvements: "",
    },
  })

  useEffect(() => {
    const lastFeedback = localStorage.getItem("lastFeedbackDate")
    if (!lastFeedback) {
      // Si es la primera vez, esperar 7 días antes de mostrar
      const waitTime = 7 * 24 * 60 * 60 * 1000
      setTimeout(() => setShowTrigger(true), waitTime)
    } else {
      const timeSinceLastFeedback = Date.now() - Number.parseInt(lastFeedback)
      if (timeSinceLastFeedback >= FEEDBACK_INTERVAL) {
        setShowTrigger(true)
      }
    }
  }, [])

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Aquí iría la lógica para enviar el feedback al backend
    console.log(values)
    localStorage.setItem("lastFeedbackDate", Date.now().toString())
    setIsOpen(false)
    setShowTrigger(false)
  }

  const RatingStars = ({ field }: { field: any }) => (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((rating) => (
        <button
          key={rating}
          type="button"
          onClick={() => field.onChange(rating)}
          className={cn(
            "rounded-full p-1 hover:bg-slate-100",
            field.value >= rating ? "text-yellow-400" : "text-gray-300",
          )}
        >
          <StarIcon className="h-6 w-6" />
        </button>
      ))}
    </div>
  )

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      {showTrigger && (
        <DialogTrigger asChild>
          <Button
            data-feedback-trigger
            variant="outline"
            className="fixed bottom-24 right-6 bg-white shadow-lg border-2 border-[#1E40AF] text-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
          >
            ¿Cómo podemos mejorar?
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-[#1E40AF]">Tu opinión nos importa</DialogTitle>
          <DialogDescription>
            Ayúdanos a mejorar tu experiencia en la plataforma. Tus respuestas son anónimas y nos ayudarán a crear una
            mejor plataforma educativa.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="performanceRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan rápida te funciona la plataforma?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la velocidad y el rendimiento general</FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="intuitivenessRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan intuitiva te parece?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa qué tan fácil es usar la plataforma</FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="interactivityRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué te parecen las funciones al hacer click en los botones?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la respuesta y funcionalidad de los elementos interactivos</FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="designRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tanto te gustan los colores y el diseño?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la apariencia visual de la plataforma</FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supportRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan rápida es la atención de tus incidentes?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la velocidad y calidad del soporte técnico</FormDescription>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="improvements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué le mejorarías a la plataforma?</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Comparte tus sugerencias para mejorar la plataforma..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>Tus sugerencias nos ayudan a crear una mejor experiencia para todos</FormDescription>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsOpen(false)
                  // Posponer por 7 días
                  const nextShow = Date.now() + 7 * 24 * 60 * 60 * 1000
                  localStorage.setItem("lastFeedbackDate", nextShow.toString())
                }}
              >
                Recordarme después
              </Button>
              <Button type="submit" className="bg-[#1E40AF]">
                Enviar Feedback
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

