"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { CalendarIcon, Plus, Activity, ArrowUpRight, ArrowDownRight, ArrowRight, Timer, Medal } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface TestFisico {
  id: string
  fecha: string
  tipo: string
  resultado: number
  unidad: string
  evaluacion: "excelente" | "bueno" | "promedio" | "regular" | "mejorable"
  notas?: string
}

// Datos de ejemplo
const mockTests: TestFisico[] = [
  {
    id: "1",
    fecha: "2023-01-20",
    tipo: "velocidad",
    resultado: 13.2,
    unidad: "segundos",
    evaluacion: "bueno",
    notas: "100 metros planos",
  },
  {
    id: "2",
    fecha: "2023-01-20",
    tipo: "resistencia",
    resultado: 12.5,
    unidad: "minutos",
    evaluacion: "excelente",
    notas: "Test de Cooper (2km)",
  },
  {
    id: "3",
    fecha: "2023-01-20",
    tipo: "fuerza",
    resultado: 8,
    unidad: "repeticiones",
    evaluacion: "promedio",
    notas: "Dominadas",
  },
  {
    id: "4",
    fecha: "2023-04-15",
    tipo: "velocidad",
    resultado: 12.8,
    unidad: "segundos",
    evaluacion: "excelente",
    notas: "100 metros planos",
  },
  {
    id: "5",
    fecha: "2023-04-15",
    tipo: "resistencia",
    resultado: 12.2,
    unidad: "minutos",
    evaluacion: "excelente",
    notas: "Test de Cooper (2km)",
  },
  {
    id: "6",
    fecha: "2023-04-15",
    tipo: "fuerza",
    resultado: 10,
    unidad: "repeticiones",
    evaluacion: "bueno",
    notas: "Dominadas",
  },
  {
    id: "7",
    fecha: "2023-07-10",
    tipo: "velocidad",
    resultado: 12.5,
    unidad: "segundos",
    evaluacion: "excelente",
    notas: "100 metros planos",
  },
  {
    id: "8",
    fecha: "2023-07-10",
    tipo: "resistencia",
    resultado: 11.8,
    unidad: "minutos",
    evaluacion: "excelente",
    notas: "Test de Cooper (2km)",
  },
  {
    id: "9",
    fecha: "2023-07-10",
    tipo: "fuerza",
    resultado: 12,
    unidad: "repeticiones",
    evaluacion: "excelente",
    notas: "Dominadas",
  },
]

const formSchema = z.object({
  fecha: z.date({
    required_error: "La fecha es requerida",
  }),
  tipo: z.string({
    required_error: "El tipo de test es requerido",
  }),
  resultado: z.coerce.number().positive("El resultado debe ser un número positivo"),
  unidad: z.string({
    required_error: "La unidad es requerida",
  }),
  evaluacion: z.enum(["excelente", "bueno", "promedio", "regular", "mejorable"], {
    required_error: "La evaluación es requerida",
  }),
  notas: z.string().optional(),
})

export function TestsFisicos() {
  const [tests, setTests] = useState<TestFisico[]>(mockTests)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fecha: new Date(),
      tipo: "",
      resultado: 0,
      unidad: "",
      evaluacion: "promedio",
      notas: "",
    },
  })

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    const nuevoTest: TestFisico = {
      id: Date.now().toString(),
      fecha: values.fecha.toISOString().split("T")[0],
      tipo: values.tipo,
      resultado: values.resultado,
      unidad: values.unidad,
      evaluacion: values.evaluacion as "excelente" | "bueno" | "promedio" | "regular" | "mejorable",
      notas: values.notas,
    }

    setTests([...tests, nuevoTest])
    setIsDialogOpen(false)
    form.reset()
  }

  const formatFecha = (fecha: string) => {
    return format(new Date(fecha), "dd MMM yyyy", { locale: es })
  }

  // Agrupar tests por fecha
  const testsPorFecha = tests.reduce(
    (acc, test) => {
      if (!acc[test.fecha]) {
        acc[test.fecha] = []
      }
      acc[test.fecha].push(test)
      return acc
    },
    {} as Record<string, TestFisico[]>,
  )

  // Ordenar fechas de más reciente a más antigua
  const fechasOrdenadas = Object.keys(testsPorFecha).sort((a, b) => new Date(b).getTime() - new Date(a).getTime())

  // Obtener el último test de cada tipo
  const ultimosTests = tests.reduce(
    (acc, test) => {
      if (!acc[test.tipo] || new Date(test.fecha) > new Date(acc[test.tipo].fecha)) {
        acc[test.tipo] = test
      }
      return acc
    },
    {} as Record<string, TestFisico>,
  )

  // Calcular progreso para cada tipo de test
  const calcularProgreso = (tipo: string) => {
    const testsDelTipo = tests
      .filter((test) => test.tipo === tipo)
      .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())

    if (testsDelTipo.length < 2) return null

    const primero = testsDelTipo[0]
    const ultimo = testsDelTipo[testsDelTipo.length - 1]

    // Para tests donde menor es mejor (como tiempo)
    if (ultimo.unidad === "segundos" || ultimo.unidad === "minutos") {
      const mejora = primero.resultado - ultimo.resultado
      const porcentaje = (mejora / primero.resultado) * 100
      return {
        mejora: mejora.toFixed(2),
        porcentaje: porcentaje.toFixed(1),
        positivo: mejora > 0,
      }
    }
    // Para tests donde mayor es mejor (como repeticiones)
    else {
      const mejora = ultimo.resultado - primero.resultado
      const porcentaje = (mejora / primero.resultado) * 100
      return {
        mejora: mejora.toFixed(2),
        porcentaje: porcentaje.toFixed(1),
        positivo: mejora > 0,
      }
    }
  }

  const getEvaluacionColor = (evaluacion: string) => {
    switch (evaluacion) {
      case "excelente":
        return "bg-green-100 text-green-800"
      case "bueno":
        return "bg-blue-100 text-blue-800"
      case "promedio":
        return "bg-yellow-100 text-yellow-800"
      case "regular":
        return "bg-orange-100 text-orange-800"
      case "mejorable":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getProgressValue = (evaluacion: string) => {
    switch (evaluacion) {
      case "excelente":
        return 100
      case "bueno":
        return 80
      case "promedio":
        return 60
      case "regular":
        return 40
      case "mejorable":
        return 20
      default:
        return 0
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#1E40AF]">Tests Físicos</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#1E40AF]">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Test
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Registrar Nuevo Test Físico</DialogTitle>
              <DialogDescription>
                Ingresa los resultados de tu test físico. Estos datos te ayudarán a hacer seguimiento de tu rendimiento.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fecha"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Fecha del Test</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: es })
                              ) : (
                                <span>Seleccione una fecha</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date > new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tipo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo de Test</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione tipo de test" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="velocidad">Velocidad</SelectItem>
                            <SelectItem value="resistencia">Resistencia</SelectItem>
                            <SelectItem value="fuerza">Fuerza</SelectItem>
                            <SelectItem value="flexibilidad">Flexibilidad</SelectItem>
                            <SelectItem value="agilidad">Agilidad</SelectItem>
                            <SelectItem value="coordinacion">Coordinación</SelectItem>
                            <SelectItem value="equilibrio">Equilibrio</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="evaluacion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Evaluación</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione evaluación" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="excelente">Excelente</SelectItem>
                            <SelectItem value="bueno">Bueno</SelectItem>
                            <SelectItem value="promedio">Promedio</SelectItem>
                            <SelectItem value="regular">Regular</SelectItem>
                            <SelectItem value="mejorable">Mejorable</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="resultado"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Resultado</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="unidad"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unidad</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione unidad" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="segundos">Segundos</SelectItem>
                            <SelectItem value="minutos">Minutos</SelectItem>
                            <SelectItem value="repeticiones">Repeticiones</SelectItem>
                            <SelectItem value="metros">Metros</SelectItem>
                            <SelectItem value="centimetros">Centímetros</SelectItem>
                            <SelectItem value="kilogramos">Kilogramos</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notas"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notas</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej: 100 metros planos, Test de Cooper, etc." {...field} />
                      </FormControl>
                      <FormDescription>Información adicional sobre el test realizado</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-[#1E40AF]">
                    Guardar Test
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {tests.length > 0 ? (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Resumen de Rendimiento</CardTitle>
              <CardDescription>Resultados de tus últimos tests físicos y progreso</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.values(ultimosTests).map((test) => {
                  const progreso = calcularProgreso(test.tipo)
                  return (
                    <Card key={test.id} className="bg-slate-50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="text-sm text-muted-foreground capitalize">{test.tipo}</p>
                            <div className="flex items-center gap-2">
                              <p className="text-2xl font-bold">
                                {test.resultado} {test.unidad}
                              </p>
                              <Badge className={getEvaluacionColor(test.evaluacion)}>
                                {test.evaluacion.charAt(0).toUpperCase() + test.evaluacion.slice(1)}
                              </Badge>
                            </div>
                          </div>
                          {test.tipo === "velocidad" || test.tipo === "resistencia" ? (
                            <Timer className="h-5 w-5 text-[#3B82F6]" />
                          ) : (
                            <Activity className="h-5 w-5 text-[#3B82F6]" />
                          )}
                        </div>
                        <div className="mt-2">
                          <Progress value={getProgressValue(test.evaluacion)} className="h-2" />
                        </div>
                        {progreso && (
                          <div className="flex items-center mt-2 text-xs">
                            {progreso.mejora === "0.00" ? (
                              <ArrowRight className="h-3 w-3 text-gray-500 mr-1" />
                            ) : progreso.positivo ? (
                              <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                            ) : (
                              <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                            )}
                            <span
                              className={
                                progreso.mejora === "0.00"
                                  ? "text-gray-500"
                                  : progreso.positivo
                                    ? "text-green-500"
                                    : "text-red-500"
                              }
                            >
                              {(test.unidad === "segundos" || test.unidad === "minutos") && progreso.positivo
                                ? "Reducción de "
                                : "Mejora de "}
                              {progreso.mejora} {test.unidad} ({progreso.porcentaje}%)
                            </span>
                          </div>
                        )}
                        {test.notas && <p className="text-xs text-muted-foreground mt-2">{test.notas}</p>}
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="historial">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="historial">Historial de Tests</TabsTrigger>
              <TabsTrigger value="comparativa">Comparativa</TabsTrigger>
            </TabsList>
            <TabsContent value="historial" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Historial de Tests Físicos</CardTitle>
                  <CardDescription>Registro completo de tus evaluaciones físicas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {fechasOrdenadas.map((fecha) => (
                      <div key={fecha}>
                        <h3 className="font-medium mb-2">{formatFecha(fecha)}</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Tipo</TableHead>
                              <TableHead>Resultado</TableHead>
                              <TableHead>Evaluación</TableHead>
                              <TableHead>Notas</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {testsPorFecha[fecha].map((test) => (
                              <TableRow key={test.id}>
                                <TableCell className="capitalize">{test.tipo}</TableCell>
                                <TableCell>
                                  {test.resultado} {test.unidad}
                                </TableCell>
                                <TableCell>
                                  <Badge className={getEvaluacionColor(test.evaluacion)}>
                                    {test.evaluacion.charAt(0).toUpperCase() + test.evaluacion.slice(1)}
                                  </Badge>
                                </TableCell>
                                <TableCell>{test.notas}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="comparativa" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Comparativa de Rendimiento</CardTitle>
                  <CardDescription>Análisis de tu progreso en diferentes tests físicos</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {["velocidad", "resistencia", "fuerza"].map((tipo) => {
                      const testsDelTipo = tests
                        .filter((test) => test.tipo === tipo)
                        .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())

                      if (testsDelTipo.length === 0) return null

                      const primero = testsDelTipo[0]
                      const ultimo = testsDelTipo[testsDelTipo.length - 1]
                      const progreso = calcularProgreso(tipo)

                      return (
                        <Card key={tipo} className="p-4">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="font-medium capitalize">{tipo}</h3>
                            {progreso && progreso.positivo && (
                              <Badge className="bg-green-100 text-green-800">
                                <Medal className="h-3 w-3 mr-1" />
                                Mejora {progreso.porcentaje}%
                              </Badge>
                            )}
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="flex items-center justify-between p-3 rounded-lg border">
                              <div>
                                <p className="text-sm text-muted-foreground">Primera medición</p>
                                <p className="font-medium">
                                  {primero.resultado} {primero.unidad}
                                </p>
                                <p className="text-xs text-muted-foreground">{formatFecha(primero.fecha)}</p>
                              </div>
                              <Badge className={getEvaluacionColor(primero.evaluacion)}>
                                {primero.evaluacion.charAt(0).toUpperCase() + primero.evaluacion.slice(1)}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between p-3 rounded-lg border">
                              <div>
                                <p className="text-sm text-muted-foreground">Última medición</p>
                                <p className="font-medium">
                                  {ultimo.resultado} {ultimo.unidad}
                                </p>
                                <p className="text-xs text-muted-foreground">{formatFecha(ultimo.fecha)}</p>
                              </div>
                              <Badge className={getEvaluacionColor(ultimo.evaluacion)}>
                                {ultimo.evaluacion.charAt(0).toUpperCase() + ultimo.evaluacion.slice(1)}
                              </Badge>
                            </div>
                          </div>
                        </Card>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Tests Físicos</CardTitle>
            <CardDescription>
              Aún no has registrado ningún test físico. Comienza a hacer seguimiento de tu rendimiento.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <Activity className="h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-6 text-center">
              Registrar tus tests físicos te permitirá hacer seguimiento de tu rendimiento y progreso deportivo.
            </p>
            <Button
              className="bg-[#1E40AF]"
              onClick={() => {
                setIsDialogOpen(true)
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Registrar Primer Test
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

