"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { CalendarIcon, Plus, Ruler, ArrowUpRight, ArrowDownRight, ArrowRight } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface MedidaFisica {
  id: string
  fecha: string
  altura: number
  peso: number
  imc: number
  porcentajeGrasaCorporal: number
  masaMuscular: number
  circunferenciaCintura: number
  circunferenciaCadera: number
  envergadura: number
}

// Datos de ejemplo
const mockMedidas: MedidaFisica[] = [
  {
    id: "1",
    fecha: "2023-01-15",
    altura: 168,
    peso: 65.5,
    imc: 23.2,
    porcentajeGrasaCorporal: 18.5,
    masaMuscular: 48.2,
    circunferenciaCintura: 78,
    circunferenciaCadera: 92,
    envergadura: 170,
  },
  {
    id: "2",
    fecha: "2023-04-20",
    altura: 169,
    peso: 64.8,
    imc: 22.7,
    porcentajeGrasaCorporal: 17.8,
    masaMuscular: 49.1,
    circunferenciaCintura: 77,
    circunferenciaCadera: 91,
    envergadura: 171,
  },
  {
    id: "3",
    fecha: "2023-07-10",
    altura: 170,
    peso: 64.2,
    imc: 22.2,
    porcentajeGrasaCorporal: 17.2,
    masaMuscular: 50.0,
    circunferenciaCintura: 76,
    circunferenciaCadera: 90,
    envergadura: 172,
  },
  {
    id: "4",
    fecha: "2023-10-05",
    altura: 171,
    peso: 63.8,
    imc: 21.8,
    porcentajeGrasaCorporal: 16.5,
    masaMuscular: 51.2,
    circunferenciaCintura: 75,
    circunferenciaCadera: 89,
    envergadura: 173,
  },
  {
    id: "5",
    fecha: "2024-01-20",
    altura: 172,
    peso: 64.0,
    imc: 21.6,
    porcentajeGrasaCorporal: 16.0,
    masaMuscular: 52.0,
    circunferenciaCintura: 74,
    circunferenciaCadera: 88,
    envergadura: 174,
  },
]

const formSchema = z.object({
  fecha: z.date({
    required_error: "La fecha es requerida",
  }),
  altura: z.coerce.number().min(100, "La altura debe ser al menos 100 cm").max(250, "La altura debe ser máximo 250 cm"),
  peso: z.coerce.number().min(30, "El peso debe ser al menos 30 kg").max(150, "El peso debe ser máximo 150 kg"),
  porcentajeGrasaCorporal: z.coerce
    .number()
    .min(5, "El porcentaje debe ser al menos 5%")
    .max(40, "El porcentaje debe ser máximo 40%"),
  masaMuscular: z.coerce.number().min(20, "La masa muscular debe ser al menos 20 kg"),
  circunferenciaCintura: z.coerce.number().min(50, "La medida debe ser al menos 50 cm"),
  circunferenciaCadera: z.coerce.number().min(50, "La medida debe ser al menos 50 cm"),
  envergadura: z.coerce.number().min(100, "La envergadura debe ser al menos 100 cm"),
})

export function MedidasFisicas() {
  const [medidas, setMedidas] = useState<MedidaFisica[]>(mockMedidas)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fecha: new Date(),
      altura: 0,
      peso: 0,
      porcentajeGrasaCorporal: 0,
      masaMuscular: 0,
      circunferenciaCintura: 0,
      circunferenciaCadera: 0,
      envergadura: 0,
    },
  })

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Calcular IMC
    const alturaMetros = values.altura / 100
    const imc = Number.parseFloat((values.peso / (alturaMetros * alturaMetros)).toFixed(1))

    const nuevaMedida: MedidaFisica = {
      id: Date.now().toString(),
      fecha: values.fecha.toISOString().split("T")[0],
      altura: values.altura,
      peso: values.peso,
      imc,
      porcentajeGrasaCorporal: values.porcentajeGrasaCorporal,
      masaMuscular: values.masaMuscular,
      circunferenciaCintura: values.circunferenciaCintura,
      circunferenciaCadera: values.circunferenciaCadera,
      envergadura: values.envergadura,
    }

    setMedidas([...medidas, nuevaMedida])
    setIsDialogOpen(false)
    form.reset()
  }

  const formatFecha = (fecha: string) => {
    return format(new Date(fecha), "dd MMM yyyy", { locale: es })
  }

  const calcularCambio = (actual: number, anterior: number) => {
    const diferencia = actual - anterior
    const porcentaje = ((diferencia / anterior) * 100).toFixed(1)
    return {
      diferencia: diferencia.toFixed(1),
      porcentaje,
      positivo: diferencia > 0,
    }
  }

  const ultimaMedida = medidas[medidas.length - 1]
  const penultimaMedida = medidas.length > 1 ? medidas[medidas.length - 2] : null

  const cambios = penultimaMedida
    ? {
        altura: calcularCambio(ultimaMedida.altura, penultimaMedida.altura),
        peso: calcularCambio(ultimaMedida.peso, penultimaMedida.peso),
        imc: calcularCambio(ultimaMedida.imc, penultimaMedida.imc),
        porcentajeGrasaCorporal: calcularCambio(
          ultimaMedida.porcentajeGrasaCorporal,
          penultimaMedida.porcentajeGrasaCorporal,
        ),
        masaMuscular: calcularCambio(ultimaMedida.masaMuscular, penultimaMedida.masaMuscular),
      }
    : null

  const chartData = medidas.map((medida) => ({
    fecha: formatFecha(medida.fecha),
    peso: medida.peso,
    imc: medida.imc,
    porcentajeGrasaCorporal: medida.porcentajeGrasaCorporal,
    masaMuscular: medida.masaMuscular,
  }))

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#1E40AF]">Medidas Físicas</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#1E40AF]">
              <Plus className="mr-2 h-4 w-4" />
              Nueva Medición
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Registrar Nueva Medición</DialogTitle>
              <DialogDescription>
                Ingresa los datos de tu nueva medición física. Estos datos te ayudarán a hacer seguimiento de tu
                progreso.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fecha"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Fecha de Medición</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: es })
                              ) : (
                                <span>Seleccione una fecha</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date > new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="altura"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Altura (cm)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="peso"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Peso (kg)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="porcentajeGrasaCorporal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Porcentaje de Grasa Corporal (%)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="masaMuscular"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Masa Muscular (kg)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="circunferenciaCintura"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Circunferencia de Cintura (cm)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="circunferenciaCadera"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Circunferencia de Cadera (cm)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="envergadura"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Envergadura (cm)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.1" {...field} />
                        </FormControl>
                        <FormDescription>Distancia entre los extremos de los brazos extendidos</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-[#1E40AF]">
                    Guardar Medición
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {medidas.length > 0 ? (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Resumen de Medidas Actuales</CardTitle>
              <CardDescription>Última medición: {formatFecha(ultimaMedida.fecha)}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Altura</p>
                        <p className="text-2xl font-bold">{ultimaMedida.altura} cm</p>
                      </div>
                      <Ruler className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                    {cambios && (
                      <div className="flex items-center mt-2 text-xs">
                        {cambios.altura.diferencia === "0.0" ? (
                          <ArrowRight className="h-3 w-3 text-gray-500 mr-1" />
                        ) : cambios.altura.positivo ? (
                          <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        <span
                          className={
                            cambios.altura.diferencia === "0.0"
                              ? "text-gray-500"
                              : cambios.altura.positivo
                                ? "text-green-500"
                                : "text-red-500"
                          }
                        >
                          {cambios.altura.diferencia} cm ({cambios.altura.porcentaje}%)
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Peso</p>
                        <p className="text-2xl font-bold">{ultimaMedida.peso} kg</p>
                      </div>
                      <Ruler className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                    {cambios && (
                      <div className="flex items-center mt-2 text-xs">
                        {cambios.peso.diferencia === "0.0" ? (
                          <ArrowRight className="h-3 w-3 text-gray-500 mr-1" />
                        ) : cambios.peso.positivo ? (
                          <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        <span
                          className={
                            cambios.peso.diferencia === "0.0"
                              ? "text-gray-500"
                              : cambios.peso.positivo
                                ? "text-green-500"
                                : "text-red-500"
                          }
                        >
                          {cambios.peso.diferencia} kg ({cambios.peso.porcentaje}%)
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">IMC</p>
                        <p className="text-2xl font-bold">{ultimaMedida.imc}</p>
                      </div>
                      <Ruler className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                    {cambios && (
                      <div className="flex items-center mt-2 text-xs">
                        {cambios.imc.diferencia === "0.0" ? (
                          <ArrowRight className="h-3 w-3 text-gray-500 mr-1" />
                        ) : cambios.imc.positivo ? (
                          <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        <span
                          className={
                            cambios.imc.diferencia === "0.0"
                              ? "text-gray-500"
                              : cambios.imc.positivo
                                ? "text-green-500"
                                : "text-red-500"
                          }
                        >
                          {cambios.imc.diferencia} ({cambios.imc.porcentaje}%)
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">% Grasa Corporal</p>
                        <p className="text-2xl font-bold">{ultimaMedida.porcentajeGrasaCorporal}%</p>
                      </div>
                      <Ruler className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                    {cambios && (
                      <div className="flex items-center mt-2 text-xs">
                        {cambios.porcentajeGrasaCorporal.diferencia === "0.0" ? (
                          <ArrowRight className="h-3 w-3 text-gray-500 mr-1" />
                        ) : cambios.porcentajeGrasaCorporal.positivo ? (
                          <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        <span
                          className={
                            cambios.porcentajeGrasaCorporal.diferencia === "0.0"
                              ? "text-gray-500"
                              : cambios.porcentajeGrasaCorporal.positivo
                                ? "text-green-500"
                                : "text-red-500"
                          }
                        >
                          {cambios.porcentajeGrasaCorporal.diferencia}% ({cambios.porcentajeGrasaCorporal.porcentaje}%)
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="grafico">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="grafico">Gráfico de Evolución</TabsTrigger>
              <TabsTrigger value="tabla">Historial de Medidas</TabsTrigger>
            </TabsList>
            <TabsContent value="grafico" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Evolución de Medidas</CardTitle>
                  <CardDescription>Seguimiento de tus medidas físicas a lo largo del tiempo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="fecha" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="peso" stroke="#3B82F6" name="Peso (kg)" />
                        <Line type="monotone" dataKey="imc" stroke="#10B981" name="IMC" />
                        <Line
                          type="monotone"
                          dataKey="porcentajeGrasaCorporal"
                          stroke="#F59E0B"
                          name="% Grasa Corporal"
                        />
                        <Line type="monotone" dataKey="masaMuscular" stroke="#6366F1" name="Masa Muscular (kg)" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="tabla" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Historial de Medidas</CardTitle>
                  <CardDescription>Registro completo de tus mediciones físicas</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Fecha</TableHead>
                        <TableHead>Altura (cm)</TableHead>
                        <TableHead>Peso (kg)</TableHead>
                        <TableHead>IMC</TableHead>
                        <TableHead>% Grasa</TableHead>
                        <TableHead>Masa Muscular (kg)</TableHead>
                        <TableHead>Cintura (cm)</TableHead>
                        <TableHead>Cadera (cm)</TableHead>
                        <TableHead>Envergadura (cm)</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {medidas
                        .slice()
                        .reverse()
                        .map((medida) => (
                          <TableRow key={medida.id}>
                            <TableCell>{formatFecha(medida.fecha)}</TableCell>
                            <TableCell>{medida.altura}</TableCell>
                            <TableCell>{medida.peso}</TableCell>
                            <TableCell>{medida.imc}</TableCell>
                            <TableCell>{medida.porcentajeGrasaCorporal}%</TableCell>
                            <TableCell>{medida.masaMuscular}</TableCell>
                            <TableCell>{medida.circunferenciaCintura}</TableCell>
                            <TableCell>{medida.circunferenciaCadera}</TableCell>
                            <TableCell>{medida.envergadura}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Medidas Físicas</CardTitle>
            <CardDescription>
              Aún no has registrado ninguna medida física. Comienza a hacer seguimiento de tu progreso.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <Ruler className="h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-6 text-center">
              Registrar tus medidas físicas te permitirá hacer seguimiento de tu progreso y desarrollo físico.
            </p>
            <Button
              className="bg-[#1E40AF]"
              onClick={() => {
                setIsDialogOpen(true)
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Registrar Primera Medición
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

