"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Users, Calendar, MapPin, Clock, ArrowRight, Edit, Plus } from "lucide-react"

interface Coach {
  id: string
  name: string
  role: string
  specialty: string
  image?: string
}

interface SportClub {
  id: string
  name: string
  logo?: string
  sport: string
  category: string
  schedule: string
  location: string
  coaches: Coach[]
  teammates: string[]
  joinDate: string
  achievements: string[]
}

// Datos de ejemplo
const mockClub: SportClub = {
  id: "1",
  name: "Águilas Doradas",
  logo: "/placeholder.svg?height=80&width=80",
  sport: "Fútbol",
  category: "Sub-16",
  schedule: "Lunes, Miércoles y Viernes 4:00 PM - 6:00 PM",
  location: "Complejo Deportivo Norte",
  coaches: [
    {
      id: "c1",
      name: "Carlos Rodríguez",
      role: "Entrenador Principal",
      specialty: "Técnica y Táctica",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "c2",
      name: "Ana Martínez",
      role: "Preparador Físico",
      specialty: "Acondicionamiento",
      image: "/placeholder.svg?height=40&width=40",
    },
  ],
  teammates: ["Juan Pérez", "Miguel Ángel", "Santiago López", "Andrés Gómez", "Felipe Martínez"],
  joinDate: "15 de marzo de 2023",
  achievements: ["Campeón Torneo Intercolegiado 2023", "Subcampeón Copa Ciudad 2023", "Mejor Equipo Defensivo 2022"],
}

export function ClubDeportivo() {
  const [club, setClub] = useState<SportClub | null>(mockClub)

  return (
    <div className="space-y-6">
      {club ? (
        <>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16 border-2 border-primary/20">
                    <AvatarImage src={club.logo} alt={club.name} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {club.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-2xl text-[#1E40AF]">{club.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        {club.sport}
                      </Badge>
                      <Badge variant="outline">{club.category}</Badge>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="gap-1">
                  <Edit className="h-4 w-4" />
                  Editar
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-[#3B82F6]" />
                  <div>
                    <p className="text-sm font-medium">Horario</p>
                    <p className="text-sm text-muted-foreground">{club.schedule}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-[#3B82F6]" />
                  <div>
                    <p className="text-sm font-medium">Ubicación</p>
                    <p className="text-sm text-muted-foreground">{club.location}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-[#3B82F6]" />
                  <div>
                    <p className="text-sm font-medium">Miembro desde</p>
                    <p className="text-sm text-muted-foreground">{club.joinDate}</p>
                  </div>
                </div>
              </div>

              <Tabs defaultValue="coaches">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="coaches">Entrenadores</TabsTrigger>
                  <TabsTrigger value="teammates">Compañeros</TabsTrigger>
                  <TabsTrigger value="achievements">Logros</TabsTrigger>
                </TabsList>
                <TabsContent value="coaches" className="space-y-4 pt-4">
                  {club.coaches.map((coach) => (
                    <div key={coach.id} className="flex items-center gap-4 p-3 rounded-lg border">
                      <Avatar>
                        <AvatarImage src={coach.image} alt={coach.name} />
                        <AvatarFallback>{coach.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{coach.name}</p>
                        <p className="text-sm text-muted-foreground">{coach.role}</p>
                        <p className="text-xs text-muted-foreground">Especialidad: {coach.specialty}</p>
                      </div>
                    </div>
                  ))}
                </TabsContent>
                <TabsContent value="teammates" className="pt-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {club.teammates.map((teammate, index) => (
                      <div key={index} className="flex items-center gap-2 p-2 rounded-lg border">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs">
                            {teammate
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm">{teammate}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="achievements" className="pt-4">
                  <div className="space-y-2">
                    {club.achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center gap-2 p-3 rounded-lg border">
                        <Trophy className="h-5 w-5 text-yellow-500" />
                        <span>{achievement}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Ver Calendario de Actividades
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-[#1E40AF]">Club Deportivo</CardTitle>
            <CardDescription>
              Aún no estás afiliado a ningún club deportivo. Únete a un club para hacer seguimiento de tus actividades
              deportivas.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <Users className="h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-6 text-center">
              Pertenecer a un club deportivo te permitirá hacer seguimiento de tus entrenamientos, medidas físicas y
              rendimiento en competencias.
            </p>
            <Button className="bg-[#1E40AF]">
              <Plus className="mr-2 h-4 w-4" />
              Unirse a un Club Deportivo
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

