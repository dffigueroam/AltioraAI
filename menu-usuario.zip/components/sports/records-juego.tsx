"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { CalendarIcon, Plus, Trophy, Medal, Star, Flag } from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"

interface RecordJuego {
  id: string
  fecha: string
  tipoEvento: string
  nombreEvento: string
  ubicacion: string
  resultado: string
  posicion?: number
  estadisticas?: {
    [key: string]: number | string
  }
  destacado: boolean
  notas?: string
  imagenes?: string[]
}

// Datos de ejemplo
const mockRecords: RecordJuego[] = [
  {
    id: "1",
    fecha: "2023-03-15",
    tipoEvento: "torneo",
    nombreEvento: "Torneo Intercolegiado Regional",
    ubicacion: "Estadio Municipal",
    resultado: "Campeón",
    posicion: 1,
    estadisticas: {
      goles: 3,
      asistencias: 2,
      tarjetasAmarillas: 1,
      tarjetasRojas: 0,
    },
    destacado: true,
    notas: "Mejor jugador del torneo",
    imagenes: ["/placeholder.svg?height=200&width=300"],
  },
  {
    id: "2",
    fecha: "2023-05-20",
    tipoEvento: "partido",
    nombreEvento: "Liga Escolar - Jornada 5",
    ubicacion: "Colegio San José",
    resultado: "Victoria 3-1",
    estadisticas: {
      goles: 1,
      asistencias: 1,
      tarjetasAmarillas: 0,
      tarjetasRojas: 0,
    },
    destacado: false,
    notas: "Buen desempeño general",
  },
  {
    id: "3",
    fecha: "2023-07-10",
    tipoEvento: "torneo",
    nombreEvento: "Copa Ciudad",
    ubicacion: "Complejo Deportivo Norte",
    resultado: "Subcampeón",
    posicion: 2,
    estadisticas: {
      goles: 4,
      asistencias: 3,
      tarjetasAmarillas: 0,
      tarjetasRojas: 0,
    },
    destacado: true,
    notas: "Goleador del torneo",
    imagenes: ["/placeholder.svg?height=200&width=300"],
  },
  {
    id: "4",
    fecha: "2023-09-05",
    tipoEvento: "partido",
    nombreEvento: "Amistoso Preparatorio",
    ubicacion: "Colegio Santa María",
    resultado: "Empate 2-2",
    estadisticas: {
      goles: 1,
      asistencias: 0,
      tarjetasAmarillas: 1,
      tarjetasRojas: 0,
    },
    destacado: false,
  },
  {
    id: "5",
    fecha: "2023-11-20",
    tipoEvento: "torneo",
    nombreEvento: "Campeonato Nacional Escolar",
    ubicacion: "Estadio Olímpico",
    resultado: "Semifinalista",
    posicion: 4,
    estadisticas: {
      goles: 2,
      asistencias: 4,
      tarjetasAmarillas: 1,
      tarjetasRojas: 0,
    },
    destacado: true,
    notas: "Mejor asistidor del torneo",
    imagenes: ["/placeholder.svg?height=200&width=300"],
  },
]

const formSchema = z.object({
  fecha: z.date({
    required_error: "La fecha es requerida",
  }),
  tipoEvento: z.string({
    required_error: "El tipo de evento es requerido",
  }),
  nombreEvento: z.string().min(3, "El nombre del evento es requerido"),
  ubicacion: z.string().min(3, "La ubicación es requerida"),
  resultado: z.string().min(1, "El resultado es requerido"),
  posicion: z.coerce.number().optional(),
  estadisticasGoles: z.coerce.number().min(0, "No puede ser negativo").optional(),
  estadisticasAsistencias: z.coerce.number().min(0, "No puede ser negativo").optional(),
  estadisticasTarjetasAmarillas: z.coerce.number().min(0, "No puede ser negativo").optional(),
  estadisticasTarjetasRojas: z.coerce.number().min(0, "No puede ser negativo").optional(),
  destacado: z.boolean().default(false),
  notas: z.string().optional(),
})

export function RecordsJuego() {
  const [records, setRecords] = useState<RecordJuego[]>(mockRecords)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fecha: new Date(),
      tipoEvento: "",
      nombreEvento: "",
      ubicacion: "",
      resultado: "",
      posicion: undefined,
      estadisticasGoles: 0,
      estadisticasAsistencias: 0,
      estadisticasTarjetasAmarillas: 0,
      estadisticasTarjetasRojas: 0,
      destacado: false,
      notas: "",
    },
  })

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    const nuevoRecord: RecordJuego = {
      id: Date.now().toString(),
      fecha: values.fecha.toISOString().split("T")[0],
      tipoEvento: values.tipoEvento,
      nombreEvento: values.nombreEvento,
      ubicacion: values.ubicacion,
      resultado: values.resultado,
      posicion: values.posicion,
      estadisticas: {
        goles: values.estadisticasGoles || 0,
        asistencias: values.estadisticasAsistencias || 0,
        tarjetasAmarillas: values.estadisticasTarjetasAmarillas || 0,
        tarjetasRojas: values.estadisticasTarjetasRojas || 0,
      },
      destacado: values.destacado,
      notas: values.notas,
    }

    setRecords([...records, nuevoRecord])
    setIsDialogOpen(false)
    form.reset()
  }

  const formatFecha = (fecha: string) => {
    return format(new Date(fecha), "dd MMM yyyy", { locale: es })
  }

  // Filtrar registros destacados
  const recordsDestacados = records.filter((record) => record.destacado)

  // Agrupar registros por año
  const recordsPorAnio = records.reduce(
    (acc, record) => {
      const anio = new Date(record.fecha).getFullYear().toString()
      if (!acc[anio]) {
        acc[anio] = []
      }
      acc[anio].push(record)
      return acc
    },
    {} as Record<string, RecordJuego[]>,
  )

  // Ordenar años de más reciente a más antiguo
  const aniosOrdenados = Object.keys(recordsPorAnio).sort((a, b) => Number.parseInt(b) - Number.parseInt(a))

  // Calcular estadísticas totales
  const estadisticasTotales = records.reduce(
    (acc, record) => {
      if (record.estadisticas) {
        acc.goles += (record.estadisticas.goles as number) || 0
        acc.asistencias += (record.estadisticas.asistencias as number) || 0
        acc.tarjetasAmarillas += (record.estadisticas.tarjetasAmarillas as number) || 0
        acc.tarjetasRojas += (record.estadisticas.tarjetasRojas as number) || 0
      }
      if (record.posicion === 1) acc.primerosPuestos++
      else if (record.posicion === 2) acc.segundosPuestos++
      else if (record.posicion === 3) acc.tercerosPuestos++
      return acc
    },
    {
      goles: 0,
      asistencias: 0,
      tarjetasAmarillas: 0,
      tarjetasRojas: 0,
      primerosPuestos: 0,
      segundosPuestos: 0,
      tercerosPuestos: 0,
    },
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#1E40AF]">Récords de Juego</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#1E40AF]">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Récord
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Registrar Nuevo Récord</DialogTitle>
              <DialogDescription>Ingresa los detalles de tu participación en un evento deportivo.</DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fecha"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Fecha del Evento</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: es })
                              ) : (
                                <span>Seleccione una fecha</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date > new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tipoEvento"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo de Evento</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione tipo de evento" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="torneo">Torneo</SelectItem>
                            <SelectItem value="partido">Partido</SelectItem>
                            <SelectItem value="campeonato">Campeonato</SelectItem>
                            <SelectItem value="amistoso">Amistoso</SelectItem>
                            <SelectItem value="liga">Liga</SelectItem>
                            <SelectItem value="copa">Copa</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="nombreEvento"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nombre del Evento</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej: Torneo Intercolegiado" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="ubicacion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ubicación</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej: Estadio Municipal" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="resultado"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Resultado</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej: Campeón, Victoria 3-1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="posicion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Posición Final</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="Ej: 1, 2, 3..." {...field} />
                        </FormControl>
                        <FormDescription>Dejar en blanco si no aplica</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="destacado"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <input
                            type="checkbox"
                            checked={field.value}
                            onChange={field.onChange}
                            className="h-4 w-4 rounded border-gray-300 text-[#1E40AF] focus:ring-[#1E40AF]"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Destacar este récord</FormLabel>
                          <FormDescription>Los récords destacados aparecerán en la sección principal</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="text-sm font-medium">Estadísticas</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <FormField
                      control={form.control}
                      name="estadisticasGoles"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Goles</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="estadisticasAsistencias"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Asistencias</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="estadisticasTarjetasAmarillas"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tarjetas Amarillas</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="estadisticasTarjetasRojas"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tarjetas Rojas</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="notas"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notas</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Ej: Mejor jugador del torneo, Hat-trick en la final..."
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>Información adicional sobre tu desempeño</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-[#1E40AF]">
                    Guardar Récord
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {records.length > 0 ? (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Resumen de Logros</CardTitle>
              <CardDescription>Estadísticas acumuladas y logros destacados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Eventos</p>
                        <p className="text-2xl font-bold">{records.length}</p>
                      </div>
                      <Flag className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Goles</p>
                        <p className="text-2xl font-bold">{estadisticasTotales.goles}</p>
                      </div>
                      <Trophy className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Asistencias</p>
                        <p className="text-2xl font-bold">{estadisticasTotales.asistencias}</p>
                      </div>
                      <Star className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-50">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-muted-foreground">Podios</p>
                        <p className="text-2xl font-bold">
                          {estadisticasTotales.primerosPuestos +
                            estadisticasTotales.segundosPuestos +
                            estadisticasTotales.tercerosPuestos}
                        </p>
                      </div>
                      <Medal className="h-5 w-5 text-[#3B82F6]" />
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="bg-yellow-100 text-yellow-800">{estadisticasTotales.primerosPuestos} 🥇</Badge>
                      <Badge className="bg-gray-100 text-gray-800">{estadisticasTotales.segundosPuestos} 🥈</Badge>
                      <Badge className="bg-amber-100 text-amber-800">{estadisticasTotales.tercerosPuestos} 🥉</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {recordsDestacados.length > 0 && (
                <div className="space-y-4">
                  <h3 className="font-medium">Logros Destacados</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {recordsDestacados.map((record) => (
                      <Card key={record.id} className="overflow-hidden">
                        {record.imagenes && record.imagenes.length > 0 && (
                          <div className="relative h-40 w-full">
                            <img
                              src={record.imagenes[0] || "/placeholder.svg"}
                              alt={record.nombreEvento}
                              className="object-cover w-full h-full"
                            />
                            {record.posicion === 1 && (
                              <div className="absolute top-2 right-2">
                                <Badge className="bg-yellow-400 text-yellow-900">🥇 Campeón</Badge>
                              </div>
                            )}
                            {record.posicion === 2 && (
                              <div className="absolute top-2 right-2">
                                <Badge className="bg-gray-300 text-gray-900">🥈 Subcampeón</Badge>
                              </div>
                            )}
                            {record.posicion === 3 && (
                              <div className="absolute top-2 right-2">
                                <Badge className="bg-amber-300 text-amber-900">🥉 Tercer Lugar</Badge>
                              </div>
                            )}
                          </div>
                        )}
                        <CardContent className="p-4">
                          <h4 className="font-medium">{record.nombreEvento}</h4>
                          <p className="text-sm text-muted-foreground">{formatFecha(record.fecha)}</p>
                          <p className="text-sm mt-1">{record.resultado}</p>
                          {record.notas && <p className="text-sm text-muted-foreground mt-2">{record.notas}</p>}
                          {record.estadisticas && (
                            <div className="flex flex-wrap gap-2 mt-2">
                              {Object.entries(record.estadisticas).map(([key, value]) => (
                                <Badge key={key} variant="outline">
                                  {key}: {value}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Tabs defaultValue="historial">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="historial">Historial Completo</TabsTrigger>
              <TabsTrigger value="estadisticas">Estadísticas</TabsTrigger>
            </TabsList>
            <TabsContent value="historial" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Historial de Eventos</CardTitle>
                  <CardDescription>Registro completo de tu participación en eventos deportivos</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {aniosOrdenados.map((anio) => (
                      <div key={anio}>
                        <h3 className="font-medium mb-2">{anio}</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Fecha</TableHead>
                              <TableHead>Evento</TableHead>
                              <TableHead>Tipo</TableHead>
                              <TableHead>Ubicación</TableHead>
                              <TableHead>Resultado</TableHead>
                              <TableHead>Estadísticas</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {recordsPorAnio[anio]
                              .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
                              .map((record) => (
                                <TableRow key={record.id}>
                                  <TableCell>{formatFecha(record.fecha)}</TableCell>
                                  <TableCell>
                                    <div className="font-medium">{record.nombreEvento}</div>
                                    {record.notas && (
                                      <div className="text-xs text-muted-foreground">{record.notas}</div>
                                    )}
                                  </TableCell>
                                  <TableCell className="capitalize">{record.tipoEvento}</TableCell>
                                  <TableCell>{record.ubicacion}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <span>{record.resultado}</span>
                                      {record.posicion === 1 && <span className="text-lg">🥇</span>}
                                      {record.posicion === 2 && <span className="text-lg">🥈</span>}
                                      {record.posicion === 3 && <span className="text-lg">🥉</span>}
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    {record.estadisticas && (
                                      <div className="flex flex-wrap gap-1">
                                        {Object.entries(record.estadisticas).map(([key, value]) => (
                                          <Badge key={key} variant="outline" className="text-xs">
                                            {key}: {value}
                                          </Badge>
                                        ))}
                                      </div>
                                    )}
                                  </TableCell>
                                </TableRow>
                              ))}
                          </TableBody>
                        </Table>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="estadisticas" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Estadísticas Generales</CardTitle>
                  <CardDescription>Resumen de tus estadísticas a lo largo de tu historial deportivo</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Categoría</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>Goles</TableCell>
                        <TableCell>{estadisticasTotales.goles}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Asistencias</TableCell>
                        <TableCell>{estadisticasTotales.asistencias}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Tarjetas Amarillas</TableCell>
                        <TableCell>{estadisticasTotales.tarjetasAmarillas}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Tarjetas Rojas</TableCell>
                        <TableCell>{estadisticasTotales.tarjetasRojas}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Primeros Puestos</TableCell>
                        <TableCell>{estadisticasTotales.primerosPuestos}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Segundos Puestos</TableCell>
                        <TableCell>{estadisticasTotales.segundosPuestos}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Terceros Puestos</TableCell>
                        <TableCell>{estadisticasTotales.tercerosPuestos}</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <p>No hay registros de juego aún.</p>
      )}
    </div>
  )
}

