"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TeacherAssignmentDialog } from "./teacher-assignment-dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { UserPlus, Trash2 } from "lucide-react"
import type { TeacherAssignment, Subject, TeacherWithDetails } from "@/types/teacher-assignment"

// Datos de prueba
const mockSubjects: { [key: string]: Subject } = {
  "1": { id: "1", name: "Matemáticas", code: "MAT" },
  "2": { id: "2", name: "Lenguaje", code: "LEN" },
  "3": { id: "3", name: "Ciencias Naturales", code: "CN" },
  "4": { id: "4", name: "Ciencias Sociales", code: "CS" },
  "5": { id: "5", name: "Inglés", code: "ING" },
}

// Lista completa de grupos disponibles
const allClassrooms = [
  "2A",
  "2B",
  "3A",
  "3B",
  "4A",
  "4B",
  "5A",
  "5B",
  "6A",
  "6B",
  "7A",
  "7B",
  "8A",
  "8B",
  "9A",
  "9B",
  "10A",
  "10B",
  "11A",
  "11B",
]

// Datos de prueba de profesores asignados
const mockTeachers: TeacherWithDetails[] = [
  {
    id: "1",
    name: "Juan Pérez",
    email: "juan.perez@altiora.edu",
    specialties: ["Matemáticas", "Física"],
    assignedClassrooms: ["10A", "10B"],
    directorOf: "10A",
  },
  {
    id: "2",
    name: "María Rodríguez",
    email: "maria.rodriguez@altiora.edu",
    specialties: ["Lenguaje", "Sociales"],
    assignedClassrooms: ["9A", "9B"],
  },
  {
    id: "3",
    name: "Carlos López",
    email: "carlos.lopez@altiora.edu",
    specialties: ["Ciencias Naturales", "Química"],
    assignedClassrooms: ["11A"],
  },
]

interface ClassroomAssignmentsProps {
  classroomId?: string // Ahora es opcional ya que mostraremos todos los grupos
}

export function ClassroomAssignments({ classroomId }: ClassroomAssignmentsProps) {
  const [assignments, setAssignments] = useState<TeacherAssignment[]>([])
  const [selectedClassroom, setSelectedClassroom] = useState<string | null>(null)

  const handleAssign = (assignment: {
    teacherId: string
    subjectId: string
    isGroupDirector: boolean
  }) => {
    const newAssignment: TeacherAssignment = {
      id: Math.random().toString(36).substr(2, 9),
      ...assignment,
      classroomId: selectedClassroom!,
    }
    setAssignments((prev) => [...prev, newAssignment])
    setSelectedClassroom(null)
  }

  const handleRemoveAssignment = (assignmentId: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== assignmentId))
  }

  const getTeacherForClassroom = (classroom: string) => {
    // Primero buscamos en las asignaciones locales
    const localAssignment = assignments.find((a) => a.classroomId === classroom)
    if (localAssignment) {
      const teacher = mockTeachers.find((t) => t.id === localAssignment.teacherId)
      return {
        name: teacher?.name || "Profesor Desconocido",
        isDirector: localAssignment.isGroupDirector,
        subjects: [mockSubjects[localAssignment.subjectId].name],
      }
    }

    // Luego buscamos en los datos de prueba
    const teacher = mockTeachers.find((t) => t.assignedClassrooms.includes(classroom))
    if (teacher) {
      return {
        name: teacher.name,
        isDirector: teacher.directorOf === classroom,
        subjects: teacher.specialties,
      }
    }

    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-[#1E40AF]">Asignación de Profesores por Grupo</CardTitle>
        <CardDescription>Gestiona los profesores asignados a cada grupo</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Grupo</TableHead>
              <TableHead>Profesor Asignado</TableHead>
              <TableHead>Materias</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {allClassrooms.map((classroom) => {
              const teacherInfo = getTeacherForClassroom(classroom)

              return (
                <TableRow key={classroom}>
                  <TableCell className="font-medium">{classroom}</TableCell>
                  <TableCell>
                    {teacherInfo ? (
                      <div className="flex items-center gap-2">
                        <span>{teacherInfo.name}</span>
                        {teacherInfo.isDirector && <Badge className="bg-[#EC4899] text-white">Director</Badge>}
                      </div>
                    ) : (
                      <span className="text-slate-500">Sin asignar</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {teacherInfo?.subjects.map((subject, index) => (
                      <Badge key={index} variant="secondary" className="mr-1">
                        {subject}
                      </Badge>
                    ))}
                  </TableCell>
                  <TableCell>
                    {teacherInfo ? (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        onClick={() => {
                          const assignmentToRemove = assignments.find((a) => a.classroomId === classroom)
                          if (assignmentToRemove) {
                            handleRemoveAssignment(assignmentToRemove.id)
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    ) : (
                      <TeacherAssignmentDialog
                        classroomId={classroom}
                        onAssign={(assignment) => {
                          setSelectedClassroom(classroom)
                          handleAssign(assignment)
                        }}
                        trigger={
                          <Button size="sm" className="bg-[#1E40AF]">
                            <UserPlus className="h-4 w-4 mr-2" />
                            Asignar
                          </Button>
                        }
                      />
                    )}
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

