"use client"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, ArrowLeft, Brain, Calendar, CheckCircle2, Heart } from "lucide-react"

interface EstadoEmocionalEstudianteProps {
  estudianteId: string
  userName: string
}

export function EstadoEmocionalEstudiante({ estudianteId, userName }: EstadoEmocionalEstudianteProps) {
  // Simulación de datos del estudiante
  const estudiante = {
    id: estudianteId,
    nombre: "Ana García",
    grado: "3A",
    estado: "Estrés Pre-Evento",
    fechaRegistro: "24/2/2024",
    descripcion: "La estudiante ha mostrado signos de ansiedad y estrés antes de los exámenes.",
    recomendacion: "Programar una reunión con el estudiante y el departamento de orientación.",
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" asChild>
          <Link href="/dashboard/profesor/acciones-pendientes">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Estado Emocional del Estudiante</h1>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">{estudiante.nombre}</CardTitle>
              <CardDescription>Grado: {estudiante.grado}</CardDescription>
            </div>
            <Badge className="bg-red-100 text-red-800 border-red-200">Requiere atención inmediata</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="informacion">
            <TabsList className="mb-4">
              <TabsTrigger value="informacion">Información</TabsTrigger>
              <TabsTrigger value="historial">Historial</TabsTrigger>
              <TabsTrigger value="acciones">Acciones</TabsTrigger>
            </TabsList>

            <TabsContent value="informacion">
              <div className="space-y-4">
                <div className="p-4 bg-red-50 rounded-lg border border-red-100">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-red-800">{estudiante.estado}</h3>
                      <p className="text-sm text-red-700 mt-1">Registrado el {estudiante.fechaRegistro}</p>
                      <p className="mt-2">{estudiante.descripcion}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Recomendación:</h3>
                  <p>{estudiante.recomendacion}</p>
                </div>

                <div className="flex justify-end">
                  <Button>
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Marcar como atendido
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="historial">
              <div className="space-y-4">
                <div className="border-l-2 border-gray-200 pl-4 ml-2 space-y-6">
                  <div className="relative">
                    <div className="absolute -left-[25px] top-1 h-4 w-4 rounded-full bg-blue-500"></div>
                    <div>
                      <h3 className="font-medium">Registro inicial</h3>
                      <p className="text-sm text-gray-500">24/2/2024 - Profesor: María González</p>
                      <p className="mt-1">Se detectó ansiedad antes del examen de matemáticas.</p>
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute -left-[25px] top-1 h-4 w-4 rounded-full bg-gray-300"></div>
                    <div>
                      <h3 className="font-medium">Seguimiento</h3>
                      <p className="text-sm text-gray-500">26/2/2024 - Psicóloga: Laura Sánchez</p>
                      <p className="mt-1">Primera sesión de evaluación realizada.</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="acciones">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button className="h-auto py-4 flex flex-col items-center justify-center">
                    <Calendar className="h-6 w-6 mb-2" />
                    <span>Programar Reunión</span>
                  </Button>

                  <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                    <Brain className="h-6 w-6 mb-2" />
                    <span>Derivar a Psicología</span>
                  </Button>

                  <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                    <Heart className="h-6 w-6 mb-2" />
                    <span>Registrar Seguimiento</span>
                  </Button>

                  <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                    <AlertTriangle className="h-6 w-6 mb-2" />
                    <span>Reportar Incidente</span>
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

