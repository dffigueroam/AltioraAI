"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Check } from "lucide-react"
import type { TeacherWithDetails, Subject } from "@/types/teacher-assignment"

// Datos de prueba
const mockSubjects: Subject[] = [
  { id: "1", name: "Matemáticas", code: "MAT" },
  { id: "2", name: "Lenguaje", code: "LEN" },
  { id: "3", name: "Ciencias Naturales", code: "CN" },
  { id: "4", name: "Ciencias Sociales", code: "CS" },
  { id: "5", name: "Inglés", code: "ING" },
  { id: "6", name: "Educación Física", code: "EF" },
  { id: "7", name: "Artes", code: "ART" },
]

const mockTeachers: TeacherWithDetails[] = [
  {
    id: "1",
    name: "Juan Pérez",
    email: "juan.perez@altiora.edu",
    specialties: ["Matemáticas", "Física"],
    assignedClassrooms: ["10A", "10B"],
    directorOf: "10A",
  },
  {
    id: "2",
    name: "María Rodríguez",
    email: "maria.rodriguez@altiora.edu",
    specialties: ["Lenguaje", "Sociales"],
    assignedClassrooms: ["9A", "9B"],
  },
  {
    id: "3",
    name: "Carlos López",
    email: "carlos.lopez@altiora.edu",
    specialties: ["Ciencias Naturales", "Química"],
    assignedClassrooms: ["11A"],
  },
]

interface TeacherAssignmentDialogProps {
  classroomId: string
  onAssign: (assignment: {
    teacherId: string
    subjectId: string
    isGroupDirector: boolean
  }) => void
  trigger?: React.ReactNode
}

export function TeacherAssignmentDialog({ classroomId, onAssign, trigger }: TeacherAssignmentDialogProps) {
  const [selectedTeacher, setSelectedTeacher] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [isGroupDirector, setIsGroupDirector] = useState(false)
  const [isOpen, setIsOpen] = useState(false)

  const handleAssign = () => {
    if (selectedTeacher && selectedSubject) {
      onAssign({
        teacherId: selectedTeacher,
        subjectId: selectedSubject,
        isGroupDirector,
      })
      setIsOpen(false)
      resetForm()
    }
  }

  const resetForm = () => {
    setSelectedTeacher("")
    setSelectedSubject("")
    setIsGroupDirector(false)
  }

  const selectedTeacherDetails = mockTeachers.find((t) => t.id === selectedTeacher)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{trigger || <Button className="bg-[#1E40AF]">Asignar Profesor</Button>}</DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Asignar Profesor al Grupo {classroomId}</DialogTitle>
          <DialogDescription>Selecciona un profesor y la materia que impartirá en este grupo.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="teacher">Profesor</Label>
            <Select value={selectedTeacher} onValueChange={setSelectedTeacher}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un profesor" />
              </SelectTrigger>
              <SelectContent>
                {mockTeachers.map((teacher) => (
                  <SelectItem key={teacher.id} value={teacher.id}>
                    {teacher.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedTeacherDetails && (
            <div className="bg-slate-50 p-3 rounded-md">
              <h4 className="font-medium mb-2">Información del profesor:</h4>
              <div className="space-y-2 text-sm">
                <p>
                  <span className="text-slate-600">Especialidades:</span>{" "}
                  {selectedTeacherDetails.specialties.join(", ")}
                </p>
                <p>
                  <span className="text-slate-600">Grupos asignados:</span>{" "}
                  {selectedTeacherDetails.assignedClassrooms.join(", ")}
                </p>
                {selectedTeacherDetails.directorOf && (
                  <p>
                    <Badge variant="secondary" className="bg-[#EC4899] text-white">
                      Director del grupo {selectedTeacherDetails.directorOf}
                    </Badge>
                  </p>
                )}
              </div>
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="subject">Materia</Label>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una materia" />
              </SelectTrigger>
              <SelectContent>
                {mockSubjects.map((subject) => (
                  <SelectItem key={subject.id} value={subject.id}>
                    {subject.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="director"
              checked={isGroupDirector}
              onCheckedChange={(checked) => setIsGroupDirector(checked as boolean)}
              disabled={selectedTeacherDetails?.directorOf !== undefined}
            />
            <Label htmlFor="director">Asignar como Director de Grupo</Label>
          </div>

          {selectedTeacherDetails?.directorOf && (
            <Alert>
              <AlertDescription>
                Este profesor ya es director del grupo {selectedTeacherDetails.directorOf}
              </AlertDescription>
            </Alert>
          )}
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancelar
          </Button>
          <Button className="bg-[#1E40AF]" onClick={handleAssign} disabled={!selectedTeacher || !selectedSubject}>
            <Check className="mr-2 h-4 w-4" />
            Confirmar Asignación
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

