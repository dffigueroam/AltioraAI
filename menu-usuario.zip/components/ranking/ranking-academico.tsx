"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ArrowUpRight, ArrowRight, Check, FileSpreadsheet, ChevronDown } from "lucide-react"

interface Student {
  position: number
  name: string
  grade: string
  average: number
  saberScore: {
    score: number
    percentile: number
  }
  evolution: number
  interaction: number
  planResponse: number
  emotionalState: "Alta" | "Media-Alta" | "Media" | "Media-Baja" | "Baja"
  trend: "Mejorando" | "Estable" | "Decreciendo"
  overallScore: number
  status: string
}

const mockStudents: Student[] = [
  {
    position: 1,
    name: "Ana García",
    grade: "10A",
    average: 9.8,
    saberScore: {
      score: 9.1,
      percentile: 98,
    },
    evolution: 95,
    interaction: 98,
    planResponse: 98,
    emotionalState: "Alta",
    trend: "Mejorando",
    overallScore: 98,
    status: "Excelente",
  },
  {
    position: 2,
    name: "Carlos Rodríguez",
    grade: "11B",
    average: 9.7,
    saberScore: {
      score: 8.7,
      percentile: 92,
    },
    evolution: 92,
    interaction: 95,
    planResponse: 94,
    emotionalState: "Media-Alta",
    trend: "Estable",
    overallScore: 95,
    status: "Muy Bueno",
  },
  {
    position: 3,
    name: "María López",
    grade: "10A",
    average: 9.5,
    saberScore: {
      score: 8.4,
      percentile: 88,
    },
    evolution: 88,
    interaction: 90,
    planResponse: 89,
    emotionalState: "Media",
    trend: "Mejorando",
    overallScore: 96,
    status: "Bueno",
  },
]

const rankingTypes = [
  { value: "academico", label: "Académico" },
  { value: "bienestar", label: "Bienestar Emocional" },
  { value: "evolucion", label: "Evolución y Mejora" },
  { value: "interaccion", label: "Calidad de Interacciones" },
  { value: "planes", label: "Respuesta a Planes" },
  { value: "general", label: "Ranking General" },
]

export function RankingAcademico() {
  const [selectedRanking, setSelectedRanking] = useState("academico")

  const getBadgeColor = (value: number) => {
    if (value >= 95) return "bg-green-100 text-green-800"
    if (value >= 90) return "bg-blue-100 text-blue-800"
    return "bg-yellow-100 text-yellow-800"
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Alta":
        return <Badge className="bg-green-100 text-green-800">Alta</Badge>
      case "Media-Alta":
        return <Badge className="bg-blue-100 text-blue-800">Media-Alta</Badge>
      case "Media":
        return <Badge className="bg-yellow-100 text-yellow-800">Media</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getTrendBadge = (trend: string) => {
    switch (trend) {
      case "Mejorando":
        return (
          <div className="flex items-center gap-1 text-green-600">
            <ArrowUpRight className="h-4 w-4" />
            <span>Mejorando</span>
          </div>
        )
      case "Estable":
        return (
          <div className="flex items-center gap-1 text-blue-600">
            <ArrowRight className="h-4 w-4" />
            <span>Estable</span>
          </div>
        )
      default:
        return trend
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl font-bold text-[#1E40AF]">Ranking de Alumnos</CardTitle>
            <CardDescription>Desempeño académico y bienestar emocional de los estudiantes</CardDescription>
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedRanking} onValueChange={setSelectedRanking}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Seleccionar ranking" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {rankingTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.value === selectedRanking && <Check className="mr-2 h-4 w-4" />}
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              Exportar a Excel
            </Button>
            <Button className="gap-2 bg-[#1E40AF]">Ver Reporte Completo</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[80px]">Posición</TableHead>
              <TableHead>Estudiante</TableHead>
              <TableHead>Grado</TableHead>
              <TableHead>Promedio</TableHead>
              <TableHead className="text-center">
                Pruebas Saber
                <ChevronDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead className="text-center">Evolución</TableHead>
              <TableHead className="text-center">Interacción</TableHead>
              <TableHead className="text-center">Resp. Planes</TableHead>
              <TableHead className="text-center">Est. Emocional</TableHead>
              <TableHead>Tendencia</TableHead>
              <TableHead className="text-right">Calificación</TableHead>
              <TableHead className="text-right">Estado</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockStudents.map((student) => (
              <TableRow key={student.position}>
                <TableCell className="font-medium">{student.position}</TableCell>
                <TableCell>{student.name}</TableCell>
                <TableCell>{student.grade}</TableCell>
                <TableCell>{student.average}</TableCell>
                <TableCell>
                  <div className="text-center">
                    <div>{student.saberScore.score}</div>
                    <div className="text-sm text-gray-500">Percentil {student.saberScore.percentile}</div>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className={getBadgeColor(student.evolution)}>{student.evolution}%</Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className={getBadgeColor(student.interaction)}>{student.interaction}%</Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className={getBadgeColor(student.planResponse)}>{student.planResponse}%</Badge>
                </TableCell>
                <TableCell className="text-center">{getStatusBadge(student.emotionalState)}</TableCell>
                <TableCell>{getTrendBadge(student.trend)}</TableCell>
                <TableCell className="text-right">{student.overallScore}%</TableCell>
                <TableCell className="text-right">
                  <Badge variant="outline">{student.status}</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

