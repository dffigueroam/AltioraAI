"use client"

import { useAuth } from "@/lib/hooks/use-auth"

export const useSession = () => {
  const { user } = useAuth()
  return { user }
}

