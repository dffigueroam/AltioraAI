"use client"

import { useState, useEffect } from "react"

interface ClassroomSelectorProps {
  onSelectClassroom: (classroomId: string) => void
  assignedClassroom?: string
  teachingClassrooms: string[]
  isDirectorGrupo: boolean
}

export function ClassroomSelector({
  onSelectClassroom,
  assignedClassroom,
  teachingClassrooms,
  isDirectorGrupo,
}: ClassroomSelectorProps) {
  const [selectedClassroom, setSelectedClassroom] = useState(assignedClassroom || teachingClassrooms[0] || "")
  const classrooms = [
    "2A",
    "2B",
    "3A",
    "3B",
    "4A",
    "4B",
    "5A",
    "5B",
    "6A",
    "6B",
    "7A",
    "7B",
    "8A",
    "8B",
    "9A",
    "9B",
    "10A",
    "10B",
    "11A",
    "11B",
  ]

  useEffect(() => {
    if (selectedClassroom) {
      onSelectClassroom(selectedClassroom)
    }
  }, [selectedClassroom, onSelectClassroom])

  const handleClassroomChange = (classroomId: string) => {
    setSelectedClassroom(classroomId)
    onSelectClassroom(classroomId)
  }

  const getButtonStyle = (classroom: string) => {
    const isSelected = selectedClassroom === classroom
    const isDirectorClassroom = classroom === assignedClassroom
    const isTeachingClassroom = teachingClassrooms.includes(classroom)

    if (isSelected) {
      return "bg-[#1E40AF] text-white"
    }
    if (isDirectorClassroom) {
      return "bg-[#EC4899] text-white"
    }
    if (isTeachingClassroom) {
      return "bg-white text-[#1E40AF] border-2 border-[#3B82F6]"
    }
    return "bg-gray-100 text-gray-400 cursor-not-allowed"
  }

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-[#EC4899] rounded-full"></div>
          <span className="text-sm text-slate-600">Grupo que diriges</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-[#1E40AF] rounded-full"></div>
          <span className="text-sm text-slate-600">Grupo seleccionado</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border-2 border-[#3B82F6] rounded-full"></div>
          <span className="text-sm text-slate-600">Grupos a los que das clase</span>
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
        {classrooms.map((classroom) => {
          const isTeachingClassroom = teachingClassrooms.includes(classroom)
          const isDirectorClassroom = classroom === assignedClassroom

          return (
            <button
              key={classroom}
              className={`
                px-4 py-2 rounded transition-colors relative
                ${getButtonStyle(classroom)}
                ${!isTeachingClassroom && !isDirectorClassroom ? "opacity-50" : "hover:opacity-90"}
              `}
              onClick={() => handleClassroomChange(classroom)}
              disabled={!isTeachingClassroom && !isDirectorClassroom}
            >
              {classroom}
              {isDirectorClassroom && (
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#EC4899] rounded-full border-2 border-white"></span>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}

