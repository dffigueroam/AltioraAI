"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

// Esquema de validación para el formulario
const eventoPsicologicoSchema = z.object({
  titulo: z.string().min(3, { message: "El título debe tener al menos 3 caracteres" }),
  fecha: z.string().min(1, { message: "La fecha es requerida" }),
  hora: z.string().min(1, { message: "La hora es requerida" }),
  lugar: z.string().min(3, { message: "El lugar debe tener al menos 3 caracteres" }),
  descripcion: z.string().min(10, { message: "La descripción debe tener al menos 10 caracteres" }),
  tipo: z.enum(["terapia", "taller", "evaluacion", "psicologico"]),
  estudiante: z.string().optional(),
  duracion: z.string().optional(),
})

type EventoPsicologicoFormValues = z.infer<typeof eventoPsicologicoSchema>

interface AgregarEventoPsicologicoFormProps {
  onSubmit: (data: EventoPsicologicoFormValues) => void
  onCancel: () => void
}

export function AgregarEventoPsicologicoForm({ onSubmit, onCancel }: AgregarEventoPsicologicoFormProps) {
  const [tipoEvento, setTipoEvento] = useState<string>("terapia")

  // Lista de estudiantes para el selector (simulada)
  const estudiantes = [
    { id: "1", nombre: "Carlos Gómez", curso: "4º ESO A" },
    { id: "2", nombre: "Ana Martínez", curso: "3º ESO B" },
    { id: "3", nombre: "Laura Sánchez", curso: "2º ESO C" },
    { id: "4", nombre: "Miguel Fernández", curso: "1º ESO A" },
    { id: "5", nombre: "Elena Ruiz", curso: "2º ESO B" },
    { id: "6", nombre: "Javier Torres", curso: "1º ESO C" },
  ]

  // Inicializar el formulario con valores predeterminados
  const form = useForm<EventoPsicologicoFormValues>({
    resolver: zodResolver(eventoPsicologicoSchema),
    defaultValues: {
      titulo: "",
      fecha: new Date().toISOString().split("T")[0],
      hora: "09:00",
      lugar: "Despacho de Orientación",
      descripcion: "",
      tipo: "terapia",
      duracion: "45",
    },
  })

  // Manejar el cambio de tipo de evento
  const handleTipoChange = (value: string) => {
    setTipoEvento(value)
    form.setValue("tipo", value as "terapia" | "taller" | "evaluacion" | "psicologico")

    // Ajustar título y lugar según el tipo
    if (value === "terapia") {
      const estudiante = form.getValues("estudiante")
      if (estudiante) {
        const estudianteSeleccionado = estudiantes.find((e) => e.id === estudiante)
        if (estudianteSeleccionado) {
          form.setValue("titulo", `Sesión individual - ${estudianteSeleccionado.nombre}`)
        }
      }
      form.setValue("lugar", "Despacho de Orientación")
    } else if (value === "taller") {
      form.setValue("titulo", "Taller de ")
      form.setValue("lugar", "Aula de Apoyo")
    } else if (value === "evaluacion") {
      const estudiante = form.getValues("estudiante")
      if (estudiante) {
        const estudianteSeleccionado = estudiantes.find((e) => e.id === estudiante)
        if (estudianteSeleccionado) {
          form.setValue("titulo", `Evaluación psicológica - ${estudianteSeleccionado.nombre}`)
        }
      }
      form.setValue("lugar", "Despacho de Orientación")
    } else if (value === "psicologico") {
      form.setValue("titulo", "Reunión ")
      form.setValue("lugar", "Sala de Reuniones")
    }
  }

  // Manejar el cambio de estudiante
  const handleEstudianteChange = (value: string) => {
    form.setValue("estudiante", value)

    // Actualizar título según el tipo y estudiante seleccionado
    const tipo = form.getValues("tipo")
    const estudianteSeleccionado = estudiantes.find((e) => e.id === value)

    if (estudianteSeleccionado) {
      if (tipo === "terapia") {
        form.setValue("titulo", `Sesión individual - ${estudianteSeleccionado.nombre}`)
      } else if (tipo === "evaluacion") {
        form.setValue("titulo", `Evaluación psicológica - ${estudianteSeleccionado.nombre}`)
      } else if (tipo === "psicologico") {
        form.setValue("titulo", `Reunión con padres - ${estudianteSeleccionado.nombre}`)
      }
    }
  }

  // Manejar el envío del formulario
  const handleFormSubmit = (data: EventoPsicologicoFormValues) => {
    onSubmit({
      ...data,
      estado: "programado",
      createdBy: "psicologo",
    })
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="tipo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tipo de Evento</FormLabel>
                <Select onValueChange={handleTipoChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione el tipo de evento" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="terapia">Sesión Terapéutica</SelectItem>
                    <SelectItem value="taller">Taller Grupal</SelectItem>
                    <SelectItem value="evaluacion">Evaluación Psicológica</SelectItem>
                    <SelectItem value="psicologico">Reunión</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {(tipoEvento === "terapia" || tipoEvento === "evaluacion" || tipoEvento === "psicologico") && (
            <FormField
              control={form.control}
              name="estudiante"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Estudiante</FormLabel>
                  <Select onValueChange={handleEstudianteChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccione un estudiante" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {estudiantes.map((estudiante) => (
                        <SelectItem key={estudiante.id} value={estudiante.id}>
                          {estudiante.nombre} - {estudiante.curso}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="titulo"
            render={({ field }) => (
              <FormItem className="col-span-2">
                <FormLabel>Título del Evento</FormLabel>
                <FormControl>
                  <Input placeholder="Ej: Sesión individual - Carlos Gómez" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="fecha"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fecha</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="hora"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Hora</FormLabel>
                <FormControl>
                  <Input type="time" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="duracion"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Duración (minutos)</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione la duración" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="30">30 minutos</SelectItem>
                    <SelectItem value="45">45 minutos</SelectItem>
                    <SelectItem value="60">60 minutos</SelectItem>
                    <SelectItem value="90">90 minutos</SelectItem>
                    <SelectItem value="120">120 minutos</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="lugar"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Lugar</FormLabel>
                <FormControl>
                  <Input placeholder="Ej: Despacho de Orientación" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="descripcion"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descripción</FormLabel>
              <FormControl>
                <Textarea placeholder="Describa los detalles del evento..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button type="submit" className="bg-[#1E40AF]">
            Agendar Evento
          </Button>
        </div>
      </form>
    </Form>
  )
}

