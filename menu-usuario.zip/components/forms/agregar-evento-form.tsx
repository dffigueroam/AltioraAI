"use client"

import { useState, useEffect } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

// Esquema de validación para el formulario
const eventoSchema = z.object({
  titulo: z.string().min(3, { message: "El título debe tener al menos 3 caracteres" }),
  fecha: z.string().min(1, { message: "La fecha es requerida" }),
  hora: z.string().min(1, { message: "La hora es requerida" }),
  lugar: z.string().min(3, { message: "El lugar debe tener al menos 3 caracteres" }),
  descripcion: z.string().min(10, { message: "La descripción debe tener al menos 10 caracteres" }),
  tipo: z.enum(["academico", "administrativo", "competencia", "evaluacion"]),
  categoria: z.string().optional(),
  deporte: z.string().optional(),
})

type EventoFormValues = z.infer<typeof eventoSchema>

interface AgregarEventoFormProps {
  onSubmit: (data: EventoFormValues) => void
  onCancel: () => void
}

export function AgregarEventoForm({ onSubmit, onCancel }: AgregarEventoFormProps) {
  const [tipoEvento, setTipoEvento] = useState<string>("academico")

  // Inicializar el formulario con valores predeterminados
  const form = useForm<EventoFormValues>({
    resolver: zodResolver(eventoSchema),
    defaultValues: {
      titulo: "",
      fecha: new Date().toISOString().split("T")[0],
      hora: "08:00",
      lugar: "",
      descripcion: "",
      tipo: "academico",
    },
  })

  // Manejar el cambio de tipo de evento
  const handleTipoChange = (value: string) => {
    setTipoEvento(value)
    form.setValue("tipo", value as "academico" | "administrativo" | "competencia" | "evaluacion")

    // Si cambia a un tipo que no requiere categoría o deporte, limpiar esos campos
    if (value === "academico" || value === "administrativo") {
      form.setValue("categoria", undefined)
      form.setValue("deporte", undefined)
    } else {
      // Si cambia a un tipo deportivo, establecer valores predeterminados
      if (!form.getValues("categoria")) {
        form.setValue("categoria", "General")
      }
      if (!form.getValues("deporte")) {
        form.setValue("deporte", "Múltiple")
      }
    }
  }

  // Manejar el envío del formulario
  const handleFormSubmit = (data: EventoFormValues) => {
    // Asegurarse de que los campos opcionales estén presentes si son necesarios
    if (data.tipo === "competencia" || data.tipo === "evaluacion") {
      if (!data.categoria) data.categoria = "General"
      if (!data.deporte) data.deporte = "Múltiple"
    }

    onSubmit(data)
  }

  // Efecto para manejar cambios en el tipo de evento
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === "tipo") {
        setTipoEvento(value.tipo as string)
      }
    })

    return () => subscription.unsubscribe()
  }, [form])

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="titulo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Título del Evento</FormLabel>
                <FormControl>
                  <Input placeholder="Ej: Exposición de Ciencias" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="tipo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tipo de Evento</FormLabel>
                <Select onValueChange={handleTipoChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione el tipo de evento" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="academico">Académico</SelectItem>
                    <SelectItem value="administrativo">Administrativo</SelectItem>
                    <SelectItem value="competencia">Competencia Deportiva</SelectItem>
                    <SelectItem value="evaluacion">Evaluación Deportiva</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="fecha"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fecha</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="hora"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Hora</FormLabel>
                <FormControl>
                  <Input type="time" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="lugar"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Lugar</FormLabel>
                <FormControl>
                  <Input placeholder="Ej: Auditorio Principal" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {(tipoEvento === "competencia" || tipoEvento === "evaluacion") && (
            <>
              <FormField
                control={form.control}
                name="categoria"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categoría</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccione la categoría" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Sub-12">Sub-12</SelectItem>
                        <SelectItem value="Sub-15">Sub-15</SelectItem>
                        <SelectItem value="Sub-17">Sub-17</SelectItem>
                        <SelectItem value="Juvenil">Juvenil</SelectItem>
                        <SelectItem value="General">General</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="deporte"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deporte</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccione el deporte" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Fútbol">Fútbol</SelectItem>
                        <SelectItem value="Baloncesto">Baloncesto</SelectItem>
                        <SelectItem value="Voleibol">Voleibol</SelectItem>
                        <SelectItem value="Natación">Natación</SelectItem>
                        <SelectItem value="Atletismo">Atletismo</SelectItem>
                        <SelectItem value="Múltiple">Múltiple</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </>
          )}
        </div>

        <FormField
          control={form.control}
          name="descripcion"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descripción</FormLabel>
              <FormControl>
                <Textarea placeholder="Describa los detalles del evento..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button type="submit" className="bg-[#1E40AF]">
            Guardar Evento
          </Button>
        </div>
      </form>
    </Form>
  )
}

