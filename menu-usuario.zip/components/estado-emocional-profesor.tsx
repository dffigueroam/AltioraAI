"use client"

import { useState } from "react"
import {
  AlertTriangle,
  Clock,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  AlertCircle,
  Mail,
  Phone,
  UserCheck,
  UserPlus,
  Filter,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { toast } from "@/components/ui/use-toast"

// Tipos de estados emocionales
const EmotionalStateType = {
  STRESS: "Estrés Pre-Evento",
  ANXIETY: "Ansiedad Pre-Evento",
  LEARNING_STYLE: "Estilo de Aprendizaje",
  MOTIVATION: "Baja Motivación",
  CONFLICT: "Conflicto Social",
  ATTENTION: "Déficit de Atención",
}

// Niveles de atención
const AttentionLevel = {
  URGENT: "Requiere atención inmediata",
  FOLLOW_UP: "Necesita seguimiento",
  NORMAL: "Estado normal",
  IMPROVED: "Ha mejorado",
}

// Tipos de asignación
const AssignmentType = {
  UNASSIGNED: "Sin asignar",
  TEACHER: "Profesor",
  PSYCHOLOGIST: "Psicólogo",
  COUNSELOR: "Orientador",
}

// Datos de ejemplo
const studentData = [
  {
    id: 1,
    name: "Ana García",
    state: EmotionalStateType.STRESS,
    date: "24/12/2024",
    attentionLevel: AttentionLevel.URGENT,
    recommendation: "Programar una reunión con el estudiante y el departamento de orientación.",
    assignedTo: AssignmentType.UNASSIGNED,
    notes: [
      {
        date: "20/12/2024",
        author: "María González (Profesora)",
        text: "Ana ha mostrado signos de estrés durante la última semana. Parece estar preocupada por los exámenes finales.",
      },
      {
        date: "22/12/2024",
        author: "Carlos Ruiz (Psicólogo)",
        text: "Tuve una breve conversación con Ana. Confirma que está estresada por los exámenes y también menciona problemas familiares.",
      },
    ],
    guardian: {
      name: "Laura García",
      relation: "Madre",
      phone: "+57 300 123 4567",
      email: "laura.garcia@example.com",
      address: "Calle 123 #45-67, Bogotá",
    },
  },
  {
    id: 2,
    name: "Carlos Rodríguez",
    state: EmotionalStateType.ANXIETY,
    date: "23/2/2024",
    attentionLevel: AttentionLevel.FOLLOW_UP,
    recommendation: "Hacer seguimiento del progreso en las próximas semanas.",
    assignedTo: AssignmentType.TEACHER,
    notes: [
      {
        date: "15/2/2024",
        author: "María González (Profesora)",
        text: "Carlos parece ansioso durante las presentaciones en clase. Se pone muy nervioso cuando tiene que hablar en público.",
      },
    ],
    guardian: {
      name: "Luisa Rodriguez",
      relation: "Madre",
      phone: "+57 311 222 3344",
      email: "luisa.rodriguez@example.com",
      address: "Carrera 456 #78-90, Medellín",
    },
  },
  {
    id: 3,
    name: "María López",
    state: EmotionalStateType.LEARNING_STYLE,
    date: "22/2/2024",
    attentionLevel: AttentionLevel.NORMAL,
    recommendation: "Continuar con el enfoque actual de aprendizaje visual.",
    assignedTo: AssignmentType.UNASSIGNED,
    notes: [],
    guardian: {
      name: "Sofia López",
      relation: "Tía",
      phone: "+57 322 555 6677",
      email: "sofia.lopez@example.com",
      address: "Avenida 789 #12-34, Cali",
    },
  },
  {
    id: 4,
    name: "Pedro Sánchez",
    state: EmotionalStateType.MOTIVATION,
    date: "20/2/2024",
    attentionLevel: AttentionLevel.FOLLOW_UP,
    recommendation: "Implementar estrategias de motivación y reconocimiento.",
    assignedTo: AssignmentType.PSYCHOLOGIST,
    notes: [
      {
        date: "18/2/2024",
        author: "María González (Profesora)",
        text: "Pedro ha mostrado poco interés en las actividades de clase durante las últimas semanas.",
      },
    ],
    guardian: {
      name: "Ricardo Sánchez",
      relation: "Padre",
      phone: "+57 301 888 9900",
      email: "ricardo.sanchez@example.com",
      address: "Diagonal 012 #34-56, Barranquilla",
    },
  },
  {
    id: 5,
    name: "Laura Martínez",
    state: EmotionalStateType.CONFLICT,
    date: "19/2/2024",
    attentionLevel: AttentionLevel.URGENT,
    recommendation: "Programar una mediación con los estudiantes involucrados.",
    assignedTo: AssignmentType.PSYCHOLOGIST,
    notes: [
      {
        date: "17/2/2024",
        author: "María González (Profesora)",
        text: "Laura ha tenido conflictos con otros estudiantes durante el recreo.",
      },
      {
        date: "18/2/2024",
        author: "Carlos Ruiz (Psicólogo)",
        text: "He hablado con Laura sobre los conflictos. Parece haber un malentendido con sus compañeros.",
      },
    ],
    guardian: {
      name: "Elena Martínez",
      relation: "Abuela",
      phone: "+57 310 444 7788",
      email: "elena.martinez@example.com",
      address: "Transversal 234 #56-78, Cartagena",
    },
  },
]

interface EstadoEmocionalProfesorProps {
  className?: string
  groupId: string
  userName: string
}

export function EstadoEmocionalProfesor({ className, groupId, userName }: EstadoEmocionalProfesorProps) {
  const [students, setStudents] = useState(studentData)
  const [selectedStudent, setSelectedStudent] = useState<any>(null)
  const [newNote, setNewNote] = useState("")
  const [newStatus, setNewStatus] = useState("")
  const [newAssignment, setNewAssignment] = useState("")
  const [filter, setFilter] = useState("all")
  const [showAssignmentDialog, setShowAssignmentDialog] = useState(false)

  const urgentCount = students.filter((s) => s.attentionLevel === AttentionLevel.URGENT).length
  const followUpCount = students.filter((s) => s.attentionLevel === AttentionLevel.FOLLOW_UP).length
  const assignedToTeacher = students.filter((s) => s.assignedTo === AssignmentType.TEACHER).length
  const assignedToPsychologist = students.filter((s) => s.assignedTo === AssignmentType.PSYCHOLOGIST).length

  const handleAddNote = () => {
    if (!newNote.trim()) return

    const updatedStudents = students.map((student) => {
      if (student.id === selectedStudent.id) {
        return {
          ...student,
          notes: [
            ...student.notes,
            {
              date: new Date().toLocaleDateString("es-ES"),
              author: `${userName} (Profesora)`,
              text: newNote,
            },
          ],
        }
      }
      return student
    })

    setStudents(updatedStudents)
    setNewNote("")

    // Actualizar el estudiante seleccionado para reflejar los cambios
    const updatedStudent = updatedStudents.find((s) => s.id === selectedStudent.id)
    setSelectedStudent(updatedStudent)

    toast({
      title: "Nota añadida",
      description: "La nota ha sido añadida correctamente",
    })
  }

  const handleUpdateStatus = () => {
    if (!newStatus) return

    const updatedStudents = students.map((student) => {
      if (student.id === selectedStudent.id) {
        return {
          ...student,
          attentionLevel: newStatus,
          notes: [
            ...student.notes,
            {
              date: new Date().toLocaleDateString("es-ES"),
              author: `${userName} (Profesora)`,
              text: `Estado actualizado a: ${newStatus}`,
            },
          ],
        }
      }
      return student
    })

    setStudents(updatedStudents)
    setNewStatus("")

    // Actualizar el estudiante seleccionado para reflejar los cambios
    const updatedStudent = updatedStudents.find((s) => s.id === selectedStudent.id)
    setSelectedStudent(updatedStudent)

    toast({
      title: "Estado actualizado",
      description: "El estado del estudiante ha sido actualizado correctamente",
    })
  }

  const handleAssignment = () => {
    if (!newAssignment) return

    const updatedStudents = students.map((student) => {
      if (student.id === selectedStudent.id) {
        return {
          ...student,
          assignedTo: newAssignment,
          notes: [
            ...student.notes,
            {
              date: new Date().toLocaleDateString("es-ES"),
              author: `${userName} (Profesora)`,
              text: `Caso asignado a: ${newAssignment}`,
            },
          ],
        }
      }
      return student
    })

    setStudents(updatedStudents)
    setNewAssignment("")
    setShowAssignmentDialog(false)

    toast({
      title: "Caso asignado",
      description: `El caso ha sido asignado a ${newAssignment}`,
    })
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case AttentionLevel.URGENT:
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case AttentionLevel.FOLLOW_UP:
        return <Clock className="h-5 w-5 text-yellow-500" />
      case AttentionLevel.NORMAL:
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case AttentionLevel.IMPROVED:
        return <ArrowUp className="h-5 w-5 text-blue-500" />
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case AttentionLevel.URGENT:
        return "bg-red-100 text-red-800"
      case AttentionLevel.FOLLOW_UP:
        return "bg-yellow-100 text-yellow-800"
      case AttentionLevel.NORMAL:
        return "bg-green-100 text-green-800"
      case AttentionLevel.IMPROVED:
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getAssignmentIcon = (assignment: string) => {
    switch (assignment) {
      case AssignmentType.TEACHER:
        return <UserCheck className="h-4 w-4 text-blue-500" />
      case AssignmentType.PSYCHOLOGIST:
        return <UserPlus className="h-4 w-4 text-purple-500" />
      case AssignmentType.COUNSELOR:
        return <UserCheck className="h-4 w-4 text-green-500" />
      default:
        return null
    }
  }

  const getAssignmentBadge = (assignment: string) => {
    switch (assignment) {
      case AssignmentType.TEACHER:
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Asignado a Profesor
          </Badge>
        )
      case AssignmentType.PSYCHOLOGIST:
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">
            Asignado a Psicólogo
          </Badge>
        )
      case AssignmentType.COUNSELOR:
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Asignado a Orientador
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
            Sin asignar
          </Badge>
        )
    }
  }

  const filteredStudents = students.filter((student) => {
    if (filter === "all") return true
    if (filter === "teacher") return student.assignedTo === AssignmentType.TEACHER
    if (filter === "psychologist") return student.assignedTo === AssignmentType.PSYCHOLOGIST
    if (filter === "unassigned") return student.assignedTo === AssignmentType.UNASSIGNED
    return true
  })

  return (
    <div className={className}>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Acciones Pendientes</h1>
        <p className="text-muted-foreground">
          Estudiantes que requieren atención especial basada en su estado emocional y académico
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-4 mb-6">
        <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
          {urgentCount} Urgentes
        </Badge>
        <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
          {followUpCount} Atención
        </Badge>
        <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
          {assignedToTeacher} Asignados a mí
        </Badge>
        <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-100">
          {assignedToPsychologist} Asignados a Psicólogo
        </Badge>
      </div>

      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Estado Emocional Alumnos - {groupId}</CardTitle>
            <CardDescription>Resultados recientes de evaluaciones emocionales y estilos de aprendizaje</CardDescription>
          </div>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Filter className="h-4 w-4" />
                Filtrar
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56">
              <div className="space-y-2">
                <h4 className="font-medium">Filtrar por asignación</h4>
                <div className="flex flex-col gap-2">
                  <Button
                    variant={filter === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilter("all")}
                    className="justify-start"
                  >
                    Todos los casos
                  </Button>
                  <Button
                    variant={filter === "teacher" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilter("teacher")}
                    className="justify-start"
                  >
                    <UserCheck className="h-4 w-4 mr-2 text-blue-500" />
                    Asignados a mí
                  </Button>
                  <Button
                    variant={filter === "psychologist" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilter("psychologist")}
                    className="justify-start"
                  >
                    <UserPlus className="h-4 w-4 mr-2 text-purple-500" />
                    Asignados a Psicólogo
                  </Button>
                  <Button
                    variant={filter === "unassigned" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilter("unassigned")}
                    className="justify-start"
                  >
                    Sin asignar
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredStudents.map((student) => (
              <Dialog key={student.id}>
                <DialogTrigger asChild>
                  <div
                    className={`p-4 rounded-lg cursor-pointer ${
                      student.attentionLevel === AttentionLevel.URGENT
                        ? "bg-red-50"
                        : student.attentionLevel === AttentionLevel.FOLLOW_UP
                          ? "bg-yellow-50"
                          : "bg-green-50"
                    }`}
                    onClick={() => setSelectedStudent(student)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        {student.attentionLevel === AttentionLevel.URGENT ? (
                          <AlertTriangle className="h-5 w-5 text-red-500 mt-1" />
                        ) : student.attentionLevel === AttentionLevel.FOLLOW_UP ? (
                          <Clock className="h-5 w-5 text-yellow-500 mt-1" />
                        ) : (
                          <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                        )}
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{student.name}</h3>
                            {getAssignmentIcon(student.assignedTo)}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>{student.state}</span>
                            <span>•</span>
                            <span>{student.date}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        {student.attentionLevel === AttentionLevel.URGENT ? (
                          <span className="text-red-500 flex items-center">
                            <ArrowDown className="h-4 w-4 mr-1" />
                            Requiere atención inmediata
                          </span>
                        ) : student.attentionLevel === AttentionLevel.FOLLOW_UP ? (
                          <span className="text-yellow-500 flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            Necesita seguimiento
                          </span>
                        ) : (
                          <span className="text-green-500 flex items-center">
                            <ArrowUp className="h-4 w-4 mr-1" />
                            Estado normal
                          </span>
                        )}
                        {getAssignmentBadge(student.assignedTo)}
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm">
                        <span className="font-medium">Recomendación:</span> {student.recommendation}
                      </p>
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle className="text-xl">{student.name}</DialogTitle>
                    <DialogDescription>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className={getStatusColor(student.attentionLevel)}>
                          {student.attentionLevel}
                        </Badge>
                        <span>•</span>
                        <span>{student.state}</span>
                        <span>•</span>
                        <span>Fecha de registro: {student.date}</span>
                      </div>
                    </DialogDescription>
                  </DialogHeader>

                  <Tabs defaultValue="details">
                    <TabsList className="mb-4">
                      <TabsTrigger value="details">Detalles</TabsTrigger>
                      <TabsTrigger value="history">Historial de Notas</TabsTrigger>
                      <TabsTrigger value="actions">Acciones</TabsTrigger>
                      <TabsTrigger value="guardian">Acudiente</TabsTrigger>
                    </TabsList>

                    <TabsContent value="details">
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-1">Recomendación</h3>
                          <p>{student.recommendation}</p>
                        </div>

                        <div>
                          <h3 className="font-medium mb-1">Estado Actual</h3>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(student.attentionLevel)}
                            <span>{student.attentionLevel}</span>
                          </div>
                        </div>

                        <div>
                          <h3 className="font-medium mb-1">Tipo de Situación</h3>
                          <p>{student.state}</p>
                        </div>

                        <div>
                          <h3 className="font-medium mb-1">Asignado a</h3>
                          <div className="flex items-center gap-2">
                            {getAssignmentIcon(student.assignedTo)}
                            <span>{student.assignedTo}</span>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2"
                            onClick={() => {
                              setNewAssignment(student.assignedTo)
                              setShowAssignmentDialog(true)
                            }}
                          >
                            Cambiar asignación
                          </Button>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="history">
                      <div className="space-y-4">
                        {student.notes && student.notes.length > 0 ? (
                          student.notes.map((note, index) => (
                            <div key={index} className="border rounded-lg p-3">
                              <div className="flex justify-between items-center mb-1">
                                <span className="font-medium">{note.author}</span>
                                <span className="text-sm text-muted-foreground">{note.date}</span>
                              </div>
                              <p>{note.text}</p>
                            </div>
                          ))
                        ) : (
                          <p className="text-muted-foreground">No hay notas registradas.</p>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="actions">
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-2">Agregar Nota</h3>
                          <Textarea
                            placeholder="Escribe una nota sobre el estudiante..."
                            value={newNote}
                            onChange={(e) => setNewNote(e.target.value)}
                            className="mb-2"
                          />
                          <Button onClick={handleAddNote}>Guardar Nota</Button>
                        </div>

                        <div className="border-t pt-4">
                          <h3 className="font-medium mb-2">Actualizar Estado</h3>
                          <div className="flex gap-2">
                            <Select value={newStatus} onValueChange={setNewStatus}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Seleccionar nuevo estado" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value={AttentionLevel.URGENT}>Requiere atención inmediata</SelectItem>
                                <SelectItem value={AttentionLevel.FOLLOW_UP}>Necesita seguimiento</SelectItem>
                                <SelectItem value={AttentionLevel.NORMAL}>Estado normal</SelectItem>
                                <SelectItem value={AttentionLevel.IMPROVED}>Ha mejorado</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button onClick={handleUpdateStatus}>Actualizar</Button>
                          </div>
                        </div>

                        <div className="border-t pt-4">
                          <h3 className="font-medium mb-2">Asignación del Caso</h3>
                          <div className="flex gap-2">
                            <Button
                              variant={student.assignedTo === AssignmentType.TEACHER ? "default" : "outline"}
                              className="flex-1"
                              onClick={() => {
                                setNewAssignment(AssignmentType.TEACHER)
                                setShowAssignmentDialog(true)
                              }}
                            >
                              <UserCheck className="h-4 w-4 mr-2" />
                              Asignarme el caso
                            </Button>
                            <Button
                              variant={student.assignedTo === AssignmentType.PSYCHOLOGIST ? "default" : "outline"}
                              className="flex-1"
                              onClick={() => {
                                setNewAssignment(AssignmentType.PSYCHOLOGIST)
                                setShowAssignmentDialog(true)
                              }}
                            >
                              <UserPlus className="h-4 w-4 mr-2" />
                              Derivar a Psicólogo
                            </Button>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="guardian">
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h3 className="font-medium mb-2">Información del Acudiente</h3>
                            <div className="space-y-2">
                              <p>
                                <span className="font-medium">Nombre:</span> {student.guardian.name}
                              </p>
                              <p>
                                <span className="font-medium">Relación:</span> {student.guardian.relation}
                              </p>
                              <p>
                                <span className="font-medium">Teléfono:</span> {student.guardian.phone}
                              </p>
                              <p>
                                <span className="font-medium">Email:</span> {student.guardian.email}
                              </p>
                              <p>
                                <span className="font-medium">Dirección:</span> {student.guardian.address}
                              </p>
                            </div>
                          </div>
                          <div>
                            <h3 className="font-medium mb-2">Contactar Acudiente</h3>
                            <div className="space-y-2">
                              <Button className="w-full flex items-center justify-center gap-2">
                                <Phone className="h-4 w-4" />
                                Llamar
                              </Button>
                              <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                                <Mail className="h-4 w-4" />
                                Enviar Email
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <DialogFooter className="mt-4">
                    <Button variant="outline">Cerrar</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Diálogo de confirmación de asignación */}
      <Dialog open={showAssignmentDialog} onOpenChange={setShowAssignmentDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirmar Asignación</DialogTitle>
            <DialogDescription>
              {newAssignment === AssignmentType.TEACHER
                ? "¿Estás seguro de que quieres asignarte este caso?"
                : newAssignment === AssignmentType.PSYCHOLOGIST
                  ? "¿Estás seguro de que quieres derivar este caso al psicólogo?"
                  : "¿Estás seguro de que quieres cambiar la asignación de este caso?"}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground">
              {newAssignment === AssignmentType.TEACHER
                ? "Al asignarte este caso, serás responsable de su seguimiento y gestión."
                : newAssignment === AssignmentType.PSYCHOLOGIST
                  ? "Al derivar este caso al psicólogo, él/ella será responsable de su seguimiento y gestión."
                  : "Esta acción cambiará la asignación actual del caso."}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignmentDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAssignment}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

