"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, BookOpen, Calendar, MessageSquare, Award, Settings } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

interface StudentNavigationProps {
  className?: string
}

export function StudentNavigation({ className }: StudentNavigationProps) {
  const pathname = usePathname()
  const [activeTab, setActiveTab] = useState<string>(pathname)

  const routes = [
    {
      href: "/student",
      icon: Home,
      label: "Inicio",
    },
    {
      href: "/student/courses",
      icon: BookOpen,
      label: "Cursos",
    },
    {
      href: "/student/calendar",
      icon: Calendar,
      label: "Calendario",
    },
    {
      href: "/student/messages",
      icon: MessageSquare,
      label: "Mensajes",
    },
    {
      href: "/student/achievements",
      icon: Award,
      label: "Logros",
    },
    {
      href: "/student/settings",
      icon: Settings,
      label: "Configuración",
    },
  ]

  return (
    <ScrollArea className={cn("h-full", className)}>
      <div className="flex flex-col gap-2 p-4">
        {routes.map((route) => (
          <Button
            key={route.href}
            variant={activeTab === route.href ? "default" : "ghost"}
            className={cn("justify-start gap-2")}
            onClick={() => setActiveTab(route.href)}
            asChild
          >
            <Link href={route.href}>
              <route.icon className="h-4 w-4" />
              {route.label}
            </Link>
          </Button>
        ))}
      </div>
    </ScrollArea>
  )
}

