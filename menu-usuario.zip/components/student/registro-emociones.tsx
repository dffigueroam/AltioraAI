"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Definimos los tipos de emociones disponibles
type Emocion = {
  id: string
  nombre: string
  emoji: string
  color: string
}

// Lista de emociones predefinidas
const emociones: Emocion[] = [
  { id: "feliz", nombre: "Feliz", emoji: "😊", color: "bg-green-100 hover:bg-green-200" },
  { id: "tranquilo", nombre: "Tranquilo", emoji: "😌", color: "bg-blue-100 hover:bg-blue-200" },
  { id: "motivado", nombre: "Motivado", emoji: "💪", color: "bg-purple-100 hover:bg-purple-200" },
  { id: "cansado", nombre: "Cansado", emoji: "😴", color: "bg-gray-100 hover:bg-gray-200" },
  { id: "estresado", nombre: "Estresado", emoji: "😓", color: "bg-orange-100 hover:bg-orange-200" },
  { id: "triste", nombre: "Triste", emoji: "😢", color: "bg-indigo-100 hover:bg-indigo-200" },
  { id: "frustrado", nombre: "Frustrado", emoji: "😤", color: "bg-red-100 hover:bg-red-200" },
  { id: "confundido", nombre: "Confundido", emoji: "🤔", color: "bg-yellow-100 hover:bg-yellow-200" },
]

// Tipo para los registros de emociones
type RegistroEmocion = {
  id: string
  fecha: Date
  emocionId: string
  descripcion: string
}

export function RegistroEmociones() {
  const [emocionSeleccionada, setEmocionSeleccionada] = useState<string | null>(null)
  const [descripcion, setDescripcion] = useState("")
  const [registros, setRegistros] = useState<RegistroEmocion[]>([])
  const [activeTab, setActiveTab] = useState("registro")

  // Cargar registros guardados al iniciar
  useEffect(() => {
    const registrosGuardados = localStorage.getItem("registrosEmociones")
    if (registrosGuardados) {
      try {
        // Convertir las fechas de string a Date
        const parsed = JSON.parse(registrosGuardados)
        const registrosConFechas = parsed.map((reg: any) => ({
          ...reg,
          fecha: new Date(reg.fecha),
        }))
        setRegistros(registrosConFechas)
      } catch (error) {
        console.error("Error al cargar registros de emociones:", error)
      }
    }
  }, [])

  // Guardar registros cuando se actualicen
  useEffect(() => {
    if (registros.length > 0) {
      localStorage.setItem("registrosEmociones", JSON.stringify(registros))
    }
  }, [registros])

  const handleGuardarRegistro = () => {
    if (!emocionSeleccionada) return

    const nuevoRegistro: RegistroEmocion = {
      id: Date.now().toString(),
      fecha: new Date(),
      emocionId: emocionSeleccionada,
      descripcion,
    }

    setRegistros([nuevoRegistro, ...registros])
    setEmocionSeleccionada(null)
    setDescripcion("")
    setActiveTab("historial")
  }

  const getEmocionById = (id: string) => {
    return emociones.find((e) => e.id === id) || emociones[0]
  }

  const formatearFecha = (fecha: Date) => {
    return format(fecha, "EEEE, d 'de' MMMM 'a las' HH:mm", { locale: es })
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Registro de Emociones</CardTitle>
        <CardDescription>Comparte cómo te sientes hoy y lleva un registro de tu bienestar emocional</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="registro">Registrar emoción</TabsTrigger>
            <TabsTrigger value="historial">Historial</TabsTrigger>
          </TabsList>

          <TabsContent value="registro" className="space-y-4 pt-4">
            <div>
              <Label className="mb-2 block">¿Cómo te sientes hoy?</Label>
              <div className="grid grid-cols-4 gap-2">
                {emociones.map((emocion) => (
                  <Button
                    key={emocion.id}
                    variant="outline"
                    className={`h-auto flex flex-col p-3 ${emocion.color} ${
                      emocionSeleccionada === emocion.id ? "ring-2 ring-primary" : ""
                    }`}
                    onClick={() => setEmocionSeleccionada(emocion.id)}
                  >
                    <span className="text-2xl mb-1">{emocion.emoji}</span>
                    <span className="text-xs">{emocion.nombre}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">¿Quieres compartir más detalles?</Label>
              <Textarea
                id="descripcion"
                placeholder="Escribe aquí cómo te sientes..."
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                rows={4}
              />
            </div>
          </TabsContent>

          <TabsContent value="historial" className="pt-4">
            {registros.length > 0 ? (
              <div className="space-y-4">
                {registros.map((registro) => {
                  const emocion = getEmocionById(registro.emocionId)
                  return (
                    <Card key={registro.id} className="overflow-hidden">
                      <div className={`p-4 ${emocion.color}`}>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{emocion.emoji}</span>
                          <div>
                            <h4 className="font-medium">{emocion.nombre}</h4>
                            <p className="text-xs text-muted-foreground">{formatearFecha(registro.fecha)}</p>
                          </div>
                        </div>
                        {registro.descripcion && <p className="mt-2 text-sm">{registro.descripcion}</p>}
                      </div>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                Aún no has registrado ninguna emoción. ¡Comienza a registrar cómo te sientes!
              </p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>

      {activeTab === "registro" && (
        <CardFooter>
          <Button onClick={handleGuardarRegistro} disabled={!emocionSeleccionada} className="w-full">
            Guardar registro
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

