"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

type TabOption = {
  id: string
  label: string
  href: string
}

const tabOptions: TabOption[] = [
  { id: "acciones-pendientes", label: "Acciones Pendientes", href: "/dashboard/acciones-pendientes" },
  { id: "eventos", label: "Eventos", href: "/dashboard/eventos" },
  { id: "enlaces-interes", label: "Enlaces de Interés", href: "/dashboard/enlaces-interes" },
  { id: "deportes", label: "Deportes", href: "/dashboard/deportes" },
  { id: "diario-emociones", label: "Diario De Emociones", href: "/dashboard/diario-emociones" },
  { id: "gestion-ia", label: "Gestión sugerida de la IA", href: "/dashboard/gestion-ia" },
]

export function NavegacionInferior() {
  const pathname = usePathname()

  return (
    <div className="border-t">
      <div className="container py-4">
        <nav className="flex flex-wrap justify-center gap-4">
          {tabOptions.map((tab) => {
            const isActive = pathname === tab.href

            return (
              <Link
                key={tab.id}
                href={tab.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  isActive ? "text-primary underline underline-offset-4" : "text-muted-foreground",
                )}
              >
                {tab.label}
              </Link>
            )
          })}
        </nav>
      </div>
    </div>
  )
}

