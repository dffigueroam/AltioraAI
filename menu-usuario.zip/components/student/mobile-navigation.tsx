"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, BookOpen, Calendar, MessageSquare, Heart } from "lucide-react"
import { cn } from "@/lib/utils"

interface MobileNavigationProps {
  className?: string
}

export function MobileNavigation({ className }: MobileNavigationProps) {
  const pathname = usePathname()

  const routes = [
    {
      href: "/student",
      icon: Home,
      label: "Inicio",
    },
    {
      href: "/student/courses",
      icon: BookOpen,
      label: "Cursos",
    },
    {
      href: "/student/calendar",
      icon: Calendar,
      label: "Calendario",
    },
    {
      href: "/student/messages",
      icon: MessageSquare,
      label: "Mensajes",
    },
    {
      href: "/student/diario-emociones",
      icon: Heart,
      label: "Diario",
      highlight: true,
    },
  ]

  return (
    <div className={cn("flex border-t bg-background", className)}>
      {routes.map((route) => (
        <Link
          key={route.href}
          href={route.href}
          className={cn(
            "flex flex-1 flex-col items-center justify-center py-3",
            pathname === route.href ? "text-primary" : "text-muted-foreground hover:text-foreground",
            route.highlight && "text-pink-500 hover:text-pink-700",
          )}
        >
          <route.icon className="h-5 w-5" />
          <span className="text-xs">{route.label}</span>
        </Link>
      ))}
    </div>
  )
}

