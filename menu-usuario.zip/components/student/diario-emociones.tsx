"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { CalendarIcon, PlusCircle, Heart, ThumbsUp, ThumbsDown } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Tipo para los registros de emociones
type EntradaDiario = {
  id: string
  fecha: Date
  titulo: string
  contenido: string
  categoria: string
  sentimiento: "positivo" | "neutral" | "negativo"
}

export function DiarioEmociones() {
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")
  const [categoria, setCategoria] = useState("")
  const [sentimiento, setSentimiento] = useState<"positivo" | "neutral" | "negativo">("neutral")
  const [entradas, setEntradas] = useState<EntradaDiario[]>([])

  // Cargar entradas guardadas al iniciar
  useEffect(() => {
    const entradasGuardadas = localStorage.getItem("diarioEmociones")
    if (entradasGuardadas) {
      try {
        // Convertir las fechas de string a Date
        const parsed = JSON.parse(entradasGuardadas)
        const entradasConFechas = parsed.map((entrada: any) => ({
          ...entrada,
          fecha: new Date(entrada.fecha),
        }))
        setEntradas(entradasConFechas)
      } catch (error) {
        console.error("Error al cargar entradas del diario:", error)
      }
    }
  }, [])

  // Guardar entradas cuando se actualicen
  useEffect(() => {
    if (entradas.length > 0) {
      localStorage.setItem("diarioEmociones", JSON.stringify(entradas))
    }
  }, [entradas])

  const handleGuardarEntrada = () => {
    if (!contenido || !titulo) return

    const nuevaEntrada: EntradaDiario = {
      id: Date.now().toString(),
      fecha: new Date(),
      titulo,
      contenido,
      categoria: categoria || "general",
      sentimiento,
    }

    setEntradas([nuevaEntrada, ...entradas])
    setTitulo("")
    setContenido("")
    setCategoria("")
    setSentimiento("neutral")
    setMostrarFormulario(false)
  }

  const formatearFecha = (fecha: Date) => {
    return format(fecha, "EEEE, d 'de' MMMM 'a las' HH:mm", { locale: es })
  }

  // Agrupar entradas por fecha (día)
  const entradasPorDia = entradas.reduce<Record<string, EntradaDiario[]>>((acc, entrada) => {
    const fechaKey = format(entrada.fecha, "yyyy-MM-dd")
    if (!acc[fechaKey]) {
      acc[fechaKey] = []
    }
    acc[fechaKey].push(entrada)
    return acc
  }, {})

  // Ordenar las fechas de más reciente a más antigua
  const fechasOrdenadas = Object.keys(entradasPorDia).sort((a, b) => b.localeCompare(a))

  // Ejemplos de entradas para mostrar
  const ejemplos = [
    "Hoy tuve un día con muchas cosas por hacer y necesité ayuda.",
    "Hoy tuve un altercado con mi papá.",
    "Siento que no he dormido lo suficiente.",
    "Me fue muy bien en el examen de matemáticas.",
    "Estoy preocupado por el proyecto grupal.",
  ]

  return (
    <div className="space-y-4 pb-16">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Diario De Emociones</h2>
        <Button
          onClick={() => setMostrarFormulario(!mostrarFormulario)}
          variant={mostrarFormulario ? "outline" : "default"}
          className="flex items-center gap-2"
        >
          <PlusCircle className="h-4 w-4" />
          {mostrarFormulario ? "Cancelar" : "Nueva entrada"}
        </Button>
      </div>

      {mostrarFormulario && (
        <Card>
          <CardHeader>
            <CardTitle>¿Cómo te sientes hoy?</CardTitle>
            <CardDescription>Comparte tus experiencias, preocupaciones o logros del día</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="titulo">Título de tu entrada</Label>
              <Input
                id="titulo"
                placeholder="Resume en una frase cómo te sientes"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contenido">Cuéntanos más</Label>
              <Textarea
                id="contenido"
                placeholder="Describe cómo te sientes, qué ha pasado hoy o cualquier cosa que quieras compartir..."
                value={contenido}
                onChange={(e) => setContenido(e.target.value)}
                rows={6}
              />

              {!contenido && (
                <div className="mt-2">
                  <p className="text-sm text-muted-foreground mb-2">Ejemplos:</p>
                  <div className="flex flex-wrap gap-2">
                    {ejemplos.map((ejemplo, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setContenido(ejemplo)}
                        className="text-xs"
                      >
                        {ejemplo}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoría</Label>
                <Select value={categoria} onValueChange={(value) => setCategoria(value)}>
                  <SelectTrigger id="categoria">
                    <SelectValue placeholder="Selecciona una categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="academico">Académico</SelectItem>
                    <SelectItem value="familiar">Familiar</SelectItem>
                    <SelectItem value="amigos">Amigos</SelectItem>
                    <SelectItem value="salud">Salud</SelectItem>
                    <SelectItem value="general">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>¿Cómo te hace sentir?</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={sentimiento === "positivo" ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setSentimiento("positivo")}
                  >
                    <ThumbsUp className="h-4 w-4 mr-2" />
                    Bien
                  </Button>
                  <Button
                    type="button"
                    variant={sentimiento === "neutral" ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setSentimiento("neutral")}
                  >
                    <Heart className="h-4 w-4 mr-2" />
                    Neutral
                  </Button>
                  <Button
                    type="button"
                    variant={sentimiento === "negativo" ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setSentimiento("negativo")}
                  >
                    <ThumbsDown className="h-4 w-4 mr-2" />
                    Mal
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleGuardarEntrada} disabled={!contenido || !titulo} className="w-full">
              Guardar en mi diario
            </Button>
          </CardFooter>
        </Card>
      )}

      {fechasOrdenadas.length > 0 ? (
        <ScrollArea className="h-[500px] rounded-md border p-4">
          {fechasOrdenadas.map((fechaKey) => {
            const entradasDelDia = entradasPorDia[fechaKey]
            const fechaFormateada = format(new Date(fechaKey), "EEEE, d 'de' MMMM 'de' yyyy", { locale: es })

            return (
              <div key={fechaKey} className="mb-6">
                <div className="flex items-center gap-2 sticky top-0 bg-background z-10 py-2">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold capitalize">{fechaFormateada}</h3>
                </div>
                <Separator className="my-2" />

                <div className="space-y-4 pl-6">
                  {entradasDelDia.map((entrada) => {
                    return (
                      <Card key={entrada.id} className="overflow-hidden">
                        <div
                          className={`p-4 ${
                            entrada.sentimiento === "positivo"
                              ? "bg-green-50"
                              : entrada.sentimiento === "negativo"
                                ? "bg-red-50"
                                : "bg-blue-50"
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-xl">
                              {entrada.sentimiento === "positivo"
                                ? "😊"
                                : entrada.sentimiento === "negativo"
                                  ? "😔"
                                  : "😐"}
                            </span>
                            <div>
                              <h4 className="font-medium">{entrada.titulo}</h4>
                              <div className="flex items-center gap-2">
                                <p className="text-xs text-muted-foreground">
                                  {format(entrada.fecha, "'a las' HH:mm", { locale: es })}
                                </p>
                                {entrada.categoria && (
                                  <span className="text-xs px-2 py-0.5 bg-gray-100 rounded-full">
                                    {entrada.categoria}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <p className="mt-2 text-sm whitespace-pre-line">{entrada.contenido}</p>
                        </div>
                      </Card>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </ScrollArea>
      ) : (
        <Card className="p-8 text-center">
          <div className="flex flex-col items-center gap-2">
            <p className="text-muted-foreground">Aún no has registrado ninguna entrada en tu diario.</p>
            {!mostrarFormulario && (
              <Button onClick={() => setMostrarFormulario(true)} variant="outline" className="mt-2">
                Crear mi primera entrada
              </Button>
            )}
          </div>
        </Card>
      )}
    </div>
  )
}

