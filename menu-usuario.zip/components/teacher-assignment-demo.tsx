"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { UserPlus, Trash2 } from "lucide-react"

// Datos de prueba
const mockTeachers = [
  {
    id: "1",
    name: "Juan Pérez",
    specialty: "Matemáticas",
    currentAssignments: ["3A", "4B"],
  },
  {
    id: "2",
    name: "María Rodríguez",
    specialty: "Lenguaje",
    currentAssignments: ["5A"],
  },
  {
    id: "3",
    name: "Carlos López",
    specialty: "Ciencias",
    currentAssignments: ["6B"],
  },
]

const mockSubjects = ["Matemáticas", "Lenguaje", "Ciencias", "Sociales", "Inglés", "Educación Física", "Arte"]

interface Assignment {
  id: string
  teacherId: string
  subject: string
  isDirector: boolean
}

export function TeacherAssignmentDemo() {
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [selectedTeacher, setSelectedTeacher] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("")

  const handleAssign = () => {
    if (selectedTeacher && selectedSubject) {
      const newAssignment: Assignment = {
        id: Date.now().toString(),
        teacherId: selectedTeacher,
        subject: selectedSubject,
        isDirector: false,
      }
      setAssignments([...assignments, newAssignment])
      setSelectedTeacher("")
      setSelectedSubject("")
    }
  }

  const handleRemove = (assignmentId: string) => {
    setAssignments(assignments.filter((a) => a.id !== assignmentId))
  }

  const getTeacherName = (teacherId: string) => {
    return mockTeachers.find((t) => t.id === teacherId)?.name || "Profesor Desconocido"
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-[#1E40AF]">Asignación de Profesores (Demo)</CardTitle>
        <CardDescription>
          Asigna profesores a los diferentes grupos y materias. Esta es una versión de demostración.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex gap-4">
            <Select value={selectedTeacher} onValueChange={setSelectedTeacher}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Seleccionar profesor" />
              </SelectTrigger>
              <SelectContent>
                {mockTeachers.map((teacher) => (
                  <SelectItem key={teacher.id} value={teacher.id}>
                    {teacher.name} - {teacher.specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Seleccionar materia" />
              </SelectTrigger>
              <SelectContent>
                {mockSubjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={handleAssign} disabled={!selectedTeacher || !selectedSubject} className="bg-[#1E40AF]">
              <UserPlus className="mr-2 h-4 w-4" />
              Asignar
            </Button>
          </div>

          {assignments.length > 0 ? (
            <div className="space-y-4">
              {assignments.map((assignment) => (
                <div
                  key={assignment.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50"
                >
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="font-medium">{getTeacherName(assignment.teacherId)}</p>
                      <p className="text-sm text-slate-600">{assignment.subject}</p>
                    </div>
                    {assignment.isDirector && <Badge className="bg-[#EC4899] text-white">Director de Grupo</Badge>}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={() => handleRemove(assignment.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <Alert>
              <AlertDescription>
                No hay asignaciones todavía. Selecciona un profesor y una materia para comenzar.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

