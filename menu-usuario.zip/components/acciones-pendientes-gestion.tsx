"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  ArrowDown,
  Clock,
  Heart,
  UserPlus,
  CheckCircle,
  MessageSquare,
  FileText,
  Calendar,
  Users,
  ClipboardList,
} from "lucide-react"

// Tipos de datos
interface AccionPendiente {
  id: string
  tipo: "evaluacion" | "reunion" | "planificacion" | "emocional"
  titulo: string
  descripcion: string
  fecha: string
  prioridad: "alta" | "media" | "baja"
  estado: "pendiente" | "en_progreso" | "completada"
  estudiante?: string
  curso?: string
}

interface EstudianteEstadoEmocional {
  id: string
  nombre: string
  curso: string
  estado: string
  fecha: string
  recomendacion: string
  tipo: "urgente" | "seguimiento" | "normal"
  asignado?: string
  notas?: string[]
}

// Datos de ejemplo
const accionesPendientesIniciales: AccionPendiente[] = [
  {
    id: "acc1",
    tipo: "evaluacion",
    titulo: "Revisar evaluación de Matemáticas",
    descripcion: "Calificar las evaluaciones del examen de ecuaciones",
    fecha: "25/2/2024",
    prioridad: "alta",
    estado: "pendiente",
    curso: "3A",
  },
  {
    id: "acc2",
    tipo: "reunion",
    titulo: "Reunión con padres de Carlos Pérez",
    descripcion: "Discutir el progreso académico y comportamiento",
    fecha: "26/2/2024",
    prioridad: "media",
    estado: "pendiente",
    estudiante: "Carlos Pérez",
    curso: "3A",
  },
  {
    id: "acc3",
    tipo: "planificacion",
    titulo: "Planificación de la Semana 12",
    descripcion: "Preparar el plan de clases para la próxima semana",
    fecha: "24/2/2024",
    prioridad: "media",
    estado: "en_progreso",
  },
  {
    id: "acc4",
    tipo: "emocional",
    titulo: "Revisar estado emocional de Ana García",
    descripcion: "Estudiante reportó altos niveles de estrés",
    fecha: "24/2/2024",
    prioridad: "alta",
    estado: "pendiente",
    estudiante: "Ana García",
    curso: "3A",
  },
  {
    id: "acc5",
    tipo: "emocional",
    titulo: "Seguimiento a Carlos Rodríguez",
    descripcion: "Ansiedad reportada en la última evaluación emocional",
    fecha: "23/2/2024",
    prioridad: "media",
    estado: "pendiente",
    estudiante: "Carlos Rodríguez",
    curso: "3A",
  },
]

const estudiantesEmocionalesIniciales: EstudianteEstadoEmocional[] = [
  {
    id: "est1",
    nombre: "Ana García",
    curso: "3A",
    estado: "Estrés Pre-Evento",
    fecha: "24/2/2024",
    recomendacion: "Programar una reunión con el estudiante y el departamento de orientación.",
    tipo: "urgente",
    asignado: "",
    notas: [],
  },
  {
    id: "est2",
    nombre: "Carlos Rodríguez",
    curso: "3A",
    estado: "Ansiedad Pre-Evento",
    fecha: "23/2/2024",
    recomendacion: "Hacer seguimiento del progreso en las próximas semanas.",
    tipo: "seguimiento",
    asignado: "",
    notas: [],
  },
  {
    id: "est3",
    nombre: "María López",
    curso: "3A",
    estado: "Estilo de Aprendizaje",
    fecha: "22/2/2024",
    recomendacion: "",
    tipo: "normal",
    asignado: "",
    notas: [],
  },
]

export function AccionesPendientesGestion() {
  const [acciones, setAcciones] = useState<AccionPendiente[]>(accionesPendientesIniciales)
  const [estudiantes, setEstudiantes] = useState<EstudianteEstadoEmocional[]>(estudiantesEmocionalesIniciales)

  // Contadores para el banner
  const accionesPendientes = acciones.filter((a) => a.estado === "pendiente").length
  const accionesUrgentes = acciones.filter((a) => a.prioridad === "alta" && a.estado === "pendiente").length
  const casosEmocionales = estudiantes.filter((e) => e.tipo === "urgente" || e.tipo === "seguimiento").length

  // Contadores para pestañas
  const evaluacionesPendientes = acciones.filter((a) => a.tipo === "evaluacion" && a.estado !== "completada").length
  const reunionesPendientes = acciones.filter((a) => a.tipo === "reunion" && a.estado !== "completada").length
  const planificacionesPendientes = acciones.filter(
    (a) => a.tipo === "planificacion" && a.estado !== "completada",
  ).length
  const emocionalesPendientes = acciones.filter((a) => a.tipo === "emocional" && a.estado !== "completada").length

  // Funciones para gestionar acciones
  const marcarEnProgreso = (id: string) => {
    setAcciones((prev) => prev.map((acc) => (acc.id === id ? { ...acc, estado: "en_progreso" } : acc)))
  }

  const marcarCompletada = (id: string) => {
    setAcciones((prev) => prev.map((acc) => (acc.id === id ? { ...acc, estado: "completada" } : acc)))
  }

  // Funciones para gestionar estados emocionales
  const asignarProfesor = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, asignado: "profesor" } : est)))

    // También actualizar la acción relacionada
    const estudiante = estudiantes.find((e) => e.id === id)
    if (estudiante) {
      const accionRelacionada = acciones.find((a) => a.tipo === "emocional" && a.estudiante === estudiante.nombre)

      if (accionRelacionada) {
        marcarEnProgreso(accionRelacionada.id)
      }
    }
  }

  const asignarPsicologo = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, asignado: "psicologo" } : est)))

    // También actualizar la acción relacionada
    const estudiante = estudiantes.find((e) => e.id === id)
    if (estudiante) {
      const accionRelacionada = acciones.find((a) => a.tipo === "emocional" && a.estudiante === estudiante.nombre)

      if (accionRelacionada) {
        marcarCompletada(accionRelacionada.id)
      }
    }
  }

  const marcarAtendido = (id: string) => {
    setEstudiantes((prev) => prev.map((est) => (est.id === id ? { ...est, tipo: "normal" } : est)))

    // También actualizar la acción relacionada
    const estudiante = estudiantes.find((e) => e.id === id)
    if (estudiante) {
      const accionRelacionada = acciones.find((a) => a.tipo === "emocional" && a.estudiante === estudiante.nombre)

      if (accionRelacionada) {
        marcarCompletada(accionRelacionada.id)
      }
    }
  }

  const agregarNota = (id: string) => {
    const estudiante = estudiantes.find((est) => est.id === id)
    if (!estudiante) return

    const nota = prompt(`Añadir nota para ${estudiante.nombre}:`)
    if (!nota) return

    const fechaActual = new Date().toLocaleDateString()
    const notaCompleta = `[${fechaActual}] ${nota}`

    setEstudiantes((prev) =>
      prev.map((est) => (est.id === id ? { ...est, notas: [...(est.notas || []), notaCompleta] } : est)),
    )
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-blue-700">Acciones Pendientes</h1>
        <p className="text-gray-600">Gestiona todas tus tareas pendientes, evaluaciones, reuniones y seguimientos</p>
      </div>

      {/* Banner de resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-blue-50">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-700 font-medium">Total Pendientes</p>
              <p className="text-2xl font-bold">{accionesPendientes}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <ClipboardList className="h-6 w-6 text-blue-700" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-red-700 font-medium">Urgentes</p>
              <p className="text-2xl font-bold">{accionesUrgentes}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-full">
              <AlertTriangle className="h-6 w-6 text-red-700" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-purple-50">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-700 font-medium">Casos Emocionales</p>
              <p className="text-2xl font-bold">{casosEmocionales}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <Heart className="h-6 w-6 text-purple-700" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pestañas de categorías */}
      <Tabs defaultValue="todas">
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas ({accionesPendientes})</TabsTrigger>
          <TabsTrigger value="evaluaciones">Evaluaciones ({evaluacionesPendientes})</TabsTrigger>
          <TabsTrigger value="reuniones">Reuniones ({reunionesPendientes})</TabsTrigger>
          <TabsTrigger value="planificacion">Planificación ({planificacionesPendientes})</TabsTrigger>
          <TabsTrigger value="emocionales">Emocionales ({emocionalesPendientes})</TabsTrigger>
        </TabsList>

        {/* Contenido de todas las acciones */}
        <TabsContent value="todas">
          <Card>
            <CardHeader>
              <CardTitle>Todas las Acciones Pendientes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {acciones
                .filter((accion) => accion.estado !== "completada")
                .map((accion) => (
                  <div
                    key={accion.id}
                    className={`p-4 rounded-lg border ${
                      accion.prioridad === "alta"
                        ? "border-red-200 bg-red-50"
                        : accion.prioridad === "media"
                          ? "border-yellow-200 bg-yellow-50"
                          : "border-green-200 bg-green-50"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          {accion.tipo === "evaluacion" && <FileText className="h-5 w-5 text-blue-600" />}
                          {accion.tipo === "reunion" && <Users className="h-5 w-5 text-green-600" />}
                          {accion.tipo === "planificacion" && <Calendar className="h-5 w-5 text-orange-600" />}
                          {accion.tipo === "emocional" && <Heart className="h-5 w-5 text-purple-600" />}
                          <h3 className="font-semibold">{accion.titulo}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{accion.descripcion}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                          <Clock className="h-4 w-4" />
                          <span>{accion.fecha}</span>
                          {accion.curso && (
                            <>
                              <span>•</span>
                              <span>Curso: {accion.curso}</span>
                            </>
                          )}
                          {accion.estudiante && (
                            <>
                              <span>•</span>
                              <span>Estudiante: {accion.estudiante}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge
                          variant={accion.prioridad === "alta" ? "destructive" : "outline"}
                          className={
                            accion.prioridad === "media"
                              ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                              : accion.prioridad === "baja"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : ""
                          }
                        >
                          {accion.prioridad === "alta" ? "Urgente" : accion.prioridad === "media" ? "Media" : "Baja"}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            accion.estado === "pendiente"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-orange-100 text-orange-800 border-orange-200"
                          }
                        >
                          {accion.estado === "pendiente" ? "Pendiente" : "En progreso"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex gap-2 mt-3">
                      {accion.estado === "pendiente" ? (
                        <Button variant="outline" size="sm" onClick={() => marcarEnProgreso(accion.id)}>
                          Iniciar
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-green-50"
                          onClick={() => marcarCompletada(accion.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Completar
                        </Button>
                      )}

                      {accion.tipo === "emocional" && (
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/dashboard/profesor/estado-emocional`}>
                            <Heart className="mr-2 h-4 w-4 text-purple-600" />
                            Ver Estado Emocional
                          </Link>
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contenido de evaluaciones */}
        <TabsContent value="evaluaciones">
          <Card>
            <CardHeader>
              <CardTitle>Evaluaciones Pendientes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {acciones
                .filter((accion) => accion.tipo === "evaluacion" && accion.estado !== "completada")
                .map((accion) => (
                  <div
                    key={accion.id}
                    className={`p-4 rounded-lg border ${
                      accion.prioridad === "alta"
                        ? "border-red-200 bg-red-50"
                        : accion.prioridad === "media"
                          ? "border-yellow-200 bg-yellow-50"
                          : "border-green-200 bg-green-50"
                    }`}
                  >
                    {/* Contenido similar al de "todas" pero filtrado por tipo */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <FileText className="h-5 w-5 text-blue-600" />
                          <h3 className="font-semibold">{accion.titulo}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{accion.descripcion}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                          <Clock className="h-4 w-4" />
                          <span>{accion.fecha}</span>
                          {accion.curso && (
                            <>
                              <span>•</span>
                              <span>Curso: {accion.curso}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge
                          variant={accion.prioridad === "alta" ? "destructive" : "outline"}
                          className={
                            accion.prioridad === "media"
                              ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                              : accion.prioridad === "baja"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : ""
                          }
                        >
                          {accion.prioridad === "alta" ? "Urgente" : accion.prioridad === "media" ? "Media" : "Baja"}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            accion.estado === "pendiente"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-orange-100 text-orange-800 border-orange-200"
                          }
                        >
                          {accion.estado === "pendiente" ? "Pendiente" : "En progreso"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex gap-2 mt-3">
                      {accion.estado === "pendiente" ? (
                        <Button variant="outline" size="sm" onClick={() => marcarEnProgreso(accion.id)}>
                          Iniciar
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-green-50"
                          onClick={() => marcarCompletada(accion.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Completar
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contenido de reuniones */}
        <TabsContent value="reuniones">
          <Card>
            <CardHeader>
              <CardTitle>Reuniones Pendientes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {acciones
                .filter((accion) => accion.tipo === "reunion" && accion.estado !== "completada")
                .map((accion) => (
                  <div
                    key={accion.id}
                    className={`p-4 rounded-lg border ${
                      accion.prioridad === "alta"
                        ? "border-red-200 bg-red-50"
                        : accion.prioridad === "media"
                          ? "border-yellow-200 bg-yellow-50"
                          : "border-green-200 bg-green-50"
                    }`}
                  >
                    {/* Contenido similar al de "todas" pero filtrado por tipo */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <Users className="h-5 w-5 text-green-600" />
                          <h3 className="font-semibold">{accion.titulo}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{accion.descripcion}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                          <Clock className="h-4 w-4" />
                          <span>{accion.fecha}</span>
                          {accion.estudiante && (
                            <>
                              <span>•</span>
                              <span>Estudiante: {accion.estudiante}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge
                          variant={accion.prioridad === "alta" ? "destructive" : "outline"}
                          className={
                            accion.prioridad === "media"
                              ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                              : accion.prioridad === "baja"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : ""
                          }
                        >
                          {accion.prioridad === "alta" ? "Urgente" : accion.prioridad === "media" ? "Media" : "Baja"}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            accion.estado === "pendiente"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-orange-100 text-orange-800 border-orange-200"
                          }
                        >
                          {accion.estado === "pendiente" ? "Pendiente" : "En progreso"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex gap-2 mt-3">
                      {accion.estado === "pendiente" ? (
                        <Button variant="outline" size="sm" onClick={() => marcarEnProgreso(accion.id)}>
                          Iniciar
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-green-50"
                          onClick={() => marcarCompletada(accion.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Completar
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contenido de planificación */}
        <TabsContent value="planificacion">
          <Card>
            <CardHeader>
              <CardTitle>Planificaciones Pendientes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {acciones
                .filter((accion) => accion.tipo === "planificacion" && accion.estado !== "completada")
                .map((accion) => (
                  <div
                    key={accion.id}
                    className={`p-4 rounded-lg border ${
                      accion.prioridad === "alta"
                        ? "border-red-200 bg-red-50"
                        : accion.prioridad === "media"
                          ? "border-yellow-200 bg-yellow-50"
                          : "border-green-200 bg-green-50"
                    }`}
                  >
                    {/* Contenido similar al de "todas" pero filtrado por tipo */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-5 w-5 text-orange-600" />
                          <h3 className="font-semibold">{accion.titulo}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{accion.descripcion}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                          <Clock className="h-4 w-4" />
                          <span>{accion.fecha}</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge
                          variant={accion.prioridad === "alta" ? "destructive" : "outline"}
                          className={
                            accion.prioridad === "media"
                              ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                              : accion.prioridad === "baja"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : ""
                          }
                        >
                          {accion.prioridad === "alta" ? "Urgente" : accion.prioridad === "media" ? "Media" : "Baja"}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            accion.estado === "pendiente"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-orange-100 text-orange-800 border-orange-200"
                          }
                        >
                          {accion.estado === "pendiente" ? "Pendiente" : "En progreso"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex gap-2 mt-3">
                      {accion.estado === "pendiente" ? (
                        <Button variant="outline" size="sm" onClick={() => marcarEnProgreso(accion.id)}>
                          Iniciar
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-green-50"
                          onClick={() => marcarCompletada(accion.id)}
                        >
                          <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                          Completar
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contenido de emocionales */}
        <TabsContent value="emocionales">
          <Card>
            <CardHeader>
              <CardTitle>Estados Emocionales que Requieren Atención</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Aquí mostramos los estudiantes con estados emocionales que requieren atención */}
              {estudiantes
                .filter((estudiante) => estudiante.tipo === "urgente" || estudiante.tipo === "seguimiento")
                .map((estudiante) => (
                  <div
                    key={estudiante.id}
                    className={`p-4 rounded-lg ${estudiante.tipo === "urgente" ? "bg-red-50" : "bg-yellow-50"}`}
                  >
                    <div className="flex flex-col gap-3">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            {estudiante.tipo === "urgente" && <AlertTriangle className="h-5 w-5 text-red-500" />}
                            <h3 className="font-semibold">{estudiante.nombre}</h3>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <span>{estudiante.estado}</span>
                            <span>•</span>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>{estudiante.fecha}</span>
                            </div>
                            <span>•</span>
                            <span>Curso: {estudiante.curso}</span>
                          </div>
                          {estudiante.recomendacion && (
                            <p className="text-sm mt-2">
                              <span className="font-medium">Recomendación:</span> {estudiante.recomendacion}
                            </p>
                          )}
                          {estudiante.asignado && (
                            <p className="text-sm mt-1">
                              <span className="font-medium">Asignado a:</span>{" "}
                              {estudiante.asignado === "profesor"
                                ? "Profesor (Tú)"
                                : estudiante.asignado === "psicologo"
                                  ? "Psicólogo/a"
                                  : "Sin asignar"}
                            </p>
                          )}
                        </div>
                        <div>
                          {estudiante.tipo === "urgente" && (
                            <Badge variant="destructive" className="flex items-center gap-1">
                              <ArrowDown className="h-4 w-4" />
                              Requiere atención inmediata
                            </Badge>
                          )}
                          {estudiante.tipo === "seguimiento" && (
                            <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                              <Clock className="h-4 w-4 mr-1" />
                              Necesita seguimiento
                            </Badge>
                          )}
                        </div>
                      </div>

                      {/* Notas */}
                      {estudiante.notas && estudiante.notas.length > 0 && (
                        <div className="mt-2 p-3 bg-white rounded-md border border-gray-100">
                          <h4 className="text-sm font-medium mb-2">Notas de seguimiento:</h4>
                          <div className="space-y-2">
                            {estudiante.notas.map((nota, index) => (
                              <p key={index} className="text-sm text-gray-600">
                                {nota}
                              </p>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Acciones */}
                      <div className="flex flex-wrap gap-2 mt-2">
                        {!estudiante.asignado && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="bg-blue-50"
                              onClick={() => asignarProfesor(estudiante.id)}
                            >
                              <Heart className="mr-2 h-4 w-4 text-blue-600" />
                              Atender yo mismo
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => asignarPsicologo(estudiante.id)}>
                              <UserPlus className="mr-2 h-4 w-4" />
                              Derivar a psicólogo
                            </Button>
                          </>
                        )}

                        {estudiante.asignado === "profesor" && (
                          <>
                            <Button variant="outline" size="sm" onClick={() => agregarNota(estudiante.id)}>
                              <MessageSquare className="mr-2 h-4 w-4" />
                              Añadir nota
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="bg-green-50"
                              onClick={() => marcarAtendido(estudiante.id)}
                            >
                              <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                              Marcar como atendido
                            </Button>
                          </>
                        )}

                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/dashboard/profesor/estado-emocional`}>
                            <Heart className="mr-2 h-4 w-4 text-purple-600" />
                            Ver Detalles
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}

              {/* Mostrar también las acciones de tipo emocional */}
              {acciones
                .filter((accion) => accion.tipo === "emocional" && accion.estado !== "completada")
                .map((accion) => (
                  <div
                    key={accion.id}
                    className={`p-4 rounded-lg border ${
                      accion.prioridad === "alta" ? "border-red-200 bg-red-50" : "border-yellow-200 bg-yellow-50"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <Heart className="h-5 w-5 text-purple-600" />
                          <h3 className="font-semibold">{accion.titulo}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{accion.descripcion}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
                          <Clock className="h-4 w-4" />
                          <span>{accion.fecha}</span>
                          {accion.estudiante && (
                            <>
                              <span>•</span>
                              <span>Estudiante: {accion.estudiante}</span>
                            </>
                          )}
                          {accion.curso && (
                            <>
                              <span>•</span>
                              <span>Curso: {accion.curso}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge
                          variant={accion.prioridad === "alta" ? "destructive" : "outline"}
                          className={
                            accion.prioridad === "media" ? "bg-yellow-100 text-yellow-800 border-yellow-200" : ""
                          }
                        >
                          {accion.prioridad === "alta" ? "Urgente" : "Atención"}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            accion.estado === "pendiente"
                              ? "bg-blue-100 text-blue-800 border-blue-200"
                              : "bg-orange-100 text-orange-800 border-orange-200"
                          }
                        >
                          {accion.estado === "pendiente" ? "Pendiente" : "En progreso"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex gap-2 mt-3">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/dashboard/profesor/estado-emocional`}>
                          <Heart className="mr-2 h-4 w-4 text-purple-600" />
                          Ver Estado Emocional
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

