"use client"

import { CardFooter } from "@/components/ui/card"

import { Label } from "@/components/ui/label"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Loader2, Upload, X, Info, Camera, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { UserRole, RegistrationResponse } from "@/types/registration"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { DataAuthorizationDialog } from "./data-authorization-dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB

const baseSchema = z.object({
  email: z.string().email("Correo electrónico inválido"),
  password: z
    .string()
    .min(8, "La contraseña debe tener al menos 8 caracteres")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
      "La contraseña debe contener al menos una mayúscula, una minúscula, un número y un carácter especial",
    ),
  confirmPassword: z.string(),
  nombre: z.string().min(2, "El nombre es requerido"),
  apellidos: z.string().min(2, "Los apellidos son requeridos"),
  tipoDocumento: z.enum(["cedula", "tarjetaIdentidad", "pasaporte", "cedulaExtranjeria"]),
  numeroDocumento: z.string().min(5, "Número de documento inválido"),
  fechaNacimiento: z.string(),
  telefono: z.string().min(7, "Teléfono inválido"),
  direccion: z.string().min(5, "Dirección inválida"),
  ciudad: z.string().min(3, "Ciudad inválida"),
  role: z.enum(["estudiante", "profesor", "padre", "directivo"]),
  profilePhoto: z.any().optional(),
  dataAuthorization: z.boolean().refine((val) => val === true, {
    message: "Debe aceptar la autorización para el tratamiento de datos personales",
  }),
})

const estudianteSchema = baseSchema.extend({
  gradoActual: z.string(),
  nombreAcudiente: z.string().min(2, "Nombre del acudiente requerido"),
  telefonoAcudiente: z.string().min(7, "Teléfono del acudiente inválido"),
  emailAcudiente: z.string().email("Correo del acudiente inválido"),
})

const profesorSchema = baseSchema.extend({
  especialidad: z.array(z.string()).min(1, "Seleccione al menos una especialidad"),
  experienciaAnos: z.number().min(0, "Experiencia inválida"),
  nivelEducativo: z.string(),
  certificaciones: z.array(z.any()).optional(),
  titulosAcademicos: z.array(z.any()).optional(),
})

const padreSchema = baseSchema.extend({
  hijos: z
    .array(
      z.object({
        nombreEstudiante: z.string().min(2, "Nombre del estudiante requerido"),
        gradoEstudiante: z.string(),
        documentoIdentidadEstudiante: z.string().min(5, "Documento del estudiante inválido"),
        relacionConEstudiante: z.enum(["padre", "madre", "tutor", "otro"]),
      }),
    )
    .min(1, "Debe agregar al menos un estudiante"),
})

const directivoSchema = baseSchema.extend({
  cargo: z.string().min(2, "Cargo requerido"),
  departamento: z.string().min(2, "Departamento requerido"),
  nombreInstitucion: z.string().min(2, "Nombre de la institución requerido"),
  experienciaEducativa: z.number().min(0, "Experiencia inválida"),
  certificaciones: z.array(z.any()).optional(),
  titulosAcademicos: z.array(z.any()).optional(),
})

const getSchemaForRole = (role: UserRole) => {
  switch (role) {
    case "estudiante":
      return estudianteSchema
    case "profesor":
      return profesorSchema
    case "padre":
      return padreSchema
    case "directivo":
      return directivoSchema
    default:
      return baseSchema
  }
}

export function RegistrationForm() {
  const [role, setRole] = useState<UserRole>("estudiante")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [registrationStatus, setRegistrationStatus] = useState<RegistrationResponse | null>(null)
  const [showAuthorizationDialog, setShowAuthorizationDialog] = useState(false)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)

  const form = useForm({
    resolver: zodResolver(getSchemaForRole(role)),
    defaultValues: {
      role: "estudiante",
      email: "",
      password: "",
      confirmPassword: "",
      nombre: "",
      apellidos: "",
      tipoDocumento: "cedula" as const,
      numeroDocumento: "",
      fechaNacimiento: "",
      telefono: "",
      direccion: "",
      ciudad: "",
      especialidad: [], // Inicializar como array vacío
      dataAuthorization: false,
      hijos: [
        {
          nombreEstudiante: "",
          gradoEstudiante: "",
          documentoIdentidadEstudiante: "",
          relacionConEstudiante: "padre" as const,
        },
      ],
    },
  })

  const onSubmit = async (data: z.infer<typeof baseSchema>) => {
    setIsSubmitting(true)
    try {
      // Aquí iría la lógica para enviar los datos al servidor
      // Simulamos una respuesta después de 2 segundos
      await new Promise((resolve) => setTimeout(resolve, 2000))

      setRegistrationStatus({
        status: "pendiente",
        message: "Tu solicitud ha sido recibida y está siendo revisada por el administrador.",
        registrationId: Math.random().toString(36).substr(2, 9),
      })
    } catch (error) {
      console.error(error)
      setRegistrationStatus({
        status: "rechazado",
        message: "Hubo un error al procesar tu solicitud. Por favor intenta nuevamente.",
        registrationId: "",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole)

    // Reset the form with role-specific defaults
    if (newRole === "padre") {
      form.reset({
        ...form.getValues(),
        role: newRole,
        hijos: [
          {
            nombreEstudiante: "",
            gradoEstudiante: "",
            documentoIdentidadEstudiante: "",
            relacionConEstudiante: "padre" as const,
          },
        ],
      })
    } else {
      form.reset({
        ...form.getValues(),
        role: newRole,
      })
    }
  }

  const handlePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        form.setError("profilePhoto", {
          message: "La imagen no debe superar los 5MB",
        })
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        setPhotoPreview(e.target.result as string)
        form.setValue("profilePhoto", file)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl text-[#1E40AF]">Registro de Usuario</CardTitle>
          <CardDescription>
            Complete el formulario para solicitar una cuenta. Su solicitud será revisada por un administrador.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Selección de Rol */}
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo de Usuario</FormLabel>
                    <Select
                      onValueChange={(value: UserRole) => {
                        field.onChange(value)
                        handleRoleChange(value)
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccione su rol" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="estudiante">Estudiante</SelectItem>
                        <SelectItem value="profesor">Profesor</SelectItem>
                        <SelectItem value="padre">Padre/Acudiente</SelectItem>
                        <SelectItem value="directivo">Directivo</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex flex-col items-center gap-4 mb-6">
                <FormField
                  control={form.control}
                  name="profilePhoto"
                  render={({ field: { onChange, value, ...field } }) => (
                    <FormItem className="text-center">
                      <FormLabel>Foto de Perfil</FormLabel>
                      <FormControl>
                        <div className="flex flex-col items-center gap-4">
                          <div className="relative">
                            <Avatar className="w-32 h-32">
                              {photoPreview ? (
                                <AvatarImage src={photoPreview} alt="Vista previa" className="object-cover" />
                              ) : (
                                <AvatarFallback className="bg-muted">
                                  <Camera className="w-8 h-8 text-muted-foreground" />
                                </AvatarFallback>
                              )}
                            </Avatar>
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="absolute bottom-0 right-0 rounded-full bg-background border-2 border-muted"
                              onClick={() => document.getElementById("photo-upload")?.click()}
                            >
                              <Camera className="w-4 h-4" />
                              <span className="sr-only">Cambiar foto</span>
                            </Button>
                          </div>
                          <Input
                            id="photo-upload"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handlePhotoChange}
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>Sube una foto de perfil (máximo 5MB)</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Información Personal */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="nombre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre</FormLabel>
                      <FormControl>
                        <Input placeholder="Juan" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="apellidos"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Apellidos</FormLabel>
                      <FormControl>
                        <Input placeholder="Pérez" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Documento */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="tipoDocumento"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Documento</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cedula">Cédula de Ciudadanía</SelectItem>
                          <SelectItem value="tarjetaIdentidad">Tarjeta de Identidad</SelectItem>
                          <SelectItem value="pasaporte">Pasaporte</SelectItem>
                          <SelectItem value="cedulaExtranjeria">Cédula de Extranjería</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="numeroDocumento"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Número de Documento</FormLabel>
                      <FormControl>
                        <Input placeholder="1234567890" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Campos específicos por rol */}
              {role === "estudiante" && (
                <>
                  <FormField
                    control={form.control}
                    name="gradoActual"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Grado Actual</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione grado" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {Array.from({ length: 11 }, (_, i) => (
                              <SelectItem key={i + 1} value={`${i + 1}`}>
                                Grado {i + 1}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Información del Acudiente</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="nombreAcudiente"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nombre del Acudiente</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="telefonoAcudiente"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Teléfono del Acudiente</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </>
              )}

              {role === "profesor" && (
                <>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Especialidades</h3>
                    <div className="grid grid-cols-1 gap-4">
                      <FormField
                        control={form.control}
                        name="especialidad"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Seleccione sus Especialidades</FormLabel>
                            <div className="space-y-4">
                              <Select
                                onValueChange={(value) => {
                                  if (!field.value.includes(value)) {
                                    field.onChange([...field.value, value])
                                  }
                                }}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Agregar especialidad" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="matematicas">Matemáticas</SelectItem>
                                  <SelectItem value="ciencias">Ciencias</SelectItem>
                                  <SelectItem value="lenguaje">Lenguaje</SelectItem>
                                  <SelectItem value="sociales">Sociales</SelectItem>
                                  <SelectItem value="ingles">Inglés</SelectItem>
                                  <SelectItem value="fisica">Física</SelectItem>
                                  <SelectItem value="quimica">Química</SelectItem>
                                  <SelectItem value="biologia">Biología</SelectItem>
                                  <SelectItem value="artistica">Educación Artística</SelectItem>
                                  <SelectItem value="educacionFisica">Educación Física</SelectItem>
                                  <SelectItem value="tecnologia">Tecnología</SelectItem>
                                  <SelectItem value="filosofia">Filosofía</SelectItem>
                                </SelectContent>
                              </Select>

                              <div className="flex flex-wrap gap-2">
                                {field.value.map((especialidad: string) => (
                                  <Badge
                                    key={especialidad}
                                    variant="secondary"
                                    className="px-3 py-1 bg-[#EFF6FF] text-[#1E40AF] hover:bg-[#EFF6FF]/80"
                                  >
                                    {especialidad}
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      className="h-4 w-4 p-0 ml-2 hover:bg-transparent"
                                      onClick={() => {
                                        field.onChange(field.value.filter((e: string) => e !== especialidad))
                                      }}
                                    >
                                      <X className="h-3 w-3" />
                                      <span className="sr-only">Remover {especialidad}</span>
                                    </Button>
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <FormDescription>
                              Puede seleccionar múltiples especialidades. Haga clic en la X para eliminar una
                              especialidad.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Documentos</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="certificaciones"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Certificaciones</FormLabel>
                            <FormControl>
                              <div className="flex items-center gap-2">
                                <Input
                                  type="file"
                                  multiple
                                  accept=".pdf,.doc,.docx"
                                  onChange={(e) => field.onChange(e.target.files)}
                                />
                                <Upload className="h-4 w-4" />
                              </div>
                            </FormControl>
                            <FormDescription>Formatos aceptados: PDF, DOC, DOCX</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </>
              )}

              {role === "padre" && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Información de los Estudiantes</h3>
                  <FormField
                    control={form.control}
                    name="hijos"
                    render={({ field }) => (
                      <FormItem>
                        <div className="space-y-4">
                          {field.value?.map((hijo, index) => (
                            <Card key={index} className="p-4 border border-gray-200">
                              <div className="flex justify-between items-center mb-4">
                                <h4 className="font-medium">Estudiante {index + 1}</h4>
                                {field.value.length > 1 && (
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                    onClick={() => {
                                      const newValue = [...field.value]
                                      newValue.splice(index, 1)
                                      field.onChange(newValue)
                                    }}
                                  >
                                    Eliminar
                                  </Button>
                                )}
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label htmlFor={`nombreEstudiante-${index}`}>Nombre del Estudiante</Label>
                                  <Input
                                    id={`nombreEstudiante-${index}`}
                                    value={hijo.nombreEstudiante || ""}
                                    onChange={(e) => {
                                      const newValue = [...field.value]
                                      newValue[index].nombreEstudiante = e.target.value
                                      field.onChange(newValue)
                                    }}
                                  />
                                  {form.formState.errors.hijos?.[index]?.nombreEstudiante && (
                                    <p className="text-sm text-red-500">
                                      {form.formState.errors.hijos[index]?.nombreEstudiante?.message}
                                    </p>
                                  )}
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor={`gradoEstudiante-${index}`}>Grado del Estudiante</Label>
                                  <Select
                                    value={hijo.gradoEstudiante || ""}
                                    onValueChange={(value) => {
                                      const newValue = [...field.value]
                                      newValue[index].gradoEstudiante = value
                                      field.onChange(newValue)
                                    }}
                                  >
                                    <SelectTrigger id={`gradoEstudiante-${index}`}>
                                      <SelectValue placeholder="Seleccione grado" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {Array.from({ length: 11 }, (_, i) => (
                                        <SelectItem key={i + 1} value={`${i + 1}`}>
                                          Grado {i + 1}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  {form.formState.errors.hijos?.[index]?.gradoEstudiante && (
                                    <p className="text-sm text-red-500">
                                      {form.formState.errors.hijos[index]?.gradoEstudiante?.message}
                                    </p>
                                  )}
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor={`documentoIdentidadEstudiante-${index}`}>
                                    Documento del Estudiante
                                  </Label>
                                  <Input
                                    id={`documentoIdentidadEstudiante-${index}`}
                                    value={hijo.documentoIdentidadEstudiante || ""}
                                    onChange={(e) => {
                                      const newValue = [...field.value]
                                      newValue[index].documentoIdentidadEstudiante = e.target.value
                                      field.onChange(newValue)
                                    }}
                                  />
                                  {form.formState.errors.hijos?.[index]?.documentoIdentidadEstudiante && (
                                    <p className="text-sm text-red-500">
                                      {form.formState.errors.hijos[index]?.documentoIdentidadEstudiante?.message}
                                    </p>
                                  )}
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor={`relacionConEstudiante-${index}`}>Relación con el Estudiante</Label>
                                  <Select
                                    value={hijo.relacionConEstudiante || ""}
                                    onValueChange={(value) => {
                                      const newValue = [...field.value]
                                      newValue[index].relacionConEstudiante = value as
                                        | "padre"
                                        | "madre"
                                        | "tutor"
                                        | "otro"
                                      field.onChange(newValue)
                                    }}
                                  >
                                    <SelectTrigger id={`relacionConEstudiante-${index}`}>
                                      <SelectValue placeholder="Seleccione relación" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="padre">Padre</SelectItem>
                                      <SelectItem value="madre">Madre</SelectItem>
                                      <SelectItem value="tutor">Tutor Legal</SelectItem>
                                      <SelectItem value="otro">Otro</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  {form.formState.errors.hijos?.[index]?.relacionConEstudiante && (
                                    <p className="text-sm text-red-500">
                                      {form.formState.errors.hijos[index]?.relacionConEstudiante?.message}
                                    </p>
                                  )}
                                </div>
                              </div>
                            </Card>
                          ))}
                          <Button
                            type="button"
                            variant="outline"
                            className="w-full border-dashed border-2 border-gray-300 hover:border-[#1E40AF] text-gray-500 hover:text-[#1E40AF]"
                            onClick={() => {
                              const currentValue = field.value || []
                              field.onChange([
                                ...currentValue,
                                {
                                  nombreEstudiante: "",
                                  gradoEstudiante: "",
                                  documentoIdentidadEstudiante: "",
                                  relacionConEstudiante: "padre" as const,
                                },
                              ])
                            }}
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Agregar otro estudiante
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {role === "directivo" && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="cargo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cargo</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="departamento"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Departamento</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="nombreInstitucion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nombre de Institución</FormLabel>
                        <FormControl>
                          <Input placeholder="Nombre del colegio" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Documentos de Respaldo</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="certificaciones"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Certificaciones y Títulos</FormLabel>
                            <FormControl>
                              <div className="flex items-center gap-2">
                                <Input
                                  type="file"
                                  multiple
                                  accept=".pdf,.doc,.docx"
                                  onChange={(e) => field.onChange(e.target.files)}
                                />
                                <Upload className="h-4 w-4" />
                              </div>
                            </FormControl>
                            <FormDescription>Formatos aceptados: PDF, DOC, DOCX</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Credenciales */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Credenciales de Acceso</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Correo Electrónico</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contraseña</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormDescription>
                          Mínimo 8 caracteres, incluyendo mayúsculas, minúsculas y números
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <FormField
                control={form.control}
                name="telefono"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Teléfono Celular</FormLabel>
                    <FormControl>
                      <Input type="tel" placeholder="300 123 4567" {...field} />
                    </FormControl>
                    <FormDescription>Ingrese un número de celular válido</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dataAuthorization"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Autorización de datos</FormLabel>
                      <FormDescription className="text-sm text-muted-foreground">
                        He leído y acepto la{" "}
                        <button
                          type="button"
                          className="text-[#1E40AF] hover:underline"
                          onClick={() => setShowAuthorizationDialog(true)}
                        >
                          autorización para el tratamiento de datos personales
                        </button>
                      </FormDescription>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              <DataAuthorizationDialog open={showAuthorizationDialog} onOpenChange={setShowAuthorizationDialog} />

              {/* Alerta de privacidad */}
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Privacidad y Protección de Datos</AlertTitle>
                <AlertDescription>
                  Sus datos personales serán tratados de acuerdo con la Ley 1581 de 2012 y el Decreto 1377 de 2013. La
                  información proporcionada será utilizada únicamente con fines académicos y educativos.
                </AlertDescription>
              </Alert>

              {registrationStatus && (
                <Alert
                  className={
                    registrationStatus.status === "pendiente"
                      ? "bg-yellow-50 border-yellow-200"
                      : registrationStatus.status === "aprobado"
                        ? "bg-green-50 border-green-200"
                        : "bg-red-50 border-red-200"
                  }
                >
                  <AlertTitle
                    className={
                      registrationStatus.status === "pendiente"
                        ? "text-yellow-800"
                        : registrationStatus.status === "aprobado"
                          ? "text-green-800"
                          : "text-red-800"
                    }
                  >
                    {registrationStatus.status === "pendiente"
                      ? "Solicitud en Revisión"
                      : registrationStatus.status === "aprobado"
                        ? "Registro Exitoso"
                        : "Error en el Registro"}
                  </AlertTitle>
                  <AlertDescription>
                    {registrationStatus.message}
                    {registrationStatus.registrationId && (
                      <p className="mt-2">
                        ID de Registro: <strong>{registrationStatus.registrationId}</strong>
                      </p>
                    )}
                  </AlertDescription>
                </Alert>
              )}
            </form>
          </Form>
        </CardContent>
        <CardFooter>
          <Button
            className="w-full bg-[#1E40AF] hover:bg-[#1E40AF]/90"
            onClick={form.handleSubmit(onSubmit)}
            disabled={isSubmitting}
          >
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isSubmitting ? "Enviando solicitud..." : "Enviar Solicitud"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

