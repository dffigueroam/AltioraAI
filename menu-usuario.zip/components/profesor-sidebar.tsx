"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BookOpen, Calendar, ClipboardList, FileText, Home, MessageSquare, Settings, Users, Heart } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export function ProfesorSidebar() {
  const pathname = usePathname()

  const routes = [
    {
      label: "Inicio",
      icon: Home,
      href: "/dashboard/profesor",
      active: pathname === "/dashboard/profesor",
    },
    {
      label: "Calendario",
      icon: Calendar,
      href: "/dashboard/profesor/calendario",
      active: pathname === "/dashboard/profesor/calendario",
    },
    {
      label: "Clases",
      icon: BookOpen,
      href: "/dashboard/profesor/clases",
      active: pathname === "/dashboard/profesor/clases",
    },
    {
      label: "Estudiantes",
      icon: Users,
      href: "/dashboard/profesor/estudiantes",
      active: pathname === "/dashboard/profesor/estudiantes",
    },
    {
      label: "Evaluaciones",
      icon: FileText,
      href: "/dashboard/profesor/evaluaciones",
      active: pathname === "/dashboard/profesor/evaluaciones",
    },
    {
      label: "Acciones Pendientes",
      icon: ClipboardList,
      href: "/dashboard/profesor/acciones-pendientes",
      active: pathname === "/dashboard/profesor/acciones-pendientes",
    },
    {
      label: "Estado Emocional",
      icon: Heart,
      href: "/dashboard/profesor/estado-emocional",
      active: pathname === "/dashboard/profesor/estado-emocional",
    },
    {
      label: "Mensajes",
      icon: MessageSquare,
      href: "/dashboard/profesor/mensajes",
      active: pathname === "/dashboard/profesor/mensajes",
    },
    {
      label: "Configuración",
      icon: Settings,
      href: "/dashboard/profesor/configuracion",
      active: pathname === "/dashboard/profesor/configuracion",
    },
    {
      label: "Tablero de Grupo",
      icon: Users,
      href: "/dashboard/profesor/grupo",
      active: pathname === "/dashboard/profesor/grupo",
    },
  ]

  return (
    <div className="w-64 bg-white border-r h-screen">
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Panel del Profesor</h2>
        <div className="space-y-1">
          {routes.map((route) => (
            <Button
              key={route.href}
              variant={route.active ? "secondary" : "ghost"}
              size="sm"
              className={cn("w-full justify-start", route.active ? "bg-primary/10 text-primary" : "")}
              asChild
            >
              <Link href={route.href}>
                <route.icon className="mr-2 h-4 w-4" />
                {route.label}
                {route.label === "Estado Emocional" && (
                  <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-red-100 text-xs text-red-600">
                    2
                  </span>
                )}
              </Link>
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}

