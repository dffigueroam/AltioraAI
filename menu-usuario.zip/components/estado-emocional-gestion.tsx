"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertTriangle, ArrowDown, ArrowUp, Clock, UserCheck } from "lucide-react"
import type { StudentEmotionalState } from "@/types/student-emotional-state"

type EmotionalStateType = "pre_event" | "anxiety" | "learning_style" | "behavioral" | "social"

type AttentionLevel = "urgent" | "needs_attention" | "monitoring" | "normal"

interface EstadoEmocionalGestionProps {
  className?: string
  groupId: string
  userRole: "teacher" | "psychologist"
  userId: string
  userName: string
}

export function EstadoEmocionalGestion({
  className,
  groupId,
  userRole,
  userId,
  userName,
}: EstadoEmocionalGestionProps) {
  // Estado inicial de ejemplo
  const [students, setStudents] = useState<StudentEmotionalState[]>([
    {
      id: "1",
      studentName: "Ana García",
      stateType: "pre_event",
      attentionLevel: "urgent",
      date: "2024-02-24",
      recommendation: "Programar una reunión con el estudiante y el departamento de orientación.",
      status: "pending",
    },
    {
      id: "2",
      studentName: "Carlos Rodríguez",
      stateType: "anxiety",
      attentionLevel: "needs_attention",
      date: "2024-02-23",
      recommendation: "Hacer seguimiento del progreso en las próximas semanas.",
      status: "in_progress",
      assignedTo: {
        id: "psych123",
        name: "Laura Sánchez",
        role: "psychologist",
      },
    },
    {
      id: "3",
      studentName: "María López",
      stateType: "learning_style",
      attentionLevel: "normal",
      date: "2024-02-22",
      recommendation: "Mantener el seguimiento regular del progreso académico.",
      status: "completed",
    },
  ])

  const [selectedStudent, setSelectedStudent] = useState<StudentEmotionalState | null>(null)
  const [newNote, setNewNote] = useState("")
  const [newStatus, setNewStatus] = useState<StudentEmotionalState["status"]>("pending")

  const urgentCount = students.filter((s) => s.attentionLevel === "urgent").length
  const attentionCount = students.filter((s) => s.attentionLevel === "needs_attention").length

  const getStateColor = (stateType: EmotionalStateType) => {
    switch (stateType) {
      case "pre_event":
        return "bg-red-100 text-red-800 border-red-200"
      case "anxiety":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "learning_style":
        return "bg-green-100 text-green-800 border-green-200"
      case "behavioral":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "social":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getAttentionIcon = (level: AttentionLevel) => {
    switch (level) {
      case "urgent":
        return <AlertTriangle className="h-5 w-5 text-red-600" />
      case "needs_attention":
        return <Clock className="h-5 w-5 text-yellow-600" />
      case "monitoring":
        return <ArrowDown className="h-5 w-5 text-blue-600" />
      case "normal":
        return <ArrowUp className="h-5 w-5 text-green-600" />
      default:
        return null
    }
  }

  const getStateLabel = (stateType: EmotionalStateType) => {
    switch (stateType) {
      case "pre_event":
        return "Estrés Pre-Evento"
      case "anxiety":
        return "Ansiedad Pre-Evento"
      case "learning_style":
        return "Estilo de Aprendizaje"
      case "behavioral":
        return "Comportamiento"
      case "social":
        return "Interacción Social"
      default:
        return stateType
    }
  }

  const handleUpdateStatus = (studentId: string, newStatus: StudentEmotionalState["status"]) => {
    setStudents((prev) =>
      prev.map((student) =>
        student.id === studentId
          ? {
              ...student,
              status: newStatus,
              notes: [
                ...(student.notes || []),
                {
                  id: Date.now().toString(),
                  text: newNote,
                  date: new Date().toISOString().split("T")[0],
                  author: {
                    id: userId,
                    name: userName,
                    role: userRole,
                  },
                },
              ],
            }
          : student,
      ),
    )
    setNewNote("")
    setSelectedStudent(null)
  }

  const handleAssign = (studentId: string) => {
    setStudents((prev) =>
      prev.map((student) =>
        student.id === studentId
          ? {
              ...student,
              assignedTo: {
                id: userId,
                name: userName,
                role: userRole,
              },
              status: "in_progress",
            }
          : student,
      ),
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl text-[#1E40AF]">Estado Emocional Alumnos - {groupId}</CardTitle>
            <CardDescription>Resultados recientes de evaluaciones emocionales y estilos de aprendizaje</CardDescription>
          </div>
          <div className="flex gap-2">
            {urgentCount > 0 && <Badge variant="destructive">{urgentCount} Urgentes</Badge>}
            {attentionCount > 0 && (
              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                {attentionCount} Atención
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {students.map((student) => (
          <div
            key={student.id}
            className={`p-4 rounded-lg border ${
              student.attentionLevel === "urgent"
                ? "bg-red-50 border-red-200"
                : student.attentionLevel === "needs_attention"
                  ? "bg-yellow-50 border-yellow-200"
                  : "bg-green-50 border-green-200"
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {getAttentionIcon(student.attentionLevel)}
                  <h3 className="text-lg font-semibold">{student.studentName}</h3>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={getStateColor(student.stateType)}>
                    {getStateLabel(student.stateType)}
                  </Badge>
                  <span className="text-sm text-muted-foreground">• {student.date}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">{student.recommendation}</p>
                {student.assignedTo && (
                  <div className="flex items-center gap-2 mt-2">
                    <UserCheck className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Asignado a: {student.assignedTo.name} (
                      {student.assignedTo.role === "teacher" ? "Profesor" : "Psicólogo"})
                    </span>
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedStudent(student)
                        setNewStatus(student.status)
                      }}
                    >
                      Gestionar
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Gestionar Estado Emocional</DialogTitle>
                      <DialogDescription>Actualiza el estado y agrega notas de seguimiento</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Estado actual</h4>
                        <Select
                          value={newStatus}
                          onValueChange={(value) => setNewStatus(value as StudentEmotionalState["status"])}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pendiente</SelectItem>
                            <SelectItem value="in_progress">En Progreso</SelectItem>
                            <SelectItem value="completed">Completado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Agregar nota de seguimiento</h4>
                        <Textarea
                          value={newNote}
                          onChange={(e) => setNewNote(e.target.value)}
                          placeholder="Escribe una nota sobre el progreso o las acciones tomadas..."
                          rows={4}
                        />
                      </div>

                      {student.notes && student.notes.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-sm font-medium">Historial de notas</h4>
                          <div className="space-y-3">
                            {student.notes.map((note) => (
                              <div key={note.id} className="bg-muted p-3 rounded-md">
                                <p className="text-sm">{note.text}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  Por {note.author.name} ({note.author.role === "teacher" ? "Profesor" : "Psicólogo"}) -{" "}
                                  {note.date}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSelectedStudent(null)
                          setNewNote("")
                        }}
                      >
                        Cancelar
                      </Button>
                      <Button
                        onClick={() => handleUpdateStatus(student.id, newStatus)}
                        disabled={!newNote && newStatus === student.status}
                      >
                        Guardar Cambios
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {!student.assignedTo && (
                  <Button variant="default" onClick={() => handleAssign(student.id)}>
                    Asignarme
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

