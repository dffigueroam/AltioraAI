"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { CalendarIcon, Plus, Upload, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Tema, Tag } from "@/types/tema"

const formSchema = z.object({
  titulo: z.string().min(2, "El título es requerido"),
  descripcion: z.string().min(10, "La descripción debe tener al menos 10 caracteres"),
  materia: z.string().min(1, "Seleccione una materia"),
  fecha: z.date(),
  archivos: z.array(z.any()).optional(),
  tags: z.array(z.string()).min(1, "Seleccione al menos un tag"),
})

const materias = [
  "Matemáticas",
  "Física",
  "Química",
  "Biología",
  "Lenguaje",
  "Historia",
  "Geografía",
  "Inglés",
  "Educación Física",
  "Arte",
]

const tagsDisponibles: Tag[] = [
  { id: "1", nombre: "Evaluación", color: "bg-red-100 text-red-800" },
  { id: "2", nombre: "Tarea", color: "bg-blue-100 text-blue-800" },
  { id: "3", nombre: "Proyecto", color: "bg-green-100 text-green-800" },
  { id: "4", nombre: "Laboratorio", color: "bg-purple-100 text-purple-800" },
  { id: "5", nombre: "Repaso", color: "bg-yellow-100 text-yellow-800" },
  { id: "6", nombre: "Exposición", color: "bg-pink-100 text-pink-800" },
  { id: "7", nombre: "Práctica", color: "bg-indigo-100 text-indigo-800" },
  { id: "8", nombre: "Teoría", color: "bg-gray-100 text-gray-800" },
]

export function TemasClase() {
  const [temas, setTemas] = useState<Tema[]>([])
  const [filtroMateria, setFiltroMateria] = useState<string>("")
  const [filtroTag, setFiltroTag] = useState<string>("")
  const [busqueda, setBusqueda] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      titulo: "",
      descripcion: "",
      materia: "",
      tags: [],
    },
  })

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    const nuevoTema: Tema = {
      id: Math.random().toString(36).substr(2, 9),
      ...values,
      fecha: values.fecha.toISOString(),
      profesorId: "1", // Este ID vendría del contexto de autenticación
      estado: "programado",
    }

    setTemas([...temas, nuevoTema])
    form.reset()
    setIsDialogOpen(false)
  }

  const temasFiltrados = temas.filter((tema) => {
    const cumpleFiltroMateria = !filtroMateria || tema.materia === filtroMateria
    const cumpleFiltroTag = !filtroTag || tema.tags.includes(filtroTag)
    const cumpleBusqueda =
      !busqueda ||
      tema.titulo.toLowerCase().includes(busqueda.toLowerCase()) ||
      tema.descripcion.toLowerCase().includes(busqueda.toLowerCase())

    return cumpleFiltroMateria && cumpleFiltroTag && cumpleBusqueda
  })

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-[#1E40AF]">Temas de Clase</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#1E40AF]">
              <Plus className="mr-2 h-4 w-4" /> Nuevo Tema
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Agregar Nuevo Tema</DialogTitle>
              <DialogDescription>
                Complete la información del tema a programar. Los campos marcados con * son obligatorios.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="titulo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Título *</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej: Introducción al Álgebra" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="descripcion"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descripción *</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describa los objetivos y contenidos principales del tema..."
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="materia"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Materia *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || materias[0]}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione la materia" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {materias.map((materia) => (
                              <SelectItem key={materia} value={materia}>
                                {materia}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="fecha"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Fecha *</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full pl-3 text-left font-normal ${
                                  !field.value && "text-muted-foreground"
                                }`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP", { locale: es })
                                ) : (
                                  <span>Seleccione una fecha</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) => date < new Date()}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="tags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tags *</FormLabel>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-2">
                          {tagsDisponibles.map((tag) => (
                            <Badge
                              key={tag.id}
                              variant="secondary"
                              className={`cursor-pointer ${tag.color} ${
                                field.value?.includes(tag.nombre) ? "ring-2 ring-offset-2 ring-[#1E40AF]" : ""
                              }`}
                              onClick={() => {
                                const currentTags = field.value || []
                                const newTags = currentTags.includes(tag.nombre)
                                  ? currentTags.filter((t) => t !== tag.nombre)
                                  : [...currentTags, tag.nombre]
                                field.onChange(newTags)
                              }}
                            >
                              {tag.nombre}
                            </Badge>
                          ))}
                        </div>
                        <FormDescription>Seleccione uno o más tags para categorizar el tema</FormDescription>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="archivos"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Archivos de Apoyo</FormLabel>
                      <FormControl>
                        <div className="flex items-center gap-2">
                          <Input
                            type="file"
                            multiple
                            accept=".pdf,.doc,.docx,.ppt,.pptx"
                            onChange={(e) => field.onChange(e.target.files)}
                          />
                          <Upload className="h-4 w-4" />
                        </div>
                      </FormControl>
                      <FormDescription>Formatos aceptados: PDF, DOC, DOCX, PPT, PPTX</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-[#1E40AF]">
                    Guardar Tema
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="mb-6 space-y-4">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <Input
              placeholder="Buscar temas..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full"
              prefix={<Search className="h-4 w-4 text-gray-400" />}
            />
          </div>
          <Select value={filtroMateria} onValueChange={setFiltroMateria}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filtrar por materia" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todas las materias">Todas las materias</SelectItem>
              {materias.map((materia) => (
                <SelectItem key={materia} value={materia}>
                  {materia}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filtroTag} onValueChange={setFiltroTag}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filtrar por tag" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos los tags">Todos los tags</SelectItem>
              {tagsDisponibles.map((tag) => (
                <SelectItem key={tag.id} value={tag.nombre}>
                  {tag.nombre}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="lista" className="space-y-4">
        <TabsList>
          <TabsTrigger value="lista">Vista Lista</TabsTrigger>
          <TabsTrigger value="calendario">Vista Calendario</TabsTrigger>
        </TabsList>

        <TabsContent value="lista" className="space-y-4">
          {temasFiltrados.length === 0 ? (
            <Card>
              <CardContent className="py-10 text-center text-gray-500">
                No hay temas que coincidan con los filtros seleccionados
              </CardContent>
            </Card>
          ) : (
            temasFiltrados.map((tema) => (
              <Card key={tema.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-[#1E40AF]">{tema.titulo}</CardTitle>
                      <CardDescription>
                        {format(new Date(tema.fecha), "PPP", { locale: es })} - {tema.materia}
                      </CardDescription>
                    </div>
                    <Badge
                      variant={
                        tema.estado === "programado"
                          ? "default"
                          : tema.estado === "completado"
                            ? "success"
                            : "destructive"
                      }
                    >
                      {tema.estado}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{tema.descripcion}</p>
                  <div className="flex flex-wrap gap-2">
                    {tema.tags.map((tag) => {
                      const tagInfo = tagsDisponibles.find((t) => t.nombre === tag)
                      return (
                        <Badge key={tag} variant="secondary" className={tagInfo?.color || "bg-gray-100 text-gray-800"}>
                          {tag}
                        </Badge>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="calendario">
          <Card>
            <CardHeader>
              <CardTitle>Calendario de Temas</CardTitle>
              <CardDescription>Vista mensual de los temas programados</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Aquí iría el componente de calendario */}
              <div className="h-[500px] flex items-center justify-center text-gray-500">
                Vista de calendario en desarrollo
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

