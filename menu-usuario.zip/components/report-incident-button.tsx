"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Upload, AlertCircle, Headset } from "lucide-react"

const formSchema = z.object({
  type: z.enum(["technical", "access", "change_request", "data_error", "security", "performance", "other"], {
    required_error: "Por favor seleccione un tipo de incidencia",
  }),
  title: z.string().min(5, "El título debe tener al menos 5 caracteres"),
  description: z.string().min(20, "La descripción debe tener al menos 20 caracteres"),
  priority: z.enum(["low", "medium", "high", "critical"], {
    required_error: "Por favor seleccione un nivel de prioridad",
  }),
  attachments: z.array(z.any()).optional(),
})

export function ReportIncidentButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"success" | "error" | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: undefined,
      title: "",
      description: "",
      priority: undefined,
      attachments: [],
    },
  })

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSubmitting(true)
    try {
      // Aquí iría la llamada a la API para enviar la incidencia
      await new Promise((resolve) => setTimeout(resolve, 1500)) // Simulación de llamada
      setSubmitStatus("success")
      setTimeout(() => {
        setIsOpen(false)
        setSubmitStatus(null)
        form.reset()
      }, 2000)
    } catch (error) {
      setSubmitStatus("error")
    } finally {
      setIsSubmitting(false)
    }
  }

  const incidentTypes = {
    technical: {
      label: "Problema Técnico",
      description: "Errores en el sistema, bugs o problemas de funcionamiento",
    },
    access: {
      label: "Problema de Acceso",
      description: "Problemas con contraseñas, permisos o inicio de sesión",
    },
    change_request: {
      label: "Solicitud de Cambio",
      description: "Reasignación de profesores, eliminación de eventos, etc.",
    },
    data_error: {
      label: "Error en Datos",
      description: "Información incorrecta o desactualizada en el sistema",
    },
    security: {
      label: "Seguridad",
      description: "Problemas relacionados con la seguridad del sistema",
    },
    performance: {
      label: "Rendimiento",
      description: "Lentitud o problemas de rendimiento del sistema",
    },
    other: {
      label: "Otro",
      description: "Otros tipos de incidencias no listadas",
    },
  }

  const priorityLevels = {
    low: {
      label: "Baja",
      description: "No afecta la operación normal",
      class: "bg-blue-100 text-blue-800",
    },
    medium: {
      label: "Media",
      description: "Afecta parcialmente la operación",
      class: "bg-yellow-100 text-yellow-800",
    },
    high: {
      label: "Alta",
      description: "Afecta significativamente la operación",
      class: "bg-orange-100 text-orange-800",
    },
    critical: {
      label: "Crítica",
      description: "Sistema inoperable o pérdida de datos",
      class: "bg-red-100 text-red-800",
    },
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-white shadow-lg hover:bg-gray-100 border-2 border-[#1E40AF] animate-bounce hover:animate-none"
        >
          <Headset className="h-6 w-6 text-[#1E40AF]" />
          <span className="sr-only">Soporte en Línea</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Soporte en Línea - Reportar Incidencia</DialogTitle>
          <DialogDescription>
            Describe el problema o solicitud para que podamos ayudarte lo antes posible.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Incidencia</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccione el tipo de incidencia" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Object.entries(incidentTypes).map(([value, { label, description }]) => (
                        <SelectItem key={value} value={value}>
                          <div className="flex flex-col">
                            <span>{label}</span>
                            <span className="text-xs text-gray-500">{description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input placeholder="Resuma brevemente la incidencia" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descripción</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describa detalladamente el problema, incluyendo los pasos para reproducirlo si es posible"
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="priority"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nivel de Prioridad</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccione la prioridad" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Object.entries(priorityLevels).map(([value, { label, description, class: className }]) => (
                        <SelectItem key={value} value={value}>
                          <div className="flex items-center gap-2">
                            <Badge className={className}>{label}</Badge>
                            <span className="text-xs text-gray-500">{description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="attachments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Archivos Adjuntos</FormLabel>
                  <FormControl>
                    <div className="flex items-center gap-2">
                      <Input
                        type="file"
                        multiple
                        accept="image/*,.pdf"
                        onChange={(e) => field.onChange(e.target.files)}
                      />
                      <Upload className="h-4 w-4" />
                    </div>
                  </FormControl>
                  <FormDescription>
                    Puede adjuntar capturas de pantalla u otros archivos relevantes (máx. 5MB por archivo)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {submitStatus && (
              <Alert
                variant={submitStatus === "success" ? "default" : "destructive"}
                className={
                  submitStatus === "success"
                    ? "bg-green-50 text-green-800 border-green-200"
                    : "bg-red-50 text-red-800 border-red-200"
                }
              >
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>{submitStatus === "success" ? "Incidencia Reportada" : "Error al Reportar"}</AlertTitle>
                <AlertDescription>
                  {submitStatus === "success"
                    ? "Tu incidencia ha sido registrada y será atendida lo antes posible."
                    : "Hubo un error al reportar la incidencia. Por favor, intenta nuevamente."}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end gap-4">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-[#1E40AF] hover:bg-[#1E40AF]/90" disabled={isSubmitting}>
                {isSubmitting ? "Enviando..." : "Enviar Reporte"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

