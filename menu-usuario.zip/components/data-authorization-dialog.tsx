import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"

interface DataAuthorizationDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function DataAuthorizationDialog({ open, onOpenChange }: DataAuthorizationDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Autorización para el Tratamiento de Datos Personales</DialogTitle>
          <DialogDescription>Por favor lea cuidadosamente el siguiente documento</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[400px] rounded-md border p-4">
          <div className="space-y-4 text-sm">
            <p>
              Autorización para el tratamiento de datos personales, para plataforma educativa como extensión de
              enseñanza
            </p>
            <p>
              Yo, [NOMBRE DEL TITULAR] identificado(a) con [TIPO DE DOCUMENTO] No. [NÚMERO DE DOCUMENTO] expedida en
              [LUGAR DE EXPEDICIÓN], por medio del presente y de conformidad con lo dispuesto en las normas vigentes
              sobre protección de datos personales, en especial la Ley 1581 de 2012 y el Decreto 1377 de 2013, autorizo
              libre, expresa e inequívocamente al sector educativo Nacional, para que realice la recolección y
              tratamiento de mis datos personales que suministro de manera veraz y completa, los cuales serán utilizados
              con fines académicos, que optimicen el rendimiento académico, disciplinario y de enseñanza en la
              institución educativa.
            </p>
            <p>
              Igualmente, a partir de la fecha de suscripción, manifiesto que de conformidad con el artículo 56 del
              Código de Procedimiento Administrativo y de lo Contencioso Administrativo - Ley 1437 de 2011, autorizo
              expresamente al Departamento Administrativo de la plataforma remitir notificaciones electrónicas al correo
              electrónico.
            </p>
            <p>
              Por lo anterior, autorizo y acepto recibir notificaciones a través de medios electrónicos así mismo, se me
              podrá dar previo aviso de la notificación al número celular en el servicio de mensajería de WhatsApp. Por
              lo tanto, expreso que mi autorización fue solicitada y puesta de presente antes de entregar mis datos y
              que la suscribo de forma libre y voluntaria una vez leída en su totalidad.
            </p>
            <div className="mt-8 space-y-2">
              <p>Firma: __________________________ (del titular)</p>
              <p>Nombre: _____________________________ (del titular)</p>
              <p>Identificación: _________________________ (del titular)</p>
              <p>
                Fecha: __________________________ (Fecha en que se puso de presente al titular la autorización y entregó
                sus datos)
              </p>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}

