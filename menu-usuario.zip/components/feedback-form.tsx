"use client"

import * as React from "react"
import { StarIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const formSchema = z.object({
  performanceRating: z.number().min(1, "Por favor califica la velocidad de la plataforma"),
  intuitivenessRating: z.number().min(1, "Por favor califica qué tan intuitiva es la plataforma"),
  interactivityRating: z.number().min(1, "Por favor califica las funciones de los botones"),
  designRating: z.number().min(1, "Por favor califica los colores y el diseño"),
  supportRating: z.number().min(1, "Por favor califica la atención de incidentes"),
  improvements: z.string().optional(),
})

interface FeedbackFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function FeedbackForm({ open, onOpenChange }: FeedbackFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      performanceRating: 0,
      intuitivenessRating: 0,
      interactivityRating: 0,
      designRating: 0,
      supportRating: 0,
      improvements: "",
    },
  })

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      // Aquí iría la lógica para enviar el feedback al backend
      console.log(values)
      // Simular envío
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast.success("¡Gracias por tu feedback!")
      onOpenChange(false)
      form.reset({
        performanceRating: 0,
        intuitivenessRating: 0,
        interactivityRating: 0,
        designRating: 0,
        supportRating: 0,
        improvements: "",
      })
    } catch (error) {
      toast.error("Hubo un error al enviar tu feedback. Por favor intenta nuevamente.")
    }
  }

  // Reset form when dialog closes
  React.useEffect(() => {
    if (!open) {
      form.reset({
        performanceRating: 0,
        intuitivenessRating: 0,
        interactivityRating: 0,
        designRating: 0,
        supportRating: 0,
        improvements: "",
      })
    }
  }, [open, form])

  const RatingStars = ({ field }: { field: any }) => (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((rating) => (
        <button
          key={rating}
          type="button"
          onClick={() => field.onChange(rating)}
          className={cn(
            "rounded-full p-1 hover:bg-slate-100 transition-colors",
            field.value >= rating ? "text-yellow-400" : "text-gray-300",
          )}
        >
          <StarIcon className="h-6 w-6" />
        </button>
      ))}
    </div>
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-[#1E40AF]">Tu opinión nos importa</DialogTitle>
          <DialogDescription>
            Ayúdanos a mejorar tu experiencia en la plataforma. Tus respuestas son anónimas y nos ayudarán a crear una
            mejor plataforma educativa.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="performanceRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan rápida te funciona la plataforma?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la velocidad y el rendimiento general</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="intuitivenessRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan intuitiva te parece?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa qué tan fácil es usar la plataforma</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="interactivityRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué te parecen las funciones al hacer click en los botones?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la respuesta y funcionalidad de los elementos interactivos</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="designRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tanto te gustan los colores y el diseño?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la apariencia visual de la plataforma</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="supportRating"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué tan rápida es la atención de tus incidentes?</FormLabel>
                  <FormControl>
                    <RatingStars field={field} />
                  </FormControl>
                  <FormDescription>Evalúa la velocidad y calidad del soporte técnico</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="improvements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>¿Qué le mejorarías a la plataforma?</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Comparte tus sugerencias para mejorar la plataforma..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>Tus sugerencias nos ayudan a crear una mejor experiencia para todos</FormDescription>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  onOpenChange(false)
                  form.reset({
                    performanceRating: 0,
                    intuitivenessRating: 0,
                    interactivityRating: 0,
                    designRating: 0,
                    supportRating: 0,
                    improvements: "",
                  })
                }}
              >
                Cancelar
              </Button>
              <Button type="submit" className="bg-[#1E40AF]">
                Enviar Feedback
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

