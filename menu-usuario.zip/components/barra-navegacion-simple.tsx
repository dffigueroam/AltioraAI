export function BarraNavegacionSimple() {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-100 border-t w-full">
      <div className="flex overflow-x-auto">
        <button className="flex-1 py-3 px-2 text-sm text-center text-gray-600">Acciones Pendientes</button>
        <button className="flex-1 py-3 px-2 text-sm text-center text-gray-600">Eventos</button>
        <button className="flex-1 py-3 px-2 text-sm text-center text-gray-600">Enlaces de Interés</button>
        <button className="flex-1 py-3 px-2 text-sm text-center text-gray-600">Deportes</button>
        <button className="flex-1 py-3 px-2 text-sm text-center text-blue-600 border-t-2 border-blue-600">
          Diario De Emociones
        </button>
        <button className="flex-1 py-3 px-2 text-sm text-center text-gray-600">Gestión sugerida de la IA</button>
      </div>
    </div>
  )
}

