"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import type { Question, Questionnaire, QuestionnaireResponse } from "@/types/questionnaire"

interface QuestionnaireFormProps {
  questionnaire: Questionnaire
  onSubmit: (response: QuestionnaireResponse) => void
  onCancel: () => void
}

export function QuestionnaireForm({ questionnaire, onSubmit, onCancel }: QuestionnaireFormProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string | number | string[]>>({})

  const question = questionnaire.questions[currentQuestion]
  const progress = ((currentQuestion + 1) / questionnaire.questions.length) * 100

  const handleAnswer = (questionId: string, value: string | number | string[]) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value,
    }))
  }

  const handleNext = () => {
    if (currentQuestion < questionnaire.questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      const response: QuestionnaireResponse = {
        id: Math.random().toString(36).substr(2, 9),
        questionnaireId: questionnaire.id,
        studentId: "current-user-id", // En una implementación real, esto vendría del contexto de autenticación
        answers: Object.entries(answers).map(([questionId, value]) => ({
          questionId,
          value,
        })),
        completedAt: new Date().toISOString(),
      }
      onSubmit(response)
    }
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("es", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  const renderQuestion = (question: Question) => {
    switch (question.type) {
      case "single":
        return (
          <RadioGroup
            value={answers[question.id]?.toString()}
            onValueChange={(value) => handleAnswer(question.id, value)}
          >
            {question.options?.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={option} />
                <Label htmlFor={option}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        )

      case "multiple":
        return (
          <div className="space-y-2">
            {question.options?.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <Checkbox
                  id={option}
                  checked={((answers[question.id] as string[]) || []).includes(option)}
                  onCheckedChange={(checked) => {
                    const currentAnswers = (answers[question.id] as string[]) || []
                    const newAnswers = checked
                      ? [...currentAnswers, option]
                      : currentAnswers.filter((a) => a !== option)
                    handleAnswer(question.id, newAnswers)
                  }}
                />
                <Label htmlFor={option}>{option}</Label>
              </div>
            ))}
          </div>
        )

      case "scale":
        return (
          <div className="space-y-4">
            <div className="flex justify-between text-sm text-gray-500">
              <span>{question.scaleRange?.labels.min}</span>
              <span>{question.scaleRange?.labels.max}</span>
            </div>
            <div className="flex justify-between gap-2">
              {Array.from({ length: (question.scaleRange?.max || 5) - (question.scaleRange?.min || 0) + 1 }).map(
                (_, i) => {
                  const value = (question.scaleRange?.min || 0) + i
                  return (
                    <Button
                      key={value}
                      variant={answers[question.id] === value ? "default" : "outline"}
                      className={`flex-1 ${answers[question.id] === value ? "bg-[#1E40AF]" : ""}`}
                      onClick={() => handleAnswer(question.id, value)}
                    >
                      {value}
                    </Button>
                  )
                },
              )}
            </div>
          </div>
        )

      case "text":
        return (
          <Textarea
            value={answers[question.id]?.toString() || ""}
            onChange={(e) => handleAnswer(question.id, e.target.value)}
            placeholder="Escribe tu respuesta aquí..."
            className="min-h-[100px]"
          />
        )

      default:
        return null
    }
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-[#1E40AF]">{questionnaire.title}</CardTitle>
        <CardDescription>{questionnaire.description}</CardDescription>
        <Progress value={progress} className="mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-lg font-medium mb-4">
          Pregunta {currentQuestion + 1} de {questionnaire.questions.length}
        </div>
        <div className="text-lg mb-6">{question.text}</div>
        {renderQuestion(question)}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button onClick={handleNext} className="bg-[#1E40AF] hover:bg-[#1E40AF]/90" disabled={!answers[question.id]}>
          {currentQuestion === questionnaire.questions.length - 1 ? "Finalizar" : "Siguiente"}
        </Button>
      </CardFooter>
    </Card>
  )
}

