"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

interface BottomNavigationProps {
  items: {
    href: string
    label: string
    icon: React.ReactNode
  }[]
}

export function BottomNavigation({ items }: BottomNavigationProps) {
  const pathname = usePathname()

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-white border-t border-gray-200 dark:bg-gray-800 dark:border-gray-700">
      <div className="grid h-full max-w-lg grid-cols-4 mx-auto">
        {items.map((item, index) => (
          <Link
            key={index}
            href={item.href}
            className={cn(
              "inline-flex flex-col items-center justify-center px-5 hover:bg-gray-50 dark:hover:bg-gray-700",
              pathname === item.href ? "text-blue-600 dark:text-blue-500" : "text-gray-500 dark:text-gray-400",
            )}
          >
            {item.icon}
            <span className="text-xs">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

