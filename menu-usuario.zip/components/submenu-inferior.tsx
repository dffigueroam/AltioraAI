"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

export function SubmenuInferior() {
  const [activeTab, setActiveTab] = useState<string | null>(null)

  // Lista de tabs en la barra inferior
  const tabs = [
    { id: "acciones-pendientes", label: "Acciones Pendientes" },
    { id: "eventos", label: "Eventos" },
    { id: "enlaces-interes", label: "Enlaces de Interés" },
    { id: "deportes", label: "Deportes" },
    { id: "gestion-ia", label: "Gestión sugerida de la IA" },
  ]

  const handleTabClick = (tabId: string) => {
    if (activeTab === tabId) {
      setActiveTab(null)
    } else {
      setActiveTab(tabId)
    }
  }

  const renderTabContent = () => {
    // Contenido para otras pestañas
    return (
      <div className="p-4 border rounded-md mt-4">
        <h2 className="text-lg font-medium mb-2">{tabs.find((tab) => tab.id === activeTab)?.label}</h2>
        <p className="text-muted-foreground">Contenido de {tabs.find((tab) => tab.id === activeTab)?.label}</p>
      </div>
    )
  }

  return (
    <div className="w-full">
      {/* Barra de navegación inferior */}
      <div className="flex flex-wrap gap-2 justify-center border-t pt-4 pb-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabClick(tab.id)}
            className={cn(
              "px-3 py-1 text-sm rounded-md transition-colors",
              activeTab === tab.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Contenido de la pestaña activa */}
      {activeTab && renderTabContent()}
    </div>
  )
}

