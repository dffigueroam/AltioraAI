import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, AlertCircle } from "lucide-react"
import type { Questionnaire, QuestionnaireSchedule } from "@/types/questionnaire"
import { Badge } from "@/components/ui/badge"

interface QuestionnaireCardProps {
  questionnaire: Questionnaire
  schedule?: QuestionnaireSchedule
  onStart: () => void
}

export function QuestionnaireCard({ questionnaire, schedule, onStart }: QuestionnaireCardProps) {
  const getStatusColor = (status?: QuestionnaireSchedule["status"]) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "overdue":
        return "bg-red-100 text-red-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  const getStatusText = (status?: QuestionnaireSchedule["status"]) => {
    switch (status) {
      case "completed":
        return "Completado"
      case "overdue":
        return "Vencido"
      case "pending":
        return "Pendiente"
      default:
        return "Disponible"
    }
  }

  const formatDate = (date: string) => {
    return new Intl.DateTimeFormat("es", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(date))
  }

  return (
    <Card className="hover:border-[#3B82F6] transition-colors">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-[#1E40AF]">{questionnaire.title}</CardTitle>
            <CardDescription>{questionnaire.description}</CardDescription>
          </div>
          <Badge variant="secondary" className={getStatusColor(schedule?.status)}>
            {getStatusText(schedule?.status)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Clock className="h-4 w-4" />
          <span>Tiempo estimado: {questionnaire.estimatedTime} minutos</span>
        </div>
        {questionnaire.required && (
          <div className="flex items-center gap-2 text-sm text-amber-600">
            <AlertCircle className="h-4 w-4" />
            <span>Este cuestionario es obligatorio</span>
          </div>
        )}
        {schedule?.scheduledFor && (
          <div className="mt-2 text-sm text-gray-600">Programado para: {formatDate(schedule.scheduledFor)}</div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          onClick={onStart}
          className="w-full bg-[#1E40AF] hover:bg-[#1E40AF]/90"
          disabled={schedule?.status === "completed"}
        >
          {schedule?.status === "completed" ? "Completado" : "Comenzar Evaluación"}
        </Button>
      </CardFooter>
    </Card>
  )
}

