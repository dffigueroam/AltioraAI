import { Mail, Phone, User } from "lucide-react"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"
import { Button } from "@/components/ui/button"

type StudentStatus = "lowStress" | "mediumStress" | "highStress"
type ProgressStatus = "good" | "average" | "needsImprovement"

interface Student {
  id: number
  firstName: string
  lastName: string
  stressStatus: StudentStatus
  progressStatus: ProgressStatus
  guardian?: {
    name: string
    relation: string
    phone: string
    email: string
    address: string
  }
}

interface TeacherClassroomOverviewProps {
  classroomId: string
  isDirectorGrupo: boolean
}

const getStressColor = (status: StudentStatus) => {
  switch (status) {
    case "lowStress":
      return "bg-green-500"
    case "mediumStress":
      return "bg-yellow-500"
    case "highStress":
      return "bg-red-500"
    default:
      return "bg-gray-500"
  }
}

const getProgressColor = (status: ProgressStatus) => {
  switch (status) {
    case "good":
      return "bg-blue-500"
    case "average":
      return "bg-orange-500"
    case "needsImprovement":
      return "bg-purple-500"
    default:
      return "bg-gray-500"
  }
}

// Lista de nombres y apellidos para generar datos de prueba
const firstNames = [
  "Ana",
  "Juan",
  "María",
  "Carlos",
  "Sofía",
  "David",
  "Laura",
  "Daniel",
  "Valentina",
  "Andrés",
  "Camila",
  "Santiago",
  "Isabella",
  "Mateo",
  "Lucía",
  "Alejandro",
  "Gabriela",
  "Sebastián",
  "Valeria",
  "Nicolás",
]

const lastNames = [
  "García",
  "Rodríguez",
  "Martínez",
  "López",
  "González",
  "Pérez",
  "Sánchez",
  "Ramírez",
  "Torres",
  "Flores",
  "Rivera",
  "Gómez",
  "Díaz",
  "Reyes",
  "Cruz",
  "Morales",
  "Ortiz",
  "Gutiérrez",
  "Mendoza",
  "Vargas",
]

export function TeacherClassroomOverview({ classroomId, isDirectorGrupo }: TeacherClassroomOverviewProps) {
  // Generamos un número aleatorio de estudiantes entre 20 y 35
  const studentCount = Math.floor(Math.random() * (35 - 20 + 1)) + 20

  // Simulamos diferentes estudiantes para cada salón con nombres y apellidos
  const students: Student[] = Array.from({ length: studentCount }, (_, i) => {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)]
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)]

    return {
      id: i + 1,
      firstName,
      lastName,
      stressStatus: ["lowStress", "mediumStress", "highStress"][Math.floor(Math.random() * 3)] as StudentStatus,
      progressStatus: ["good", "average", "needsImprovement"][Math.floor(Math.random() * 3)] as ProgressStatus,
      guardian: {
        name: `Acudiente de ${firstName}`,
        relation: ["Madre", "Padre", "Abuelo/a", "Tío/a"][Math.floor(Math.random() * 4)],
        phone: `+57 ${300 + Math.floor(Math.random() * 100)} ${Math.floor(Math.random() * 10000000)}`,
        email: `acudiente.${firstName.toLowerCase()}@example.com`,
        address: `Calle ${Math.floor(Math.random() * 100)} #${Math.floor(Math.random() * 100)}-${Math.floor(Math.random() * 100)}, Bogotá`,
      },
    }
  })

  return (
    <div className="bg-[#1E1E1E] border-[#3B82F6] border p-4 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-[#F3F4F6] text-lg font-semibold flex items-center gap-2">
          Vista General del Salón {classroomId}
          {isDirectorGrupo && (
            <span className="bg-[#EC4899] text-white px-3 py-1 rounded-full text-sm">Director de Grupo</span>
          )}
        </h3>
      </div>
      <div className="grid grid-cols-5 sm:grid-cols-7 md:grid-cols-9 lg:grid-cols-11 gap-4">
        {students.map((student) => (
          <HoverCard key={student.id} openDelay={200} closeDelay={100}>
            <HoverCardTrigger asChild>
              <div className="flex flex-col items-center cursor-pointer">
                <div className="relative">
                  <User className={`h-8 w-8 ${getStressColor(student.stressStatus)} text-white p-1 rounded-full`} />
                  <div
                    className={`absolute bottom-0 right-0 w-3 h-3 ${getProgressColor(student.progressStatus)} rounded-full border-2 border-[#1E1E1E]`}
                  ></div>
                </div>
                <span
                  className="text-white text-xs mt-1 text-center"
                  style={{ maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
                >
                  {student.firstName}
                </span>
              </div>
            </HoverCardTrigger>
            <HoverCardContent className="w-80 bg-white text-black p-4 rounded-lg shadow-lg">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium text-lg">
                    {student.firstName} {student.lastName}
                  </h4>
                  <span className={`px-2 py-1 rounded-full text-xs text-white ${getStressColor(student.stressStatus)}`}>
                    {student.stressStatus === "lowStress"
                      ? "Estrés Bajo"
                      : student.stressStatus === "mediumStress"
                        ? "Estrés Medio"
                        : "Estrés Alto"}
                  </span>
                </div>
                <div className="border-t pt-2 mt-2">
                  <h5 className="font-medium">Información del Acudiente</h5>
                  <div className="grid grid-cols-[100px_1fr] gap-1 mt-2">
                    <div className="text-sm font-medium">Nombre:</div>
                    <div className="text-sm">{student.guardian?.name}</div>

                    <div className="text-sm font-medium">Relación:</div>
                    <div className="text-sm">{student.guardian?.relation}</div>

                    <div className="text-sm font-medium">Teléfono:</div>
                    <div className="text-sm">{student.guardian?.phone}</div>

                    <div className="text-sm font-medium">Email:</div>
                    <div className="text-sm">{student.guardian?.email}</div>

                    <div className="text-sm font-medium">Dirección:</div>
                    <div className="text-sm">{student.guardian?.address}</div>
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-4">
                  <Button size="sm" variant="outline">
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </Button>
                  <Button size="sm" variant="default">
                    <Phone className="h-4 w-4 mr-2" />
                    Llamar
                  </Button>
                </div>
              </div>
            </HoverCardContent>
          </HoverCard>
        ))}
      </div>
      <div className="mt-4 flex flex-wrap justify-center gap-4">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Estrés Bajo</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Estrés Medio</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Estrés Alto</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Buen Progreso</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Progreso Promedio</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
          <span className="text-white text-xs">Necesita Mejorar</span>
        </div>
      </div>
    </div>
  )
}

