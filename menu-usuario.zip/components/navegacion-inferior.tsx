"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

// Exportación nombrada para evitar problemas de importación
export function NavegacionInferior() {
  const pathname = usePathname()

  const enlaces = [
    { nombre: "Inicio", ruta: "/dashboard/estudiante" },
    { nombre: "Tareas", ruta: "/dashboard/estudiante/tareas" },
    { nombre: "Eventos", ruta: "/dashboard/estudiante/eventos" },
    { nombre: "Diario De Emociones", ruta: "/dashboard/estudiante/diario-emociones" },
    { nombre: "Recursos", ruta: "/dashboard/estudiante/recursos" },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md z-50">
      <div className="container mx-auto">
        <div className="flex overflow-x-auto">
          {enlaces.map((enlace) => (
            <Link
              key={enlace.nombre}
              href={enlace.ruta}
              className={`flex-1 py-3 px-2 text-sm text-center ${
                pathname === enlace.ruta
                  ? "text-blue-600 border-t-2 border-blue-600"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {enlace.nombre}
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}

