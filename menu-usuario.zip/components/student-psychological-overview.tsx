import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Clock, AlertCircle, ArrowUp, ArrowDown, Phone } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

interface TestResult {
  studentId: string
  studentName: string
  testType: string
  score: number
  completedAt: string
  status: "normal" | "attention" | "urgent"
  trend: "improving" | "declining" | "stable"
}

interface StudentPsychologicalOverviewProps {
  classroomId: string
  isDirectorGrupo: boolean
}

interface Student {
  id: string
  name: string
  emotionalState: string
  lastUpdate: string
  status: "normal" | "warning" | "critical"
  recommendation?: string
  guardian?: {
    name?: string
    relation?: string
    phone?: string
    email?: string
    address?: string
  }
}

export function StudentPsychologicalOverview({ classroomId, isDirectorGrupo }: StudentPsychologicalOverviewProps) {
  // Simulación de resultados de tests
  const recentTestResults: TestResult[] = [
    {
      studentId: "1",
      studentName: "Ana García",
      testType: "pre_event_stress",
      score: 8,
      completedAt: "2024-02-25",
      status: "urgent",
      trend: "declining",
    },
    {
      studentId: "2",
      studentName: "Carlos Rodríguez",
      testType: "pre_event_anxiety",
      score: 6,
      completedAt: "2024-02-24",
      status: "attention",
      trend: "stable",
    },
    {
      studentId: "3",
      studentName: "María López",
      testType: "learning_style",
      score: 4,
      completedAt: "2024-02-23",
      status: "normal",
      trend: "improving",
    },
  ]

  const students: Student[] = [
    {
      id: "1",
      name: "Ana García",
      emotionalState: "Estrés Pre-Evento",
      lastUpdate: "2024-02-25",
      status: "critical",
      recommendation: "Programar una reunión con el estudiante y el departamento de orientación.",
      guardian: {
        name: "Roberto García",
        relation: "Padre",
        phone: "+57 310 123 4567",
        email: "roberto.garcia@example.com",
        address: "Calle 123 #45-67, Medellín",
      },
    },
    {
      id: "2",
      name: "Carlos Rodríguez",
      emotionalState: "Ansiedad Pre-Evento",
      lastUpdate: "2024-02-24",
      status: "warning",
      recommendation: "Hacer seguimiento del progreso en las próximas semanas.",
      guardian: {
        name: "Laura Pérez",
        relation: "Madre",
        phone: "+57 311 234 5678",
        email: "laura.perez@example.com",
        address: "Avenida 456 #78-90, Cali",
      },
    },
    {
      id: "3",
      name: "María López",
      emotionalState: "Estilo de Aprendizaje",
      lastUpdate: "2024-02-23",
      status: "normal",
      guardian: {
        name: "José López",
        relation: "Padre",
        phone: "+57 312 345 6789",
        email: "jose.lopez@example.com",
        address: "Carrera 789 #01-23, Barranquilla",
      },
    },
  ]

  const getStatusColor = (status: TestResult["status"]) => {
    switch (status) {
      case "urgent":
        return "bg-red-100 text-red-800 border-red-200"
      case "attention":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-green-100 text-green-800 border-green-200"
    }
  }

  const getTrendIcon = (trend: TestResult["trend"]) => {
    switch (trend) {
      case "improving":
        return <ArrowUp className="h-4 w-4 text-green-600" />
      case "declining":
        return <ArrowDown className="h-4 w-4 text-red-600" />
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />
    }
  }

  const getTestTypeLabel = (type: string) => {
    const labels = {
      pre_event_stress: "Estrés Pre-Evento",
      pre_event_anxiety: "Ansiedad Pre-Evento",
      learning_style: "Estilo de Aprendizaje",
    }
    return labels[type] || type
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-[#1E40AF]">Estado Emocional Alumnos - {classroomId}</CardTitle>
            <CardDescription>Resultados recientes de evaluaciones emocionales y estilos de aprendizaje</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-red-50 text-red-800 border-red-200">
              {recentTestResults.filter((r) => r.status === "urgent").length} Urgentes
            </Badge>
            <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">
              {recentTestResults.filter((r) => r.status === "attention").length} Atención
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {students.map((student) => (
            <Popover key={student.id}>
              <PopoverTrigger asChild>
                <div
                  className={`p-4 rounded-lg cursor-pointer ${
                    student.status === "critical"
                      ? "bg-red-50"
                      : student.status === "warning"
                        ? "bg-yellow-50"
                        : "bg-green-50"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {student.status === "critical" && <AlertTriangle className="h-5 w-5 text-red-500" />}
                        {student.status === "warning" && <AlertCircle className="h-5 w-5 text-yellow-500" />}
                        <h3 className="font-semibold">{student.name}</h3>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>{student.emotionalState}</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{student.lastUpdate}</span>
                        </div>
                      </div>
                      {student.recommendation && (
                        <p className="text-sm mt-2">
                          <span className="font-medium">Recomendación:</span> {student.recommendation}
                        </p>
                      )}
                    </div>
                    <div>
                      {student.status === "critical" && (
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <ArrowDown className="h-4 w-4" />
                          Requiere atención inmediata
                        </Badge>
                      )}
                      {student.status === "warning" && (
                        <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                          <Clock className="h-4 w-4 mr-1" />
                          Necesita seguimiento
                        </Badge>
                      )}
                      {student.status === "normal" && (
                        <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                          <ArrowUp className="h-4 w-4 mr-1" />
                          Estado normal
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="space-y-2">
                  <h4 className="font-medium">Información del Acudiente</h4>
                  <div className="grid grid-cols-2 gap-1">
                    <div className="text-sm font-medium">Nombre:</div>
                    <div className="text-sm">{student.guardian?.name || "Carlos Gómez"}</div>

                    <div className="text-sm font-medium">Relación:</div>
                    <div className="text-sm">{student.guardian?.relation || "Padre"}</div>

                    <div className="text-sm font-medium">Teléfono:</div>
                    <div className="text-sm">{student.guardian?.phone || "+57 300 987 6543"}</div>

                    <div className="text-sm font-medium">Email:</div>
                    <div className="text-sm">{student.guardian?.email || "carlos.gomez@example.com"}</div>

                    <div className="text-sm font-medium">Dirección:</div>
                    <div className="text-sm">{student.guardian?.address || "Carrera 45 #67-89, Bogotá"}</div>
                  </div>
                  <div className="flex justify-end gap-2 mt-4">
                    <Button size="sm" variant="outline">
                      <Mail className="h-4 w-4 mr-2" />
                      Contactar
                    </Button>
                    <Button size="sm" variant="default">
                      <Phone className="h-4 w-4 mr-2" />
                      Llamar
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

