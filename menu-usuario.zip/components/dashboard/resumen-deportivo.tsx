"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trophy, Activity, Ruler, Award, ArrowRight } from "lucide-react"
import Link from "next/link"

interface ResumenDeportivoProps {
  clubDeportivo?: {
    nombre: string
    deporte: string
    categoria: string
    proximoEntrenamiento?: string
  }
  ultimasMedidas?: {
    fecha: string
    altura: number
    peso: number
    imc: number
  }
  ultimosTests?: {
    fecha: string
    tipo: string
    resultado: string
    evaluacion: string
  }[]
  ultimosLogros?: {
    fecha: string
    evento: string
    resultado: string
    destacado?: boolean
  }[]
}

// Datos de ejemplo
const datosEjemplo: ResumenDeportivoProps = {
  clubDeportivo: {
    nombre: "Águilas Doradas",
    deporte: "Fútbol",
    categoria: "Sub-16",
    proximoEntrenamiento: "Lunes 4:00 PM",
  },
  ultimasMedidas: {
    fecha: "2024-01-20",
    altura: 172,
    peso: 64.0,
    imc: 21.6,
  },
  ultimosTests: [
    {
      fecha: "2024-01-15",
      tipo: "Velocidad",
      resultado: "12.5 segundos",
      evaluacion: "excelente",
    },
    {
      fecha: "2024-01-15",
      tipo: "Resistencia",
      resultado: "11.8 minutos",
      evaluacion: "excelente",
    },
  ],
  ultimosLogros: [
    {
      fecha: "2024-01-10",
      evento: "Torneo Intercolegiado Regional",
      resultado: "Campeón",
      destacado: true,
    },
    {
      fecha: "2023-12-15",
      evento: "Liga Escolar",
      resultado: "Subcampeón",
      destacado: true,
    },
  ],
}

export function ResumenDeportivo({
  clubDeportivo = datosEjemplo.clubDeportivo,
  ultimasMedidas = datosEjemplo.ultimasMedidas,
  ultimosTests = datosEjemplo.ultimosTests,
  ultimosLogros = datosEjemplo.ultimosLogros,
}: ResumenDeportivoProps) {
  const getEvaluacionColor = (evaluacion: string) => {
    switch (evaluacion.toLowerCase()) {
      case "excelente":
        return "bg-green-100 text-green-800"
      case "bueno":
        return "bg-blue-100 text-blue-800"
      case "promedio":
        return "bg-yellow-100 text-yellow-800"
      case "regular":
        return "bg-orange-100 text-orange-800"
      case "mejorable":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-[#1E40AF]">Formación Deportiva</h2>
        <Button variant="outline" size="sm" asChild>
          <Link href="/dashboard/deportes">
            Ver todo
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Club Deportivo */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Trophy className="h-5 w-5 text-[#3B82F6]" />
              Club Deportivo
            </CardTitle>
          </CardHeader>
          <CardContent>
            {clubDeportivo ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-lg">{clubDeportivo.nombre}</h3>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                    {clubDeportivo.deporte}
                  </Badge>
                  <Badge variant="outline">{clubDeportivo.categoria}</Badge>
                </div>
                {clubDeportivo.proximoEntrenamiento && (
                  <p className="text-sm text-muted-foreground">
                    Próximo entrenamiento: {clubDeportivo.proximoEntrenamiento}
                  </p>
                )}
                <Button variant="link" className="p-0" asChild>
                  <Link href="/dashboard/deportes/club">Ver detalles del club</Link>
                </Button>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No estás afiliado a ningún club deportivo</p>
                <Button variant="link" asChild>
                  <Link href="/dashboard/deportes/club">Unirse a un club</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Medidas Físicas */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Ruler className="h-5 w-5 text-[#3B82F6]" />
              Medidas Físicas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {ultimasMedidas ? (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Última medición: {new Date(ultimasMedidas.fecha).toLocaleDateString()}
                </p>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Altura</p>
                    <p className="font-medium">{ultimasMedidas.altura} cm</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Peso</p>
                    <p className="font-medium">{ultimasMedidas.peso} kg</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">IMC</p>
                    <p className="font-medium">{ultimasMedidas.imc}</p>
                  </div>
                </div>
                <Button variant="link" className="p-0" asChild>
                  <Link href="/dashboard/deportes/medidas">Ver historial completo</Link>
                </Button>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No hay medidas registradas</p>
                <Button variant="link" asChild>
                  <Link href="/dashboard/deportes/medidas">Registrar medidas</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tests Físicos */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Activity className="h-5 w-5 text-[#3B82F6]" />
              Tests Físicos Recientes
            </CardTitle>
          </CardHeader>
          <CardContent>
            {ultimosTests && ultimosTests.length > 0 ? (
              <div className="space-y-3">
                {ultimosTests.map((test, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{test.tipo}</p>
                      <p className="text-sm text-muted-foreground">{test.resultado}</p>
                    </div>
                    <Badge className={getEvaluacionColor(test.evaluacion)}>{test.evaluacion}</Badge>
                  </div>
                ))}
                <Button variant="link" className="p-0" asChild>
                  <Link href="/dashboard/deportes/tests">Ver todos los tests</Link>
                </Button>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No hay tests registrados</p>
                <Button variant="link" asChild>
                  <Link href="/dashboard/deportes/tests">Registrar test</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Logros Deportivos */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Award className="h-5 w-5 text-[#3B82F6]" />
              Últimos Logros
            </CardTitle>
          </CardHeader>
          <CardContent>
            {ultimosLogros && ultimosLogros.length > 0 ? (
              <div className="space-y-3">
                {ultimosLogros.map((logro, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{logro.evento}</p>
                      {logro.destacado && <Badge className="bg-yellow-100 text-yellow-800">Destacado</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{logro.resultado}</p>
                  </div>
                ))}
                <Button variant="link" className="p-0" asChild>
                  <Link href="/dashboard/deportes/records">Ver todos los logros</Link>
                </Button>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No hay logros registrados</p>
                <Button variant="link" asChild>
                  <Link href="/dashboard/deportes/records">Registrar logro</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

