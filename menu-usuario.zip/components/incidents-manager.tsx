"use client"

import React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Clock, FileX, RotateCcw, Search, Shield, UserX, XCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { Incident, IncidentLog } from "@/types/incidents"

// Datos de ejemplo
const mockIncidents: Incident[] = [
  {
    id: "1",
    type: "class_deletion",
    title: "Eliminación de clase de Matemáticas",
    description: "Se eliminó la clase de Matemáticas del grupo 10A programada para el 26/02/2024",
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    createdBy: {
      id: "prof123",
      name: "Juan Pérez",
      role: "profesor",
    },
    status: "pending",
    priority: "high",
    affectedData: {
      type: "class",
      id: "class123",
      details: {
        subject: "Matemáticas",
        group: "10A",
        date: "2024-02-26",
        teacher: "Juan Pérez",
      },
    },
  },
  {
    id: "2",
    type: "teacher_reassignment",
    title: "Reasignación masiva de profesores",
    description: "Se realizaron múltiples cambios en las asignaciones de profesores del departamento de Ciencias",
    createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    createdBy: {
      id: "dir456",
      name: "María González",
      role: "directivo",
    },
    status: "in_review",
    priority: "medium",
    affectedData: {
      type: "teacher",
      id: "dept123",
      details: {
        department: "Ciencias",
        affectedTeachers: ["prof123", "prof456", "prof789"],
        previousAssignments: {
          // Detalles de las asignaciones previas
        },
      },
    },
  },
]

const mockLogs: IncidentLog[] = [
  {
    id: "log1",
    incidentId: "1",
    timestamp: new Date().toISOString(),
    action: "Incident created",
    performedBy: "System",
    details: "Automatic detection of class deletion",
  },
  {
    id: "log2",
    incidentId: "1",
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    action: "Status updated",
    performedBy: "admin",
    details: "Changed status to 'in_review'",
  },
]

export function IncidentsManager() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterPriority, setFilterPriority] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false)

  const getStatusColor = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800",
      in_review: "bg-blue-100 text-blue-800",
      resolved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800",
    }
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getPriorityColor = (priority: string) => {
    const colors = {
      low: "bg-blue-100 text-blue-800",
      medium: "bg-yellow-100 text-yellow-800",
      high: "bg-orange-100 text-orange-800",
      critical: "bg-red-100 text-red-800",
    }
    return colors[priority as keyof typeof colors] || "bg-gray-100 text-gray-800"
  }

  const getTypeIcon = (type: string) => {
    const icons = {
      class_deletion: FileX,
      event_deletion: FileX,
      teacher_reassignment: RotateCcw,
      unauthorized_access: Shield,
      system_error: AlertTriangle,
      data_modification: UserX,
    }
    return icons[type as keyof typeof icons] || AlertTriangle
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("es", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const handleResolveIncident = (action: "restore" | "confirm_deletion") => {
    if (!selectedIncident) return

    // Aquí iría la lógica para resolver la incidencia
    console.log(`Resolving incident ${selectedIncident.id} with action: ${action}`)
    setIsConfirmationOpen(false)
    setIsDetailsOpen(false)
  }

  const filteredIncidents = mockIncidents.filter((incident) => {
    const matchesSearch =
      incident.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      incident.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPriority = filterPriority === "all" || incident.priority === filterPriority
    const matchesStatus = filterStatus === "all" || incident.status === filterStatus
    return matchesSearch && matchesPriority && matchesStatus
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl text-[#1E40AF]">Gestor de Incidencias</CardTitle>
        <CardDescription>Gestiona las incidencias reportadas en la plataforma</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="mb-6 space-y-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <Input
                placeholder="Buscar incidencias..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
                prefix={<Search className="h-4 w-4 text-gray-400" />}
              />
            </div>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por prioridad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las prioridades</SelectItem>
                <SelectItem value="low">Baja</SelectItem>
                <SelectItem value="medium">Media</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="critical">Crítica</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="pending">Pendiente</SelectItem>
                <SelectItem value="in_review">En revisión</SelectItem>
                <SelectItem value="resolved">Resuelto</SelectItem>
                <SelectItem value="rejected">Rechazado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Fecha</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Título</TableHead>
              <TableHead>Creado por</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Prioridad</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredIncidents.map((incident) => (
              <TableRow key={incident.id}>
                <TableCell className="whitespace-nowrap">{formatDate(incident.createdAt)}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {React.createElement(getTypeIcon(incident.type), {
                      className: "h-4 w-4",
                    })}
                    <span className="capitalize">{incident.type.replace("_", " ")}</span>
                  </div>
                </TableCell>
                <TableCell>{incident.title}</TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span>{incident.createdBy.name}</span>
                    <span className="text-sm text-gray-500">{incident.createdBy.role}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={getStatusColor(incident.status)}>{incident.status}</Badge>
                </TableCell>
                <TableCell>
                  <Badge className={getPriorityColor(incident.priority)}>{incident.priority}</Badge>
                </TableCell>
                <TableCell>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedIncident(incident)
                      setIsDetailsOpen(true)
                    }}
                  >
                    Ver detalles
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* Diálogo de detalles */}
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Detalles de la Incidencia</DialogTitle>
              <DialogDescription>Revisa los detalles y toma una acción</DialogDescription>
            </DialogHeader>

            {selectedIncident && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Información General</h4>
                    <div className="space-y-2">
                      <p>
                        <span className="text-gray-500">ID:</span> {selectedIncident.id}
                      </p>
                      <p>
                        <span className="text-gray-500">Creado:</span> {formatDate(selectedIncident.createdAt)}
                      </p>
                      <p>
                        <span className="text-gray-500">Por:</span> {selectedIncident.createdBy.name} (
                        {selectedIncident.createdBy.role})
                      </p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Estado Actual</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">Estado:</span>
                        <Badge className={getStatusColor(selectedIncident.status)}>{selectedIncident.status}</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">Prioridad:</span>
                        <Badge className={getPriorityColor(selectedIncident.priority)}>
                          {selectedIncident.priority}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Descripción</h4>
                  <p className="text-gray-700">{selectedIncident.description}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Datos Afectados</h4>
                  <pre className="bg-gray-50 p-4 rounded-lg overflow-auto">
                    {JSON.stringify(selectedIncident.affectedData.details, null, 2)}
                  </pre>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Historial</h4>
                  <div className="space-y-2">
                    {mockLogs
                      .filter((log) => log.incidentId === selectedIncident.id)
                      .map((log) => (
                        <div key={log.id} className="flex items-start gap-2 text-sm">
                          <Clock className="h-4 w-4 mt-0.5" />
                          <div>
                            <p className="text-gray-500">{formatDate(log.timestamp)}</p>
                            <p>
                              <span className="font-medium">{log.performedBy}</span> - {log.action}
                            </p>
                            <p className="text-gray-600">{log.details}</p>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                <DialogFooter className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Button variant="destructive" onClick={() => setIsConfirmationOpen(true)}>
                      <XCircle className="h-4 w-4 mr-2" />
                      Confirmar Eliminación
                    </Button>
                    <Button variant="outline" onClick={() => setIsConfirmationOpen(true)}>
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Restaurar
                    </Button>
                  </div>
                  <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                    Cerrar
                  </Button>
                </DialogFooter>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Diálogo de confirmación */}
        <Dialog open={isConfirmationOpen} onOpenChange={setIsConfirmationOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Acción</DialogTitle>
              <DialogDescription>
                ¿Estás seguro de que deseas realizar esta acción? Esta operación no se puede deshacer.
              </DialogDescription>
            </DialogHeader>

            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Advertencia</AlertTitle>
              <AlertDescription>
                Esta acción afectará a los datos del sistema y puede tener consecuencias en la operación de la
                plataforma.
              </AlertDescription>
            </Alert>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsConfirmationOpen(false)}>
                Cancelar
              </Button>
              <Button variant="destructive" onClick={() => handleResolveIncident("confirm_deletion")}>
                Confirmar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

