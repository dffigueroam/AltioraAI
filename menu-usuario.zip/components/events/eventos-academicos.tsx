"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Trophy, Medal, MonitorIcon as Running } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AgregarEventoForm } from "../forms/agregar-evento-form"
import { useToast } from "@/components/ui/use-toast"
import { useApi } from "@/hooks/useApi"

// Datos iniciales para desarrollo
const eventosIniciales = [
  {
    id: "1",
    titulo: "Exposición de Ciencias",
    fecha: "2024-03-15",
    hora: "09:00",
    tipo: "academico",
    estado: "próximo",
    descripcion: "Presentación de proyectos científicos",
    lugar: "Auditorio Principal",
  },
  {
    id: "2",
    titulo: "Reunión de Padres",
    fecha: "2024-03-20",
    hora: "14:30",
    tipo: "administrativo",
    estado: "próximo",
    descripcion: "Entrega de informes del primer periodo",
    lugar: "Salón Múltiple",
  },
  {
    id: "3",
    titulo: "Torneo Interescolar de Fútbol",
    fecha: "2024-03-18",
    hora: "15:00",
    tipo: "competencia",
    estado: "próximo",
    descripcion: "Partido semifinal contra Colegio San José",
    lugar: "Campo Deportivo Principal",
    categoria: "Sub-15",
    deporte: "Fútbol",
  },
  {
    id: "4",
    titulo: "Pruebas de Rendimiento Físico",
    fecha: "2024-03-25",
    hora: "10:00",
    tipo: "evaluacion",
    estado: "próximo",
    descripcion: "Evaluación trimestral de capacidades físicas",
    lugar: "Gimnasio",
    categoria: "General",
    deporte: "Múltiple",
  },
  {
    id: "5",
    titulo: "Competencia de Natación",
    fecha: "2024-04-05",
    hora: "09:00",
    tipo: "competencia",
    estado: "programado",
    descripcion: "Campeonato regional de natación",
    lugar: "Piscina Olímpica Municipal",
    categoria: "Juvenil",
    deporte: "Natación",
  },
]

interface EventosAcademicosProps {
  userRole: string
}

export function EventosAcademicos({ userRole }: EventosAcademicosProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const { toast } = useToast()

  // Usar el hook con datos iniciales para evitar estados de carga innecesarios
  const {
    data: eventos,
    isLoading,
    error,
    createItem: createEvento,
  } = useApi("events", {
    initialData: eventosIniciales,
    onSuccess: () => {
      toast({
        title: "Éxito",
        description: "Operación completada correctamente",
      })
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    },
  })

  const handleSubmitEvento = async (data: any) => {
    try {
      await createEvento(data)
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error al crear evento:", error)
    }
  }

  // Renderizado condicional para estados de carga y error
  if (isLoading && eventos.length === 0) return <div>Cargando...</div>
  if (error && eventos.length === 0) return <div>Error: {error.message}</div>

  const getTipoEvento = (tipo: string) => {
    switch (tipo) {
      case "academico":
        return <Badge className="bg-blue-100 text-blue-800">Académico</Badge>
      case "administrativo":
        return <Badge className="bg-purple-100 text-purple-800">Administrativo</Badge>
      case "competencia":
        return <Badge className="bg-green-100 text-green-800">Competencia</Badge>
      case "evaluacion":
        return <Badge className="bg-yellow-100 text-yellow-800">Evaluación</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800">{tipo}</Badge>
    }
  }

  const getIconoDeporte = (deporte: string) => {
    if (!deporte) return <Medal className="h-5 w-5 text-yellow-600" />

    switch (deporte.toLowerCase()) {
      case "fútbol":
        return <Trophy className="h-5 w-5 text-green-600" />
      case "natación":
        return <Running className="h-5 w-5 text-blue-600" />
      default:
        return <Medal className="h-5 w-5 text-yellow-600" />
    }
  }

  // Función segura para formatear fechas
  const formatearFecha = (fechaStr: string) => {
    try {
      return new Date(fechaStr).toLocaleDateString("es-ES", {
        day: "numeric",
        month: "short",
      })
    } catch (error) {
      console.error("Error al formatear fecha:", error)
      return fechaStr
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-[#1E40AF]">Eventos</CardTitle>
        <CardDescription>Calendario de actividades académicas y deportivas</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="todos" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="todos">Todos</TabsTrigger>
            <TabsTrigger value="academicos">Académicos</TabsTrigger>
            <TabsTrigger value="deportivos">Deportivos</TabsTrigger>
          </TabsList>

          <TabsContent value="todos">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-[#3B82F6]">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              {evento.deporte ? (
                                getIconoDeporte(evento.deporte)
                              ) : (
                                <Calendar className="h-5 w-5 text-[#3B82F6]" />
                              )}
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {getTipoEvento(evento.tipo)}
                              {evento.categoria && <Badge variant="outline">{evento.categoria}</Badge>}
                              {evento.deporte && <Badge variant="outline">{evento.deporte}</Badge>}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="academicos">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .filter((evento) => evento.tipo === "academico")
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-[#3B82F6]">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-5 w-5 text-[#3B82F6]" />
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex gap-2 mt-2">{getTipoEvento(evento.tipo)}</div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="deportivos">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .filter((evento) => evento.tipo === "competencia" || evento.tipo === "evaluacion")
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-green-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              {getIconoDeporte(evento.deporte)}
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {getTipoEvento(evento.tipo)}
                              {evento.categoria && <Badge variant="outline">{evento.categoria}</Badge>}
                              {evento.deporte && <Badge variant="outline">{evento.deporte}</Badge>}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {(userRole === "profesor" || userRole === "directivo") && (
          <>
            <div className="mt-4 flex justify-end">
              <Button className="bg-[#1E40AF]" onClick={() => setIsDialogOpen(true)}>
                Agregar Evento
              </Button>
            </div>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Agregar Nuevo Evento</DialogTitle>
                  <DialogDescription>
                    Complete el formulario para crear un nuevo evento académico o deportivo.
                  </DialogDescription>
                </DialogHeader>
                <AgregarEventoForm onSubmit={handleSubmitEvento} onCancel={() => setIsDialogOpen(false)} />
              </DialogContent>
            </Dialog>
          </>
        )}
      </CardContent>
    </Card>
  )
}

