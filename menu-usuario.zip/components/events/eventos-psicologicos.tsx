"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Brain, Users, Heart, MessageSquare } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AgregarEventoPsicologicoForm } from "../forms/agregar-evento-psicologico-form"
import { useToast } from "@/components/ui/use-toast"
import { useApi } from "@/hooks/useApi"

// Datos iniciales para desarrollo
const eventosPsicologicosIniciales = [
  {
    id: "1",
    titulo: "Sesión individual - Carlos Gómez",
    fecha: "2024-03-15",
    hora: "10:30",
    tipo: "terapia",
    estado: "programado",
    descripcion: "Seguimiento de ansiedad por exámenes",
    lugar: "Despacho de Orientación",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
  {
    id: "2",
    titulo: "Taller de gestión emocional",
    fecha: "2024-03-18",
    hora: "12:00",
    tipo: "taller",
    estado: "programado",
    descripcion: "Taller grupal para 3º ESO sobre manejo de estrés",
    lugar: "Aula 15",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
  {
    id: "3",
    titulo: "Evaluación psicológica - Laura Sánchez",
    fecha: "2024-03-20",
    hora: "09:15",
    tipo: "evaluacion",
    estado: "programado",
    descripcion: "Evaluación inicial por derivación del tutor",
    lugar: "Despacho de Orientación",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
  {
    id: "4",
    titulo: "Reunión con padres - Miguel Fernández",
    fecha: "2024-03-22",
    hora: "16:30",
    tipo: "psicologico",
    estado: "programado",
    descripcion: "Entrevista con padres para seguimiento de caso",
    lugar: "Sala de Reuniones",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
  {
    id: "5",
    titulo: "Reunión equipo docente 2º ESO",
    fecha: "2024-03-25",
    hora: "14:00",
    tipo: "psicologico",
    estado: "programado",
    descripcion: "Coordinación de estrategias para alumnos con necesidades especiales",
    lugar: "Sala de Profesores",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
  {
    id: "6",
    titulo: "Taller de habilidades sociales",
    fecha: "2024-03-27",
    hora: "11:00",
    tipo: "taller",
    estado: "programado",
    descripcion: "Grupo reducido de 1º ESO con dificultades de integración",
    lugar: "Aula de Apoyo",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: "psicologo",
  },
]

export function EventosPsicologicos() {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const { toast } = useToast()

  // Usar el hook con datos iniciales para evitar estados de carga innecesarios
  const {
    data: eventos,
    isLoading,
    error,
    createItem: createEvento,
  } = useApi("events", {
    initialData: eventosPsicologicosIniciales,
    onSuccess: () => {
      toast({
        title: "Éxito",
        description: "Evento psicológico creado correctamente",
      })
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      })
    },
  })

  const handleSubmitEvento = async (data: any) => {
    try {
      await createEvento(data)
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error al crear evento psicológico:", error)
    }
  }

  // Renderizado condicional para estados de carga y error
  if (isLoading && eventos.length === 0) return <div>Cargando...</div>
  if (error && eventos.length === 0) return <div>Error: {error.message}</div>

  const getTipoEvento = (tipo: string) => {
    switch (tipo) {
      case "terapia":
        return <Badge className="bg-blue-100 text-blue-800">Sesión Terapéutica</Badge>
      case "taller":
        return <Badge className="bg-green-100 text-green-800">Taller</Badge>
      case "evaluacion":
        return <Badge className="bg-yellow-100 text-yellow-800">Evaluación</Badge>
      case "psicologico":
        return <Badge className="bg-purple-100 text-purple-800">Reunión</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800">{tipo}</Badge>
    }
  }

  const getIconoEvento = (tipo: string) => {
    switch (tipo) {
      case "terapia":
        return <Heart className="h-5 w-5 text-pink-600" />
      case "taller":
        return <Users className="h-5 w-5 text-green-600" />
      case "evaluacion":
        return <Brain className="h-5 w-5 text-yellow-600" />
      case "psicologico":
        return <MessageSquare className="h-5 w-5 text-purple-600" />
      default:
        return <Calendar className="h-5 w-5 text-blue-600" />
    }
  }

  // Función segura para formatear fechas
  const formatearFecha = (fechaStr: string) => {
    try {
      return new Date(fechaStr).toLocaleDateString("es-ES", {
        day: "numeric",
        month: "short",
      })
    } catch (error) {
      console.error("Error al formatear fecha:", error)
      return fechaStr
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-[#1E40AF]">Eventos Psicológicos</CardTitle>
        <CardDescription>Gestión de sesiones, talleres y evaluaciones psicológicas</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="todos" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="todos">Todos</TabsTrigger>
            <TabsTrigger value="sesiones">Sesiones</TabsTrigger>
            <TabsTrigger value="talleres">Talleres</TabsTrigger>
            <TabsTrigger value="reuniones">Reuniones</TabsTrigger>
          </TabsList>

          <TabsContent value="todos">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-[#3B82F6]">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              {getIconoEvento(evento.tipo)}
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex flex-wrap gap-2 mt-2">{getTipoEvento(evento.tipo)}</div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="sesiones">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .filter((evento) => evento.tipo === "terapia")
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-pink-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Heart className="h-5 w-5 text-pink-600" />
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex gap-2 mt-2">{getTipoEvento(evento.tipo)}</div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="talleres">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .filter((evento) => evento.tipo === "taller")
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-green-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Users className="h-5 w-5 text-green-600" />
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex gap-2 mt-2">{getTipoEvento(evento.tipo)}</div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="reuniones">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {eventos
                  .filter((evento) => evento.tipo === "psicologico")
                  .map((evento) => (
                    <Card key={evento.id} className="border-l-4 border-l-purple-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <MessageSquare className="h-5 w-5 text-purple-600" />
                              <h4 className="font-semibold">{evento.titulo}</h4>
                            </div>
                            <p className="text-sm text-gray-500">{evento.descripcion}</p>
                            <div className="flex gap-2 mt-2">{getTipoEvento(evento.tipo)}</div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{formatearFecha(evento.fecha)}</p>
                            <p className="text-sm text-gray-500">{evento.hora}</p>
                            <p className="text-xs text-gray-500 mt-1">{evento.lugar}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        <div className="mt-4 flex justify-end">
          <Button className="bg-[#1E40AF]" onClick={() => setIsDialogOpen(true)}>
            Crear Evento
          </Button>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Crear Nuevo Evento Psicológico</DialogTitle>
              <DialogDescription>Complete el formulario para crear una sesión, taller o reunión.</DialogDescription>
            </DialogHeader>
            <AgregarEventoPsicologicoForm onSubmit={handleSubmitEvento} onCancel={() => setIsDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

