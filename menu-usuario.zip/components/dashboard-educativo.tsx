"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  BookOpen,
  Brain,
  Calendar,
  GraduationCap,
  Heart,
  MessageSquare,
  Settings,
  Users,
  AlertTriangle,
  Smile,
  TrendingUp,
  Star,
  Flag,
  Moon,
  AlertCircle,
  Plus,
  Clock,
  Shield,
} from "lucide-react"
import { TeacherClassroomOverview } from "./teacher-classroom-overview"
import { ClassroomSelector } from "./classroom-selector"
import Link from "next/link"
import type { Teacher, TeacherRole } from "@/types/teacher"
import { TemasClase } from "./temas-clase"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
// Remover estas importaciones
// import { format } from 'date-fns';
// import { es } from 'date-fns/locale';
import { StudentPsychologicalOverview } from "./student-psychological-overview"
import { ClassroomAssignments } from "./classroom-assignments"
import { AdminDashboard } from "./admin-dashboard"
// Añadir Avatar a las importaciones
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { EventosAcademicos } from "./events/eventos-academicos"
import { RankingAcademico } from "./ranking/ranking-academico"
import { FeedbackForm } from "./feedback-form"
import { ResumenDeportivo } from "@/components/dashboard/resumen-deportivo"

// Actualizar el tipo UserRole para incluir "psicologo"
type UserRole = "estudiante" | "profesor" | "padre" | "directivo" | "admin" | "psicologo"
type Gender = "male" | "female"

interface DashboardEducativoProps {
  initialRole?: UserRole
  isDemo?: boolean
}

// Añadir el ícono para el rol de psicólogo en roleIcons
const roleIcons = {
  estudiante: GraduationCap,
  profesor: Users,
  padre: Heart,
  directivo: Settings,
  admin: Settings,
  psicologo: Brain,
}

const generateRandomISCE = () => (Math.random() | (10 - 5 + 5)).toFixed(1)

const generateRandomSleepHours = () => (Math.random() * (10 - 5) + 5).toFixed(1)

const generateRandomProgress = () => `${Math.floor(Math.random() * 100)}%`

const generateRandomDaysUntilPeriod = () => Math.floor(Math.random() * 28) + 1

const generateRandomEmotionalState = () => {
  const states = ["Feliz", "Neutral", "Triste", "Ansiosa", "Energética"]
  return states[Math.floor(Math.random() * states.length)]
}

// Añadir los elementos del dashboard para el rol de psicólogo
const dashboardItems = {
  estudiante: [
    { icon: BookOpen, label: "Mis Cursos", value: "5 activos" },
    { icon: Smile, label: "Estado de Conducta", value: "Excelente" },
    { icon: TrendingUp, label: "Plan de Mejoramiento", value: "80% completado" },
    { icon: Brain, label: "Nivel de Estrés", value: "Bajo" },
    { icon: Heart, label: "Motivación", value: "Alta" },
    { icon: BarChart, label: "Progreso General", value: "75%" },
    { icon: Star, label: "Materias Sobresalientes", value: "Matemáticas, Ciencias" },
    { icon: Flag, label: "Materias en Mejora", value: "Filosofia" },
    { icon: Heart, label: "Diario de Emociones", value: "Ver Diario" }, // Added Diary of Emotions
  ],
  profesor: [
    { icon: Users, label: "Mis Estudiantes", value: "28 activos" },
    { icon: Calendar, label: "Próxima Clase", value: "En 2 horas" },
    { icon: Brain, label: "Sugerencias de Enseñanza", value: "3 nuevas" },
    { icon: MessageSquare, label: "Mensajes", value: "5 sin leer" },
  ],
  padre: [
    { icon: GraduationCap, label: "Progreso Académico", value: generateRandomProgress() },
    { icon: TrendingUp, label: "Avance del Plan de Mejoramiento", value: generateRandomProgress() },
    { icon: Smile, label: "Estado del Plan de Conducta", value: "En progreso" },
    { icon: Heart, label: "Bienestar Emocional", value: "Estable" },
    { icon: Calendar, label: "Próximo Evento", value: "Reunión de padres" },
    { icon: MessageSquare, label: "Comunicaciones", value: "2 nuevas" },
  ],
  directivo: [
    { icon: Users, label: "Total Estudiantes", value: "1250" },
    { icon: AlertTriangle, label: "Casos de Atención", value: "3 pendientes" },
    { icon: Brain, label: "Sugerencias IA", value: "5 nuevas" },
  ],
  admin: [
    { icon: Users, label: "Total Usuarios", value: "500" },
    { icon: AlertTriangle, label: "Alertas del Sistema", value: "10" },
    { icon: Settings, label: "Configuración", value: "Ajustes" },
  ],
  psicologo: [
    { icon: Users, label: "Estudiantes Asignados", value: "42 activos" },
    { icon: AlertTriangle, label: "Casos Críticos", value: "3 pendientes" },
    { icon: Calendar, label: "Próxima Sesión", value: "En 1 hora" },
    { icon: Brain, label: "Evaluaciones Pendientes", value: "8 por revisar" },
    { icon: MessageSquare, label: "Mensajes", value: "4 sin leer" },
    { icon: Heart, label: "Bienestar Emocional", value: "Monitoreo" },
  ],
}

export function DashboardEducativo({ initialRole = "estudiante", isDemo = false }: DashboardEducativoProps) {
  const [role, setRole] = useState<UserRole>(initialRole)
  const [selectedClassroom, setSelectedClassroom] = useState("3A")
  const [generalISCE, setGeneralISCE] = useState(generateRandomISCE())
  const [classroomISCE, setClassroomISCE] = useState(generateRandomISCE())
  const [studentName, setStudentName] = useState("Ana García")
  const [studentGender, setStudentGender] = useState<Gender>("female")
  const [sleepHours, setSleepHours] = useState({
    light: generateRandomSleepHours(),
    deep: generateRandomSleepHours(),
    average: generateRandomSleepHours(),
    yesterday: generateRandomSleepHours(),
  })
  const [daysUntilPeriod, setDaysUntilPeriod] = useState(generateRandomDaysUntilPeriod())
  const [emotionalState, setEmotionalState] = useState(generateRandomEmotionalState())
  const [teacherRole, setTeacherRole] = useState<TeacherRole>("normal")
  const [assignedClassroom, setAssignedClassroom] = useState<string | undefined>(undefined)

  // Agregamos estado para los grupos a los que da clase
  const [teachingClassrooms, setTeachingClassrooms] = useState<string[]>([])

  // Simulamos un profesor para demostración
  const [teacher, setTeacher] = useState<Teacher>({
    id: "1",
    name: "Juan Pérez",
    role: "normal",
  })
  const RoleIcon = roleIcons[role]
  const [feedbackOpen, setFeedbackOpen] = useState(false)

  useEffect(() => {
    // Simula la carga de datos del profesor
    if (role === "profesor") {
      // En una aplicación real, esto vendría de una API o base de datos
      const mockTeacher: Teacher = {
        id: "1",
        name: "Juan Pérez",
        role: Math.random() > 0.5 ? "director_grupo" : "normal",
        assignedClassroom: "3A",
        teachingClassrooms: ["3A", "3B", "4A", "5B"], // Simulamos grupos a los que da clase
      }
      setTeacher(mockTeacher)
      setTeacherRole(mockTeacher.role)
      setAssignedClassroom(mockTeacher.assignedClassroom)
      setTeachingClassrooms(mockTeacher.teachingClassrooms)
    }
    if (role === "directivo") {
      setClassroomISCE(generateRandomISCE())
    }
  }, [role])

  // Actualizar el rol cuando cambia initialRole
  useEffect(() => {
    setRole(initialRole)
  }, [initialRole])

  const directivoItems = [
    { icon: BarChart, label: "ISCE General", value: generalISCE },
    { icon: BarChart, label: `ISCE ${selectedClassroom}`, value: classroomISCE },
    ...dashboardItems.directivo,
  ]

  const studentItems = [
    ...dashboardItems.estudiante,
    { icon: Moon, label: "Horas de Sueño Ligero", value: `${sleepHours.light}h` },
    { icon: Moon, label: "Horas de Sueño Profundo", value: `${sleepHours.deep}h` },
    { icon: Moon, label: "Promedio de Sueño", value: `${sleepHours.average}h` },
    { icon: Moon, label: "Sueño de Ayer", value: `${sleepHours.yesterday}h` },
  ]

  if (studentGender === "female") {
    studentItems.push(
      { icon: Calendar, label: "Días hasta próximo período", value: daysUntilPeriod.toString() },
      { icon: Heart, label: "Estado Emocional", value: emotionalState },
    )
  }

  // Modificar la sección del encabezado del dashboard donde se muestra el nombre del usuario
  const getRoleDisplay = () => {
    if (role === "estudiante") {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt={studentName} />
            <AvatarFallback className="bg-[#1E40AF] text-white text-2xl">
              {studentName
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#1E40AF]">Bienvenida, {studentName}</h2>
            <p className="text-lg text-slate-600">Estudiante</p>
          </div>
        </div>
      )
    } else if (role === "profesor") {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt={teacher.name} />
            <AvatarFallback className="bg-[#1E40AF] text-white text-2xl">
              {teacher.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#1E40AF]">Bienvenido, {teacher.name}</h2>
            <div className="flex flex-wrap items-center gap-2">
              {teacherRole === "director_grupo" && assignedClassroom && (
                <span className="bg-[#EC4899] text-white px-3 py-1 rounded-full text-sm">
                  Director del Grupo {assignedClassroom}
                </span>
              )}
              <span className="bg-[#2563EB] text-white px-3 py-1 rounded-full text-sm">
                Profesor de {teachingClassrooms.length} grupos
              </span>
            </div>
          </div>
        </div>
      )
    } else if (role === "directivo") {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Directivo" />
            <AvatarFallback className="bg-[#1E40AF] text-white text-2xl">DIR</AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#1E40AF]">Bienvenido, Director</h2>
            <p className="text-lg text-slate-600">Directivo Académico</p>
          </div>
        </div>
      )
    } else if (role === "padre") {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Padre/Acudiente" />
            <AvatarFallback className="bg-[#1E40AF] text-white text-2xl">PA</AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#1E40AF]">Bienvenido, Acudiente</h2>
            <p className="text-lg text-slate-600">Padre/Acudiente</p>
          </div>
        </div>
      )
    } else if (role === "psicologo") {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Psicólogo" />
            <AvatarFallback className="bg-[#7E22CE] text-white text-2xl">PSI</AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#7E22CE]">Bienvenido, Dr. Martínez</h2>
            <p className="text-lg text-slate-600">Psicólogo Escolar</p>
          </div>
        </div>
      )
    } else {
      return (
        <div className="flex items-center gap-6">
          <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Admin" />
            <AvatarFallback className="bg-[#1E40AF] text-white text-2xl">ADM</AvatarFallback>
          </Avatar>
          <div className="space-y-2">
            <h2 className="text-4xl font-bold text-[#1E40AF]">Bienvenido, Administrador</h2>
            <p className="text-lg text-slate-600">Administrador del Sistema</p>
          </div>
        </div>
      )
    }
  }

  const [activeTab, setActiveTab] = useState("overview")

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("es", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  const pendingTests = [
    {
      id: "stress-1",
      title: "Evaluación Inicial de Estrés",
      type: "stress",
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 días después
      priority: "alta",
    },
    {
      id: "anxiety-1",
      title: "Evaluación de Ansiedad",
      type: "anxiety",
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 días después
      priority: "media",
    },
    {
      id: "learning-1",
      title: "Estilo de Aprendizaje",
      type: "learning_style",
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 días después
      priority: "baja",
    },
  ]

  const getPriorityForTest = (test: any) => {
    // Si es un cuestionario relacionado con eventos
    if (test.eventRelated) {
      const daysUntilEvent = Math.floor(
        (new Date(test.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
      )

      if (daysUntilEvent <= 1) return "alta"
      if (daysUntilEvent <= 3) return "media"
      return "baja"
    }

    // Para otros tipos de cuestionarios
    return "baja"
  }

  // Ordenar los tests pendientes priorizando los relacionados con eventos
  const sortedPendingTests = pendingTests.sort((a, b) => {
    const priorityOrder = { alta: 0, media: 1, baja: 2 }
    const priorityA = getPriorityForTest(a)
    const priorityB = getPriorityForTest(b)

    return priorityOrder[priorityA] - priorityOrder[priorityB]
  })

  if (role === "admin") {
    return (
      <div className="flex flex-col h-full bg-white text-slate-900">
        <header className="bg-[#1E40AF] text-white p-4">
          <div className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-2xl font-bold">
              ALTIORA AI
            </Link>
            <div className="flex items-center gap-2">
              <Settings className="h-6 w-6 text-[#EC4899]" />
              {!isDemo && (
                <select
                  className="bg-[#1E40AF] text-white border-none font-semibold focus:outline-none focus:ring-2 focus:ring-[#3B82F6]"
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                >
                  <option value="estudiante">Estudiante</option>
                  <option value="profesor">Profesor</option>
                  <option value="padre">Padre/Acudiente</option>
                  <option value="directivo">Directivo</option>
                  <option value="admin">Admin</option>
                </select>
              )}
              <span className="font-semibold">Administrador</span>
            </div>
          </div>
        </header>
        {/* Modificar la sección donde se muestra el encabezado en el main */}
        <main className="flex-grow p-6 overflow-auto">
          <div className="container mx-auto">
            {isDemo && (
              <Alert className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Estás viendo una demostración de la plataforma. Para acceder a todas las funcionalidades,{" "}
                  <Link href="/registro" className="font-medium text-[#1E40AF] hover:underline">
                    regístrate
                  </Link>{" "}
                  o{" "}
                  <Link href="/login" className="font-medium text-[#1E40AF] hover:underline">
                    inicia sesión
                  </Link>
                  .
                </AlertDescription>
              </Alert>
            )}

            <div className="mb-10">{getRoleDisplay()}</div>

            <h2 className="text-3xl font-bold mb-6">Panel de Administración</h2>

            {/* Cards de resumen para el admin */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              {[
                {
                  icon: AlertTriangle,
                  label: "Incidencias Pendientes",
                  value: "5",
                  color: "text-red-600",
                },
                {
                  icon: Clock,
                  label: "Logs del Sistema",
                  value: "128",
                  color: "text-blue-600",
                },
                {
                  icon: Shield,
                  label: "Alertas de Seguridad",
                  value: "2",
                  color: "text-yellow-600",
                },
                {
                  icon: Users,
                  label: "Usuarios Activos",
                  value: "1,234",
                  color: "text-green-600",
                },
              ].map((item, index) => (
                <Card
                  key={index}
                  className="bg-white border-[#3B82F6] border hover:border-[#1E40AF] transition-colors duration-300"
                >
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-[#1E40AF]">{item.label}</CardTitle>
                    <item.icon className={`h-4 w-4 ${item.color}`} />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{item.value}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <AdminDashboard />
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-white text-slate-900">
      <div className="bg-[#1E40AF] text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <RoleIcon className="h-6 w-6 text-[#EC4899]" />
            {!isDemo && (
              <select
                className="bg-[#1E40AF] text-white border-none font-semibold focus:outline-none focus:ring-2 focus:ring-[#3B82F6]"
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
              >
                <option value="estudiante">Estudiante</option>
                <option value="profesor">Profesor</option>
                <option value="padre">Padre/Acudiente</option>
                <option value="directivo">Directivo</option>
                <option value="admin">Admin</option>
                <option value="psicologo">Psicologo</option>
              </select>
            )}
            <span className="font-semibold">{role.charAt(0).toUpperCase() + role.slice(1)}</span>
          </div>
        </div>
      </div>
      <main className="flex-grow p-6 overflow-auto">
        <div className="container mx-auto">
          {isDemo && (
            <Alert className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Estás viendo una demostración de la plataforma. Para acceder a todas las funcionalidades,{" "}
                <Link href="/registro" className="font-medium text-[#1E40AF] hover:underline">
                  regístrate
                </Link>{" "}
                o{" "}
                <Link href="/login" className="font-medium text-[#1E40AF] hover:underline">
                  inicia sesión
                </Link>
                .
              </AlertDescription>
            </Alert>
          )}

          <div className="mb-10">{getRoleDisplay()}</div>

          {/* Cards del dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {(role === "directivo" ? directivoItems : role === "estudiante" ? studentItems : dashboardItems[role]).map(
              (item, index) => (
                <Card
                  key={index}
                  className="bg-white border-[#3B82F6] border hover:border-[#1E40AF] transition-colors duration-300"
                >
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-[#1E40AF]">{item.label}</CardTitle>
                    <item.icon className="h-4 w-4 text-[#3B82F6]" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{item.value}</div>
                  </CardContent>
                </Card>
              ),
            )}
          </div>

          {/* Panel informativo para profesores */}
          {role === "profesor" && (
            <>
              <div className="bg-[#EFF6FF] border border-[#3B82F6] rounded-lg p-4 mb-4 mt-6">
                <h3 className="text-[#1E40AF] font-semibold mb-2">Grupos Asignados</h3>
                <div className="space-y-2">
                  {teacherRole === "director_grupo" && assignedClassroom && (
                    <p className="text-slate-600">
                      <span className="font-medium">Director del grupo:</span>{" "}
                      <span className="text-[#1E40AF]">{assignedClassroom}</span>
                    </p>
                  )}
                  <p className="text-slate-600">
                    <span className="font-medium">Grupos a los que da clase:</span>{" "}
                    <span className="text-[#1E40AF]">{teachingClassrooms.join(", ")}</span>
                  </p>
                </div>
              </div>

              {/* Selector de aulas y vista de grupo */}
              <div className="mt-6">
                <div className="mb-4">
                  <ClassroomSelector
                    onSelectClassroom={setSelectedClassroom}
                    assignedClassroom={assignedClassroom}
                    teachingClassrooms={teachingClassrooms}
                    isDirectorGrupo={teacherRole === "director_grupo"}
                  />
                </div>
                <TeacherClassroomOverview
                  classroomId={selectedClassroom}
                  isDirectorGrupo={teacherRole === "director_grupo" && selectedClassroom === assignedClassroom}
                />
              </div>
            </>
          )}

          {/* Modificar la sección del dashboard del directivo para incluir la asignación de profesores */}
          {role === "directivo" && (
            <>
              <div className="mt-6">
                <Tabs defaultValue="assignments" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="assignments">Asignación de Profesores</TabsTrigger>
                    <TabsTrigger value="discipline">Casos Disciplinarios</TabsTrigger>
                    <TabsTrigger value="events">Eventos</TabsTrigger>
                    <TabsTrigger value="ranking">Ranking Académico</TabsTrigger>
                    <TabsTrigger value="reports">Gestión sugerida de la IA</TabsTrigger>
                  </TabsList>
                  <TabsContent value="assignments">
                    <div className="grid gap-6">
                      <div className="mb-4">
                        <ClassroomSelector
                          onSelectClassroom={setSelectedClassroom}
                          assignedClassroom={undefined}
                          teachingClassrooms={[]}
                          isDirectorGrupo={false}
                        />
                      </div>
                      <ClassroomAssignments classroomId={selectedClassroom} />
                    </div>
                  </TabsContent>
                  <TabsContent value="discipline">
                    <Tabs defaultValue="active" className="space-y-4">
                      <TabsList>
                        <TabsTrigger value="active">Casos Activos</TabsTrigger>
                        <TabsTrigger value="archived">Casos Archivados</TabsTrigger>
                      </TabsList>

                      <TabsContent value="active">
                        <Card>
                          <CardHeader>
                            <div className="flex justify-between items-center">
                              <div>
                                <CardTitle className="text-[#1E40AF]">Casos Disciplinarios Activos</CardTitle>
                                <CardDescription>Gestión de casos disciplinarios en curso</CardDescription>
                              </div>
                              <Button className="bg-[#1E40AF]">
                                <Plus className="h-4 w-4 mr-2" />
                                Nuevo Caso
                              </Button>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>ID Caso</TableHead>
                                  <TableHead>Involucrado</TableHead>
                                  <TableHead>Tipo</TableHead>
                                  <TableHead>Fecha Inicio</TableHead>
                                  <TableHead>Estado</TableHead>
                                  <TableHead>Prioridad</TableHead>
                                  <TableHead>Acciones</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {[
                                  {
                                    id: "CD-001",
                                    name: "Juan Pérez",
                                    role: "Estudiante",
                                    type: "Conducta Disruptiva",
                                    startDate: "2024-02-25",
                                    status: "En Proceso",
                                    priority: "Alta",
                                    grade: "10A",
                                  },
                                  {
                                    id: "CD-002",
                                    name: "María González",
                                    role: "Profesor",
                                    type: "Incumplimiento",
                                    startDate: "2024-02-24",
                                    status: "Pendiente",
                                    priority: "Media",
                                    department: "Matemáticas",
                                  },
                                  {
                                    id: "CD-003",
                                    name: "Carlos Rodríguez",
                                    role: "Estudiante",
                                    type: "Acoso Escolar",
                                    startDate: "2024-02-23",
                                    status: "En Revisión",
                                    priority: "Alta",
                                    grade: "8B",
                                  },
                                ].map((caso) => (
                                  <TableRow key={caso.id}>
                                    <TableCell className="font-medium">{caso.id}</TableCell>
                                    <TableCell>
                                      <div className="flex flex-col">
                                        <span>{caso.name}</span>
                                        <span className="text-sm text-muted-foreground">
                                          {caso.role} - {caso.role === "Estudiante" ? caso.grade : caso.department}
                                        </span>
                                      </div>
                                    </TableCell>
                                    <TableCell>{caso.type}</TableCell>
                                    <TableCell>{new Date(caso.startDate).toLocaleDateString()}</TableCell>
                                    <TableCell>
                                      <Badge
                                        className={
                                          caso.status === "En Proceso"
                                            ? "bg-yellow-100 text-yellow-800"
                                            : caso.status === "Pendiente"
                                              ? "bg-red-100 text-red-800"
                                              : "bg-blue-100 text-blue-800"
                                        }
                                      >
                                        {caso.status}
                                      </Badge>
                                    </TableCell>
                                    <TableCell>
                                      <Badge
                                        className={
                                          caso.priority === "Alta"
                                            ? "bg-red-100 text-red-800"
                                            : "bg-yellow-100 text-yellow-800"
                                        }
                                      >
                                        {caso.priority}
                                      </Badge>
                                    </TableCell>
                                    <TableCell>
                                      <div className="flex items-center gap-2">
                                        <Button variant="outline" size="sm">
                                          Ver Detalles
                                        </Button>
                                        <Button variant="outline" size="sm" className="text-green-600">
                                          Actualizar
                                        </Button>
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </CardContent>
                        </Card>
                      </TabsContent>

                      <TabsContent value="archived">
                        <Card>
                          <CardHeader>
                            <CardTitle className="text-[#1E40AF]">Casos Disciplinarios Archivados</CardTitle>
                            <CardDescription>Historial de casos disciplinarios resueltos</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>ID Caso</TableHead>
                                  <TableHead>Involucrado</TableHead>
                                  <TableHead>Tipo</TableHead>
                                  <TableHead>Fecha Inicio</TableHead>
                                  <TableHead>Fecha Cierre</TableHead>
                                  <TableHead>Resolución</TableHead>
                                  <TableHead>Acciones</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {[
                                  {
                                    id: "CD-001-A",
                                    name: "Ana Martínez",
                                    role: "Estudiante",
                                    type: "Conducta Disruptiva",
                                    startDate: "2024-01-15",
                                    endDate: "2024-02-01",
                                    resolution: "Sanción Cumplida",
                                    grade: "9A",
                                  },
                                  {
                                    id: "CD-002-A",
                                    name: "Pedro Sánchez",
                                    role: "Profesor",
                                    type: "Incumplimiento",
                                    startDate: "2024-01-10",
                                    endDate: "2024-01-30",
                                    resolution: "Amonestación",
                                    department: "Ciencias",
                                  },
                                ].map((caso) => (
                                  <TableRow key={caso.id}>
                                    <TableCell className="font-medium">{caso.id}</TableCell>
                                    <TableCell>
                                      <div className="flex flex-col">
                                        <span>{caso.name}</span>
                                        <span className="text-sm text-muted-foreground">
                                          {caso.role} - {caso.role === "Estudiante" ? caso.grade : caso.department}
                                        </span>
                                      </div>
                                    </TableCell>
                                    <TableCell>{caso.type}</TableCell>
                                    <TableCell>{new Date(caso.startDate).toLocaleDateString()}</TableCell>
                                    <TableCell>{new Date(caso.endDate).toLocaleDateString()}</TableCell>
                                    <TableCell>
                                      <Badge className="bg-green-100 text-green-800">{caso.resolution}</Badge>
                                    </TableCell>
                                    <TableCell>
                                      <Button variant="outline" size="sm">
                                        Ver Historial
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </CardContent>
                        </Card>
                      </TabsContent>
                    </Tabs>
                  </TabsContent>
                  <TabsContent value="events">
                    <EventosAcademicos userRole={role} />
                  </TabsContent>
                  <TabsContent value="ranking">
                    <RankingAcademico />
                  </TabsContent>
                  <TabsContent value="reports">{/* Contenido existente de reportes */}</TabsContent>{" "}
                  <TabsContent value="reports">{/* Contenido existente de reportes */}</TabsContent>
                </Tabs>
              </div>
            </>
          )}

          {/* Tabs para diferentes vistas */}
          {role !== "directivo" && role !== "admin" && (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
              <TabsList>
                {(role === "profesor" || role === "padre") && <TabsTrigger value="temas">Temas de Clase</TabsTrigger>}
                <TabsTrigger value="actions">Acciones Pendientes</TabsTrigger>
                <TabsTrigger value="events">Eventos</TabsTrigger>
                {role === "estudiante" && <TabsTrigger value="resources">Enlaces de Interés</TabsTrigger>}
                {role === "estudiante" && <TabsTrigger value="sports">Deportes</TabsTrigger>}
                <TabsTrigger value="reports">Gestión sugerida de la IA</TabsTrigger>
                {role === "estudiante" && <TabsTrigger value="emotions">Diario de Emociones</TabsTrigger>}{" "}
                {/* Added Diary of Emotions tab */}
              </TabsList>

              <TabsContent value="temas" className="mt-6">
                {role === "profesor" && <TemasClase />}
                {role === "padre" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Temas de Clase</CardTitle>
                      <CardDescription>
                        Aquí podrás ver los temas que los profesores han programado para las clases de tu hijo/a.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Mostrar los temas de clase en modo solo lectura */}
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <h3 className="font-medium text-slate-900 mb-2">Matemáticas - Próxima Clase</h3>
                          <p className="text-slate-600">Tema: Ecuaciones de Segundo Grado</p>
                          <p className="text-slate-600">Fecha: 28 de Febrero, 2024</p>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="secondary">Material Asignado</Badge>
                            <Badge variant="secondary">Tarea Pendiente</Badge>
                          </div>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <h3 className="font-medium text-slate-900 mb-2">Ciencias Naturales - Última Clase</h3>
                          <p className="text-slate-600">Tema: Sistema Solar</p>
                          <p className="text-slate-600">Fecha: 26 de Febrero, 2024</p>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="secondary">Material Disponible</Badge>
                            <Badge variant="secondary">Tarea Completada</Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="actions" className="mt-6">
                {role === "estudiante" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Acciones Pendientes</CardTitle>
                      <CardDescription>
                        Evaluaciones y cuestionarios que requieren tu atención para ayudarnos a brindarte un mejor
                        apoyo.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-4">
                        {sortedPendingTests.map((test) => {
                          const priority = getPriorityForTest(test)
                          const priorityConfig = {
                            alta: {
                              icon: AlertTriangle,
                              bgColor: "bg-red-100",
                              textColor: "text-red-600",
                              badge: "bg-red-100 text-red-800",
                              label: "Prioridad alta",
                            },
                            media: {
                              icon: Clock,
                              bgColor: "bg-yellow-100",
                              textColor: "text-yellow-600",
                              badge: "bg-yellow-100 text-yellow-800",
                              label: "Prioridad media",
                            },
                            baja: {
                              icon: Brain,
                              bgColor: "bg-blue-100",
                              textColor: "text-blue-600",
                              badge: "bg-blue-100 text-blue-800",
                              label: "Opcional",
                            },
                          }[priority]
                          const Icon = priorityConfig.icon
                          return (
                            <Link key={test.id} href={`/dashboard/evaluaciones?test=${test.id}`} className="block">
                              <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:border-[#3B82F6] transition-colors">
                                <div className="flex items-center gap-4">
                                  <div
                                    className={`h-10 w-10 rounded-full flex items-center justify-center ${priorityConfig.bgColor} ${priorityConfig.textColor}`}
                                  >
                                    <Icon className="h-5 w-5" />
                                  </div>
                                  <div>
                                    <h4 className="font-medium text-gray-900">{test.title}</h4>
                                    <p className="text-sm text-gray-500">
                                      {priority === "baja" ? "Disponible hasta el" : "Vence el"}{" "}
                                      {formatDate(test.dueDate)}
                                    </p>
                                  </div>
                                </div>
                                <Badge variant="secondary" className={priorityConfig.badge}>
                                  {priorityConfig.label}
                                </Badge>
                              </div>
                            </Link>
                          )
                        })}
                      </div>
                      <div className="mt-4">
                        <Button
                          variant="outline"
                          className="w-full text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                          asChild
                        >
                          <Link href="/dashboard/evaluaciones">Ver todas las evaluaciones</Link>
                        </Button>
                      </div>
                      {role === "estudiante" && (
                        <Card className="bg-white border-[#3B82F6] mt-4">
                          <CardHeader>
                            <CardTitle className="text-[#1E40AF]">Ayúdanos a Mejorar</CardTitle>
                            <CardDescription>
                              Tu opinión es importante para nosotros. Comparte tu experiencia con la plataforma.
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-6">
                            <div className="flex justify-center">
                              <Button
                                variant="outline"
                                className="text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                                onClick={() => setFeedbackOpen(true)}
                              >
                                Calificar la Plataforma
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </CardContent>
                  </Card>
                )}
                {role === "profesor" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Acciones Pendientes</CardTitle>
                      <CardDescription>
                        Estudiantes que requieren atención especial basada en su estado emocional y académico
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <StudentPsychologicalOverview
                        classroomId={selectedClassroom}
                        isDirectorGrupo={teacherRole === "director_grupo" && selectedClassroom === assignedClassroom}
                      />
                    </CardContent>
                    {role === "profesor" && (
                      <Card className="bg-white border-[#3B82F6] mt-4">
                        <CardHeader>
                          <CardTitle className="text-[#1E40AF]">Ayúdanos a Mejorar</CardTitle>
                          <CardDescription>
                            Como educador, tu opinión es fundamental. Comparte tu experiencia con la plataforma.
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                          <div className="flex justify-center">
                            <Button
                              variant="outline"
                              className="text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                              onClick={() => setFeedbackOpen(true)}
                            >
                              Calificar la Plataforma
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </Card>
                )}
                {role === "padre" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Acciones Pendientes</CardTitle>
                      <CardDescription>
                        Aquí verás las acciones sugeridas por la plataforma basadas en el desempeño de tu hijo/a.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {role === "padre" && (
                        <div className="text-center py-8 text-slate-500">
                          <p>No hay acciones pendientes en este momento.</p>
                          <p className="text-sm mt-2">
                            Las acciones se generarán automáticamente cuando la plataforma detecte situaciones que
                            requieran tu atención.
                          </p>
                        </div>
                      )}
                      {role === "padre" && (
                        <Card className="bg-white border-[#3B82F6] mt-4">
                          <CardHeader>
                            <CardTitle className="text-[#1E40AF]">Ayúdanos a Mejorar</CardTitle>
                            <CardDescription>
                              Como padre/acudiente, tu opinión nos ayuda a mejorar la experiencia educativa de tu
                              hijo/a.
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-6">
                            <div className="flex justify-center">
                              <Button
                                variant="outline"
                                className="text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                                onClick={() => setFeedbackOpen(true)}
                              >
                                Calificar la Plataforma
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="events" className="mt-6">
                <EventosAcademicos userRole={role} />
              </TabsContent>

              <TabsContent value="sports" className="mt-6">
                {role === "estudiante" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Resumen Deportivo</CardTitle>
                      <CardDescription>
                        Aquí encontrarás toda la información sobre tu desarrollo deportivo
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResumenDeportivo />
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="resources" className="mt-6">
                {role === "estudiante" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Enlaces Educativos Recomendados</CardTitle>
                      <CardDescription>
                        Recursos seleccionados por tus profesores para complementar tu aprendizaje
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="matematicas" className="space-y-4">
                        <TabsList className="flex flex-wrap gap-2">
                          <TabsTrigger value="matematicas">Matemáticas</TabsTrigger>
                          <TabsTrigger value="ciencias">Ciencias</TabsTrigger>
                          <TabsTrigger value="lenguaje">Lenguaje</TabsTrigger>
                          <TabsTrigger value="historia">Historia</TabsTrigger>
                          <TabsTrigger value="fisica">Física</TabsTrigger>
                          <TabsTrigger value="quimica">Química</TabsTrigger>
                        </TabsList>
                        <TabsContent value="matematicas">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {[
                              {
                                id: 1,
                                title: "Introducción al Álgebra",
                                thumbnail: "/placeholder.svg?height=120&width=200",
                                url: "https://youtube.com/watch?v=example1",
                                description: "Conceptos básicos de álgebra para principiantes",
                                duration: "15:30",
                                topic: "Álgebra",
                                isNew: true,
                              },
                              {
                                id: 2,
                                title: "Geometría Básica",
                                thumbnail: "/placeholder.svg?height=120&width=200",
                                url: "https://youtube.com/watch?v=example2",
                                description: "Aprende sobre formas y ángulos",
                                duration: "12:45",
                                topic: "Geometría",
                                isRecommended: true,
                              },
                              {
                                id: 3,
                                title: "Trigonometría Avanzada",
                                thumbnail: "/placeholder.svg?height=120&width=200",
                                url: "https://youtube.com/watch?v=example3",
                                description: "Funciones trigonométricas y sus aplicaciones",
                                duration: "20:15",
                                topic: "Trigonometría",
                              },
                            ].map((video) => (
                              <Card key={video.id} className="overflow-hidden hover:border-[#1E40AF] transition-colors">
                                <div className="relative">
                                  <img
                                    src={video.thumbnail || "/placeholder.svg"}
                                    alt={video.title}
                                    className="w-full h-[120px] object-cover"
                                  />
                                  <div className="absolute bottom-2 right-2 bg-black/75 text-white px-2 py-0.5 text-xs rounded">
                                    {video.duration}
                                  </div>
                                  {video.isNew && (
                                    <Badge className="absolute top-2 left-2 bg-green-100 text-green-800">Nuevo</Badge>
                                  )}
                                  {video.isRecommended && (
                                    <Badge className="absolute top-2 left-2 bg-blue-100 text-blue-800">
                                      Recomendado
                                    </Badge>
                                  )}
                                </div>
                                <CardHeader className="p-4">
                                  <CardTitle className="text-base">{video.title}</CardTitle>
                                  <Badge variant="secondary" className="w-fit">
                                    {video.topic}
                                  </Badge>
                                </CardHeader>
                                <CardContent className="p-4 pt-0">
                                  <p className="text-sm text-slate-600 mb-4">{video.description}</p>
                                  <Button
                                    variant="outline"
                                    className="w-full text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                                    asChild
                                  >
                                    <a href={video.url} target="_blank" rel="noopener noreferrer">
                                      Ver Video
                                    </a>
                                  </Button>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </TabsContent>
                        <TabsContent value="ciencias">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {[
                              {
                                id: 1,
                                title: "El Sistema Solar",
                                thumbnail: "/placeholder.svg?height=120&width=200",
                                url: "https://youtube.com/watch?v=example4",
                                description: "Explora los planetas y sus características",
                                duration: "18:20",
                                topic: "Astronomía",
                                isNew: true,
                              },
                              {
                                id: 2,
                                title: "La Célula",
                                thumbnail: "/placeholder.svg?height=120&width=200",
                                url: "https://youtube.com/watch?v=example5",
                                description: "Estructura y funciones celulares",
                                duration: "14:30",
                                topic: "Biología",
                                isRecommended: true,
                              },
                            ].map((video) => (
                              <Card key={video.id} className="overflow-hidden hover:border-[#1E40AF] transition-colors">
                                <div className="relative">
                                  <img
                                    src={video.thumbnail || "/placeholder.svg"}
                                    alt={video.title}
                                    className="w-full h-[120px] object-cover"
                                  />
                                  <div className="absolute bottom-2 right-2 bg-black/75 text-white px-2 py-0.5 text-xs rounded">
                                    {video.duration}
                                  </div>
                                  {video.isNew && (
                                    <Badge className="absolute top-2 left-2 bg-green-100 text-green-800">Nuevo</Badge>
                                  )}
                                  {video.isRecommended && (
                                    <Badge className="absolute top-2 left-2 bg-blue-100 text-blue-800">
                                      Recomendado
                                    </Badge>
                                  )}
                                </div>
                                <CardHeader className="p-4">
                                  <CardTitle className="text-base">{video.title}</CardTitle>
                                  <Badge variant="secondary" className="w-fit">
                                    {video.topic}
                                  </Badge>
                                </CardHeader>
                                <CardContent className="p-4 pt-0">
                                  <p className="text-sm text-slate-600 mb-4">{video.description}</p>
                                  <Button
                                    variant="outline"
                                    className="w-full text-[#1E40AF] border-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                                    asChild
                                  >
                                    <a href={video.url} target="_blank" rel="noopener noreferrer">
                                      Ver Video
                                    </a>
                                  </Button>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </TabsContent>
                        {/* Contenido similar para otras materias */}
                      </Tabs>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="reports" className="mt-6">
                <Card className="bg-white border-[#3B82F6]">
                  <CardHeader>
                    <CardTitle className="text-[#1E40AF]">Gestión sugerida de la IA</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">
                      Recomendaciones y análisis personalizados generados por nuestra IA para optimizar tu experiencia
                      educativa.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="emotions" className="mt-6">
                {role === "estudiante" && (
                  <Card className="bg-white border-[#3B82F6]">
                    <CardHeader>
                      <CardTitle className="text-[#1E40AF]">Diario de Emociones</CardTitle>
                      <CardDescription>Registra tus emociones diarias para un mejor seguimiento.</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Aquí se mostraría el contenido del diario de emociones */}
                      <p>Contenido del diario de emociones</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          )}

          {/* Botón flotante para agregar temas rápidamente (solo visible para profesores) */}
          {role === "profesor" && activeTab !== "temas" && (
            <Button
              className="fixed bottom-6 right-6 bg-[#1E40AF] rounded-full p-4 shadow-lg hover:bg-[#1E40AF]/90"
              onClick={() => setActiveTab("temas")}
            >
              <Plus className="h-6 w-6" />
              <span className="sr-only">Agregar Tema</span>
            </Button>
          )}
        </div>
      </main>
      <FeedbackForm open={feedbackOpen} onOpenChange={setFeedbackOpen} />
    </div>
  )
}

