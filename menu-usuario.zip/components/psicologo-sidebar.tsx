"use client"

import { cn } from "@/lib/utils"
import {
  BarChart3,
  Calendar,
  ClipboardList,
  FileText,
  Heart,
  Home,
  LogOut,
  MessageSquare,
  Settings,
  Users,
} from "lucide-react"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const routes = [
  {
    label: "Dashboard",
    icon: Home,
    href: "/dashboard/psicologo",
    color: "text-sky-500",
  },
  {
    href: "/dashboard/psicologo/eventos",
    label: "Eventos",
    icon: Calendar,
    color: "text-teal-500",
  },
  {
    label: "Casos Emocionales",
    icon: Heart,
    href: "/dashboard/psicologo/casos-emocionales",
    color: "text-pink-500",
    badge: "12",
  },
  {
    label: "Seguimiento",
    icon: ClipboardList,
    href: "/dashboard/psicologo/seguimiento",
    color: "text-violet-500",
  },
  {
    label: "Citas",
    icon: Calendar,
    href: "/dashboard/psicologo/citas",
    color: "text-emerald-500",
    badge: "3",
  },
  {
    label: "Estudiantes",
    icon: Users,
    href: "/dashboard/psicologo/estudiantes",
    color: "text-orange-500",
  },
  {
    label: "Informes",
    icon: FileText,
    href: "/dashboard/psicologo/informes",
    color: "text-blue-500",
  },
  {
    label: "Estadísticas",
    icon: BarChart3,
    href: "/dashboard/psicologo/estadisticas",
    color: "text-yellow-500",
  },
  {
    label: "Mensajes",
    icon: MessageSquare,
    href: "/dashboard/psicologo/mensajes",
    color: "text-green-500",
    badge: "5",
  },
  {
    label: "Configuración",
    icon: Settings,
    href: "/dashboard/psicologo/configuracion",
  },
]

export function PsicologoSidebar() {
  const pathname = usePathname()

  return (
    <div className="flex h-full flex-col space-y-4 bg-gray-50 py-4 shadow-sm">
      <div className="px-3 py-2">
        <div className="flex items-center justify-center rounded-lg px-3 py-2">
          <Link href="/dashboard/psicologo">
            <h1 className="text-2xl font-bold text-primary">EduPsy</h1>
          </Link>
        </div>
        <div className="my-4 flex flex-col items-center gap-2 rounded-lg bg-white p-4 shadow-sm">
          <Avatar className="h-20 w-20">
            <AvatarImage src="/placeholder.svg?height=80&width=80" />
            <AvatarFallback>MP</AvatarFallback>
          </Avatar>
          <div className="text-center">
            <h2 className="text-lg font-semibold">Dra. María Pérez</h2>
            <p className="text-sm text-muted-foreground">Psicóloga Educativa</p>
          </div>
        </div>
      </div>
      <div className="space-y-1 px-3">
        {routes.map((route) => (
          <Link
            key={route.href}
            href={route.href}
            className={cn(
              "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-gray-100 hover:text-primary",
              pathname === route.href ? "bg-gray-100 text-primary" : "text-muted-foreground",
            )}
          >
            <div className="flex items-center gap-3">
              <route.icon className={cn("h-5 w-5", route.color)} />
              {route.label}
            </div>
            {route.badge && (
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground">
                {route.badge}
              </span>
            )}
          </Link>
        ))}
      </div>
      <div className="mt-auto px-3">
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href="/login">
            <LogOut className="mr-2 h-4 w-4" />
            Cerrar Sesión
          </Link>
        </Button>
      </div>
    </div>
  )
}

