// Tipos de sugerencias de IA
export interface AISuggestion {
  id: string
  title: string
  description: string
  priority: "alta" | "media" | "baja"
  actionText: string
  actionLink: string
  category: string
  createdAt: Date
}

// Función para generar sugerencias para estudiantes
export function getStudentSuggestions(studentData: any = {}): AISuggestion[] {
  return [
    {
      id: "student-1",
      title: "Mejora tu rendimiento en Matemáticas",
      description:
        "Basado en tus últimas evaluaciones, te recomendamos dedicar más tiempo a los ejercicios de álgebra. Hemos notado que tus calificaciones han bajado un 15% en este tema.",
      priority: "alta",
      actionText: "Ver recursos recomendados",
      actionLink: "/recursos/matematicas",
      category: "académico",
      createdAt: new Date(Date.now() - 86400000), // 1 día atrás
    },
    {
      id: "student-2",
      title: "Patrones emocionales detectados",
      description:
        "Hemos notado que registras emociones negativas los lunes y miércoles. Considera hablar con tu orientador sobre cómo manejar el estrés en estos días.",
      priority: "media",
      actionText: "Agendar cita con orientador",
      actionLink: "/agendar/orientacion",
      category: "bienestar",
      createdAt: new Date(Date.now() - 172800000), // 2 días atrás
    },
    {
      id: "student-3",
      title: "Oportunidad de proyecto extracurricular",
      description:
        "Basado en tus intereses y habilidades, te recomendamos participar en el próximo concurso de ciencias. Esto podría mejorar tu perfil académico.",
      priority: "baja",
      actionText: "Ver detalles del concurso",
      actionLink: "/actividades/concurso-ciencias",
      category: "oportunidades",
      createdAt: new Date(Date.now() - 259200000), // 3 días atrás
    },
    {
      id: "student-4",
      title: "Recordatorio de entrega de proyecto",
      description:
        "Tu proyecto de Historia debe ser entregado en 3 días. Basado en tu progreso actual, te recomendamos dedicar al menos 2 horas hoy para completarlo a tiempo.",
      priority: "alta",
      actionText: "Ver detalles del proyecto",
      actionLink: "/tareas/historia-proyecto",
      category: "recordatorios",
      createdAt: new Date(),
    },
  ]
}

// Función para generar sugerencias para profesores
export function getTeacherSuggestions(teacherData: any = {}): AISuggestion[] {
  return [
    {
      id: "teacher-1",
      title: "Estudiantes en riesgo académico",
      description:
        "Hemos identificado 5 estudiantes en tu clase de Ciencias que muestran una tendencia negativa en sus calificaciones. Te recomendamos una intervención temprana.",
      priority: "alta",
      actionText: "Ver lista de estudiantes",
      actionLink: "/estudiantes/riesgo-academico",
      category: "intervención",
      createdAt: new Date(Date.now() - 86400000), // 1 día atrás
    },
    {
      id: "teacher-2",
      title: "Optimización de plan de lecciones",
      description:
        'Basado en el rendimiento de la clase, te sugerimos reforzar el tema de "Ecosistemas" con actividades prácticas. El 60% de los estudiantes mostró dificultades en este tema.',
      priority: "media",
      actionText: "Ver recursos didácticos sugeridos",
      actionLink: "/recursos/ecosistemas",
      category: "planificación",
      createdAt: new Date(Date.now() - 172800000), // 2 días atrás
    },
    {
      id: "teacher-3",
      title: "Patrones emocionales en tu clase",
      description:
        "Hemos detectado un aumento del 20% en registros de emociones negativas los días de examen. Considera implementar técnicas de reducción de estrés antes de las evaluaciones.",
      priority: "media",
      actionText: "Ver técnicas recomendadas",
      actionLink: "/recursos/manejo-estres",
      category: "bienestar",
      createdAt: new Date(Date.now() - 259200000), // 3 días atrás
    },
    {
      id: "teacher-4",
      title: "Oportunidad de desarrollo profesional",
      description:
        'Hay un taller sobre "Inteligencia Artificial en Educación" que coincide con tus intereses profesionales declarados. Las inscripciones cierran en 5 días.',
      priority: "baja",
      actionText: "Ver detalles del taller",
      actionLink: "/desarrollo-profesional/taller-ia",
      category: "oportunidades",
      createdAt: new Date(),
    },
  ]
}

// Función para generar sugerencias para administradores
export function getAdminSuggestions(adminData: any = {}): AISuggestion[] {
  return [
    {
      id: "admin-1",
      title: "Alerta de ausentismo",
      description:
        "Hemos detectado un aumento del 15% en el ausentismo en el grado 10. Los datos sugieren que esto podría estar relacionado con el calendario de evaluaciones.",
      priority: "alta",
      actionText: "Ver análisis detallado",
      actionLink: "/analisis/ausentismo",
      category: "alertas",
      createdAt: new Date(Date.now() - 86400000), // 1 día atrás
    },
    {
      id: "admin-2",
      title: "Optimización de recursos",
      description:
        "El análisis de uso de laboratorios muestra que el Laboratorio B está subutilizado. Recomendamos redistribuir las clases para maximizar el uso de instalaciones.",
      priority: "media",
      actionText: "Ver plan de optimización",
      actionLink: "/recursos/optimizacion",
      category: "gestión",
      createdAt: new Date(Date.now() - 172800000), // 2 días atrás
    },
    {
      id: "admin-3",
      title: "Tendencias en bienestar estudiantil",
      description:
        "Los datos del Diario de Emociones muestran un incremento del 25% en registros negativos durante el último mes. Recomendamos una evaluación del programa de apoyo emocional.",
      priority: "alta",
      actionText: "Ver informe completo",
      actionLink: "/informes/bienestar-estudiantil",
      category: "bienestar",
      createdAt: new Date(Date.now() - 259200000), // 3 días atrás
    },
    {
      id: "admin-4",
      title: "Oportunidad de financiamiento",
      description:
        "Se ha identificado una convocatoria de subvenciones para programas de tecnología educativa que se alinea con los objetivos estratégicos de la institución.",
      priority: "media",
      actionText: "Ver detalles de la convocatoria",
      actionLink: "/financiamiento/subvenciones-tecnologia",
      category: "oportunidades",
      createdAt: new Date(),
    },
    {
      id: "admin-5",
      title: "Predicción de rendimiento académico",
      description:
        "Nuestro modelo predictivo indica que el rendimiento en Ciencias podría disminuir un 10% el próximo trimestre si no se implementan medidas correctivas.",
      priority: "alta",
      actionText: "Ver recomendaciones preventivas",
      actionLink: "/predicciones/rendimiento-academico",
      category: "predicciones",
      createdAt: new Date(),
    },
  ]
}

// Función para obtener sugerencias según el tipo de usuario
export function getAISuggestions(userType: "student" | "teacher" | "admin", userData: any = {}): AISuggestion[] {
  switch (userType) {
    case "student":
      return getStudentSuggestions(userData)
    case "teacher":
      return getTeacherSuggestions(userData)
    case "admin":
      return getAdminSuggestions(userData)
    default:
      return []
  }
}

