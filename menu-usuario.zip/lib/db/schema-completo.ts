// Esquema completo de la base de datos para la plataforma educativa

// USUARIOS
export interface Usuario {
  id: string
  nombre: string
  apellido: string
  email: string
  password: string // Almacenado con hash en producción
  rol: "admin" | "director" | "profesor" | "psicologo" | "estudiante" | "padre"
  estado: "activo" | "inactivo" | "suspendido"
  fechaCreacion: string
  ultimoAcceso: string

  // Campos opcionales
  fotoPerfil?: string
  telefono?: string
  direccion?: string

  // Campos específicos según rol
  aulaId?: string // Para estudiantes
  materias?: string[] // Para profesores
  hijos?: string[] // Para padres (IDs de estudiantes)
}

// AULAS/CLASES
export interface Aula {
  id: string
  nombre: string
  grado: string
  seccion: string
  anioAcademico: string
  capacidad: number

  // Campos derivados
  estudiantesActuales?: number
  profesoresAsignados?: string[]
}

// ASIGNACIONES DE PROFESORES
export interface AsignacionProfesor {
  id: string
  profesorId: string
  aulaId: string
  materiaId: string
  horario: {
    dia: "lunes" | "martes" | "miercoles" | "jueves" | "viernes" | "sabado"
    horaInicio: string
    horaFin: string
  }[]
  fechaCreacion: string

  // Campos derivados
  nombreProfesor?: string
  nombreAula?: string
  nombreMateria?: string
  horasPorSemana?: number
}

// MATERIAS
export interface Materia {
  id: string
  nombre: string
  codigo: string
  descripcion: string
  grado: string
  creditos: number

  // Campos opcionales
  prerequisitos?: string[] // IDs de otras materias
  corequisitos?: string[] // IDs de otras materias
}

// TEMAS DE CLASE
export interface Tema {
  id: string
  titulo: string
  materia: string
  descripcion: string
  contenido: string
  recursos: {
    tipo: "documento" | "video" | "enlace" | "imagen"
    url: string
    titulo: string
  }[]
  creadorId: string
  fechaCreacion: string

  // Campos opcionales
  duracionEstimada?: number // En minutos
  prerequisitos?: string[] // IDs de otros temas

  // Campos derivados
  tasaCompletado?: number // Porcentaje de estudiantes que completaron
}

// EVENTOS
export interface Evento {
  id: string
  titulo: string
  fecha: string
  hora: string
  tipo: "academico" | "cultural" | "deportivo" | "otro"
  estado: "proximo" | "en_curso" | "finalizado" | "cancelado"
  descripcion: string
  lugar: string
  creadorId: string
  fechaCreacion: string
  fechaActualizacion: string

  // Campos opcionales
  fechaFin?: string
  horaFin?: string
  categoria?: string
  deporte?: string
  adjuntos?: string[] // URLs de archivos adjuntos

  // Campos derivados
  diasRestantes?: number
}

// CUESTIONARIOS/EVALUACIONES
export interface Cuestionario {
  id: string
  titulo: string
  tipo: "academico" | "psicologico"
  preguntas: {
    id: string
    texto: string
    tipo: "opcion_multiple" | "texto" | "escala" | "verdadero_falso"
    opciones?: string[] // Para preguntas de opción múltiple
    valorMinimo?: number // Para escalas
    valorMaximo?: number // Para escalas
    respuestaCorrecta?: string | number | boolean // Para preguntas calificables
    puntaje?: number // Valor de la pregunta
  }[]
  creadorId: string
  fechaCreacion: string
  fechaLimite?: string

  // Campos opcionales
  descripcion?: string
  audienciaObjetivo?: "estudiantes" | "profesores" | "padres"
  duracionMinutos?: number
  intentosPermitidos?: number

  // Campos derivados
  cantidadRespuestas?: number
}

// RESPUESTAS A CUESTIONARIOS
export interface RespuestaCuestionario {
  id: string
  cuestionarioId: string
  respondienteId: string
  respuestas: {
    preguntaId: string
    valor: string | number | boolean
  }[]
  fechaEnvio: string
  tiempoCompletado: number // En segundos

  // Campos derivados
  puntaje?: number
  porcentajeCompletado?: number
}

// DIARIO DE EMOCIONES
export interface EntradaDiario {
  id: string
  estudianteId: string
  titulo: string
  contenido: string
  sentimiento: "positivo" | "neutral" | "negativo"
  intensidad: number // 1-5
  fecha: string
  hora: string

  // Campos opcionales
  etiquetas?: string[]
  situacion?: string
  pensamientos?: string

  // Campos derivados
  tendenciaSemanal?: "mejorando" | "estable" | "empeorando"
}

// REGISTROS PSICOLÓGICOS
export interface RegistroPsicologico {
  id: string
  estudianteId: string
  psicologoId: string
  fecha: string
  observaciones: string
  recomendaciones: string
  fechaSeguimiento?: string
  etiquetas: string[]
  fechaCreacion: string

  // Campos opcionales
  adjuntos?: string[] // URLs de documentos adjuntos
  padreNotificado?: boolean

  // Campos derivados
  nombreEstudiante?: string
  nombrePsicologo?: string
  diasHastaSeguimiento?: number
}

// SUGERENCIAS DE IA
export interface SugerenciaIA {
  id: string
  usuarioId: string
  rolUsuario: "estudiante" | "profesor" | "admin"
  titulo: string
  descripcion: string
  tipo: "academico" | "emocional" | "administrativo" | "comportamiento"
  prioridad: "alta" | "media" | "baja"
  accionRecomendada: string
  enlaceAccion?: string
  fechaGeneracion: string

  // Campos opcionales
  datosRelacionados?: {
    tipo: string
    id: string
    valor: string
  }[]

  // Campos de seguimiento
  estado: "pendiente" | "implementada" | "ignorada" | "pospuesta"
  fechaImplementacion?: string
  comentarioUsuario?: string
}

// ACTIVIDADES DEPORTIVAS
export interface ActividadDeportiva {
  id: string
  estudianteId: string
  tipo: "entrenamiento" | "competencia" | "evaluacion"
  deporte: string
  fecha: string
  duracionMinutos: number

  // Para entrenamientos
  ejercicios?: {
    nombre: string
    series: number
    repeticiones: number
    peso?: number
  }[]

  // Para competencias
  resultado?: "victoria" | "derrota" | "empate"
  puntuacion?: string
  rival?: string

  // Para evaluaciones físicas
  mediciones?: {
    tipo: "peso" | "altura" | "velocidad" | "resistencia" | "fuerza" | "flexibilidad"
    valor: number
    unidad: string
  }[]

  // Campos derivados
  progresoMensual?: number // Porcentaje de mejora
}

// TAREAS Y ASIGNACIONES
export interface Tarea {
  id: string
  titulo: string
  descripcion: string
  materiaId: string
  profesorId: string
  aulaId: string
  fechaAsignacion: string
  fechaEntrega: string

  // Campos opcionales
  recursos?: {
    tipo: "documento" | "video" | "enlace"
    url: string
    titulo: string
  }[]
  puntajeMaximo?: number

  // Campos derivados
  diasRestantes?: number
  tasaEntrega?: number // Porcentaje de estudiantes que entregaron
}

// ENTREGAS DE TAREAS
export interface EntregaTarea {
  id: string
  tareaId: string
  estudianteId: string
  fechaEntrega: string
  estado: "entregada" | "calificada" | "retrasada" | "no_entregada"

  // Campos opcionales
  archivos?: string[] // URLs de archivos adjuntos
  comentarioEstudiante?: string

  // Calificación
  calificacion?: number
  comentarioProfesor?: string
  fechaCalificacion?: string

  // Campos derivados
  puntajePorcentaje?: number // Porcentaje del puntaje máximo
  diasRetraso?: number
}

// ASISTENCIA
export interface RegistroAsistencia {
  id: string
  estudianteId: string
  aulaId: string
  materiaId: string
  fecha: string
  estado: "presente" | "ausente" | "tardanza" | "justificado"

  // Campos opcionales
  justificacion?: string
  minutosRetraso?: number
  registradoPor: string // ID del profesor o administrativo

  // Campos derivados
  porcentajeAsistenciaMensual?: number
}

// NOTIFICACIONES
export interface Notificacion {
  id: string
  usuarioId: string
  titulo: string
  mensaje: string
  tipo: "informativa" | "alerta" | "recordatorio" | "felicitacion"
  fechaCreacion: string
  leida: boolean
  fechaLectura?: string

  // Campos opcionales
  enlace?: string
  accion?: string
  prioridad: "alta" | "normal" | "baja"

  // Campos derivados
  tiempoTranscurrido?: string // "hace 5 minutos", "hace 1 hora", etc.
}

