import type {
  Event,
  User,
  Assignment,
  Questionnaire,
  QuestionnaireResponse,
  Topic,
  Classroom,
  PsychologicalRecord,
} from "./schema"

// Simulación de base de datos en memoria
interface DatabaseCache {
  events: Map<string, Event>
  users: Map<string, User>
  assignments: Map<string, Assignment>
  questionnaires: Map<string, Questionnaire>
  questionnaireResponses: Map<string, QuestionnaireResponse>
  topics: Map<string, Topic>
  classrooms: Map<string, Classroom>
  psychological: Map<string, PsychologicalRecord>
}

class Database {
  private static instance: Database
  private cache: DatabaseCache

  private constructor() {
    this.cache = {
      events: new Map(),
      users: new Map(),
      assignments: new Map(),
      questionnaires: new Map(),
      questionnaireResponses: new Map(),
      topics: new Map(),
      classrooms: new Map(),
      psychological: new Map(),
    }
    this.initializeData()
  }

  public static getInstance(): Database {
    if (!Database.instance) {
      Database.instance = new Database()
    }
    return Database.instance
  }

  private initializeData() {
    // Inicializar con datos de ejemplo
    const mockEvents = [
      {
        id: "1",
        title: "Exposición de Ciencias",
        date: "2024-03-15",
        time: "09:00",
        type: "academic",
        status: "upcoming",
        description: "Presentación de proyectos científicos",
        location: "Auditorio Principal",
      },
      // ... más eventos
    ]

    mockEvents.forEach((event) => {
      this.cache.events.set(event.id, event)
    })

    // Inicializar otros datos de ejemplo...
  }

  // Métodos genéricos CRUD
  public async create(collection: keyof DatabaseCache, id: string, data: any): Promise<any> {
    if (!this.cache[collection].has(id)) {
      this.cache[collection].set(id, data)
      return data
    }
    throw new Error("Item already exists")
  }

  public async read(collection: keyof DatabaseCache, id: string): Promise<any> {
    const item = this.cache[collection].get(id)
    if (item) return item
    throw new Error("Item not found")
  }

  public async readAll(collection: keyof DatabaseCache): Promise<any[]> {
    return Array.from(this.cache[collection].values())
  }

  public async update(collection: keyof DatabaseCache, id: string, data: any): Promise<any> {
    if (this.cache[collection].has(id)) {
      const updatedData = { ...this.cache[collection].get(id), ...data }
      this.cache[collection].set(id, updatedData)
      return updatedData
    }
    throw new Error("Item not found")
  }

  public async delete(collection: keyof DatabaseCache, id: string): Promise<boolean> {
    return this.cache[collection].delete(id)
  }

  public async query(collection: keyof DatabaseCache, filter: (item: any) => boolean): Promise<any[]> {
    const items = Array.from(this.cache[collection].values())
    return items.filter(filter)
  }
}

export const db = Database.getInstance()

