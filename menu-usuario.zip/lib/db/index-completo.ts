// Sistema de base de datos completo para la plataforma educativa

// Importamos los tipos del esquema
import type * as Schema from "./schema-completo"

// Clase para simular una base de datos en memoria
export class Database {
  private collections: Map<string, Map<string, any>>

  constructor() {
    this.collections = new Map()
    this.initializeCollections()
    this.seedInitialData()
  }

  private initializeCollections() {
    // Inicializamos todas las colecciones necesarias
    const collectionNames = [
      "usuarios",
      "aulas",
      "asignacionesProfesores",
      "materias",
      "temas",
      "eventos",
      "cuestionarios",
      "respuestasCuestionarios",
      "diarioEmociones",
      "registrosPsicologicos",
      "sugerenciasIA",
      "actividadesDeportivas",
      "tareas",
      "entregasTareas",
      "asistencia",
      "notificaciones",
    ]

    collectionNames.forEach((name) => {
      this.collections.set(name, new Map())
    })
  }

  private seedInitialData() {
    // Usuarios de ejemplo
    const usuarios: Schema.Usuario[] = [
      {
        id: "1",
        nombre: "Admin",
        apellido: "Sistema",
        email: "admin@altiora.edu",
        password: "admin123", // En producción usar hash
        rol: "admin",
        estado: "activo",
        fechaCreacion: new Date().toISOString(),
        ultimoAcceso: new Date().toISOString(),
      },
      {
        id: "2",
        nombre: "Juan",
        apellido: "Pérez",
        email: "profesor@altiora.edu",
        password: "profesor123",
        rol: "profesor",
        estado: "activo",
        fechaCreacion: new Date().toISOString(),
        ultimoAcceso: new Date().toISOString(),
        materias: ["1", "2"],
      },
      {
        id: "3",
        nombre: "María",
        apellido: "González",
        email: "estudiante@altiora.edu",
        password: "estudiante123",
        rol: "estudiante",
        estado: "activo",
        fechaCreacion: new Date().toISOString(),
        ultimoAcceso: new Date().toISOString(),
        aulaId: "1",
      },
    ]

    // Aulas de ejemplo
    const aulas: Schema.Aula[] = [
      {
        id: "1",
        nombre: "5to A",
        grado: "5",
        seccion: "A",
        anioAcademico: "2024",
        capacidad: 30,
      },
    ]

    // Materias de ejemplo
    const materias: Schema.Materia[] = [
      {
        id: "1",
        nombre: "Matemáticas",
        codigo: "MAT-5",
        descripcion: "Curso de matemáticas para 5to grado",
        grado: "5",
        creditos: 4,
      },
      {
        id: "2",
        nombre: "Ciencias Naturales",
        codigo: "CIE-5",
        descripcion: "Curso de ciencias naturales para 5to grado",
        grado: "5",
        creditos: 3,
      },
    ]

    // Eventos de ejemplo
    const eventos: Schema.Evento[] = [
      {
        id: "1",
        titulo: "Exposición de Ciencias",
        fecha: "2024-03-15",
        hora: "09:00",
        tipo: "academico",
        estado: "proximo",
        descripcion: "Presentación de proyectos científicos",
        lugar: "Auditorio Principal",
        creadorId: "2",
        fechaCreacion: new Date().toISOString(),
        fechaActualizacion: new Date().toISOString(),
      },
      {
        id: "2",
        titulo: "Torneo Interescolar de Fútbol",
        fecha: "2024-03-18",
        hora: "15:00",
        tipo: "deportivo",
        estado: "proximo",
        descripcion: "Partido semifinal contra Colegio San José",
        lugar: "Campo Deportivo Principal",
        creadorId: "2",
        fechaCreacion: new Date().toISOString(),
        fechaActualizacion: new Date().toISOString(),
        categoria: "Sub-15",
        deporte: "Fútbol",
      },
    ]

    // Entradas de diario de emociones de ejemplo
    const diarioEmociones: Schema.EntradaDiario[] = [
      {
        id: "1",
        estudianteId: "3",
        titulo: "Día de examen",
        contenido: "Hoy tuve un examen de matemáticas y me sentí muy nervioso.",
        sentimiento: "negativo",
        intensidad: 3,
        fecha: "2024-03-01",
        hora: "18:30",
      },
      {
        id: "2",
        estudianteId: "3",
        titulo: "Proyecto grupal",
        contenido: "Trabajamos en equipo para el proyecto de ciencias y fue muy divertido.",
        sentimiento: "positivo",
        intensidad: 4,
        fecha: "2024-03-03",
        hora: "19:15",
      },
    ]

    // Sugerencias de IA de ejemplo
    const sugerenciasIA: Schema.SugerenciaIA[] = [
      {
        id: "1",
        usuarioId: "3",
        rolUsuario: "estudiante",
        titulo: "Mejora en matemáticas",
        descripcion: "Basado en tus últimas evaluaciones, te recomendamos reforzar el tema de fracciones.",
        tipo: "academico",
        prioridad: "alta",
        accionRecomendada: "Revisar material adicional sobre fracciones",
        enlaceAccion: "/dashboard/estudiante/temas/matematicas/fracciones",
        fechaGeneracion: new Date().toISOString(),
        estado: "pendiente",
      },
      {
        id: "2",
        usuarioId: "3",
        rolUsuario: "estudiante",
        titulo: "Patrón emocional detectado",
        descripcion: "Hemos notado que tiendes a sentirte más estresado antes de los exámenes.",
        tipo: "emocional",
        prioridad: "media",
        accionRecomendada: "Revisar técnicas de manejo de estrés",
        enlaceAccion: "/dashboard/estudiante/recursos/manejo-estres",
        fechaGeneracion: new Date().toISOString(),
        estado: "pendiente",
      },
    ]

    // Guardamos los datos iniciales en las colecciones
    usuarios.forEach((usuario) => this.collections.get("usuarios")!.set(usuario.id, usuario))
    aulas.forEach((aula) => this.collections.get("aulas")!.set(aula.id, aula))
    materias.forEach((materia) => this.collections.get("materias")!.set(materia.id, materia))
    eventos.forEach((evento) => this.collections.get("eventos")!.set(evento.id, evento))
    diarioEmociones.forEach((entrada) => this.collections.get("diarioEmociones")!.set(entrada.id, entrada))
    sugerenciasIA.forEach((sugerencia) => this.collections.get("sugerenciasIA")!.set(sugerencia.id, sugerencia))
  }

  // Métodos CRUD genéricos
  async create<T>(collection: string, id: string, data: T): Promise<T> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    this.collections.get(collection)!.set(id, data)
    return data
  }

  async read<T>(collection: string, id: string): Promise<T | null> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    return (this.collections.get(collection)!.get(id) || null) as T | null
  }

  async update<T>(collection: string, id: string, data: Partial<T>): Promise<T | null> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    const existingData = this.collections.get(collection)!.get(id)
    if (!existingData) {
      return null
    }

    const updatedData = { ...existingData, ...data }
    this.collections.get(collection)!.set(id, updatedData)
    return updatedData as T
  }

  async delete(collection: string, id: string): Promise<boolean> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    return this.collections.get(collection)!.delete(id)
  }

  async readAll<T>(collection: string): Promise<T[]> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    return Array.from(this.collections.get(collection)!.values()) as T[]
  }

  async query<T>(collection: string, predicate: (item: T) => boolean): Promise<T[]> {
    if (!this.collections.has(collection)) {
      throw new Error(`Colección ${collection} no existe`)
    }

    const items = Array.from(this.collections.get(collection)!.values()) as T[]
    return items.filter(predicate)
  }

  // Métodos específicos para el Diario de Emociones
  async getDiarioEmocionesByEstudiante(estudianteId: string): Promise<Schema.EntradaDiario[]> {
    return this.query<Schema.EntradaDiario>("diarioEmociones", (entrada) => entrada.estudianteId === estudianteId)
  }

  async getDiarioEmocionesByFecha(
    estudianteId: string,
    fechaInicio: string,
    fechaFin: string,
  ): Promise<Schema.EntradaDiario[]> {
    return this.query<Schema.EntradaDiario>(
      "diarioEmociones",
      (entrada) => entrada.estudianteId === estudianteId && entrada.fecha >= fechaInicio && entrada.fecha <= fechaFin,
    )
  }

  async getDiarioEmocionesBySentimiento(
    estudianteId: string,
    sentimiento: "positivo" | "neutral" | "negativo",
  ): Promise<Schema.EntradaDiario[]> {
    return this.query<Schema.EntradaDiario>(
      "diarioEmociones",
      (entrada) => entrada.estudianteId === estudianteId && entrada.sentimiento === sentimiento,
    )
  }

  // Métodos específicos para Sugerencias de IA
  async getSugerenciasByUsuario(usuarioId: string): Promise<Schema.SugerenciaIA[]> {
    return this.query<Schema.SugerenciaIA>("sugerenciasIA", (sugerencia) => sugerencia.usuarioId === usuarioId)
  }

  async getSugerenciasByRol(rol: "estudiante" | "profesor" | "admin"): Promise<Schema.SugerenciaIA[]> {
    return this.query<Schema.SugerenciaIA>("sugerenciasIA", (sugerencia) => sugerencia.rolUsuario === rol)
  }

  async getSugerenciasByPrioridad(prioridad: "alta" | "media" | "baja"): Promise<Schema.SugerenciaIA[]> {
    return this.query<Schema.SugerenciaIA>("sugerenciasIA", (sugerencia) => sugerencia.prioridad === prioridad)
  }

  // Métodos específicos para Eventos
  async getEventosByTipo(tipo: "academico" | "cultural" | "deportivo" | "otro"): Promise<Schema.Evento[]> {
    return this.query<Schema.Evento>("eventos", (evento) => evento.tipo === tipo)
  }

  async getEventosFuturos(): Promise<Schema.Evento[]> {
    const hoy = new Date().toISOString().split("T")[0]
    return this.query<Schema.Evento>("eventos", (evento) => evento.fecha >= hoy)
  }

  // Métodos específicos para Usuarios
  async getUsersByRol(rol: string): Promise<Schema.Usuario[]> {
    return this.query<Schema.Usuario>("usuarios", (usuario) => usuario.rol === rol)
  }

  async getUsersByAula(aulaId: string): Promise<Schema.Usuario[]> {
    return this.query<Schema.Usuario>(
      "usuarios",
      (usuario) => usuario.rol === "estudiante" && usuario.aulaId === aulaId,
    )
  }

  // Métodos para análisis y reportes
  async getEstadisticasDiarioEmociones(estudianteId: string): Promise<any> {
    const entradas = await this.getDiarioEmocionesByEstudiante(estudianteId)

    // Contamos las entradas por sentimiento
    const conteoSentimientos = {
      positivo: 0,
      neutral: 0,
      negativo: 0,
    }

    entradas.forEach((entrada) => {
      conteoSentimientos[entrada.sentimiento]++
    })

    // Calculamos la tendencia
    let tendencia = "estable"
    if (entradas.length >= 3) {
      const ultimasEntradas = entradas
        .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
        .slice(0, 3)

      const puntajes = ultimasEntradas.map((entrada) => {
        if (entrada.sentimiento === "positivo") return 1
        if (entrada.sentimiento === "neutral") return 0
        return -1
      })

      const sumaPuntajes = puntajes.reduce((sum, score) => sum + score, 0)
      if (sumaPuntajes > 0) tendencia = "mejorando"
      if (sumaPuntajes < 0) tendencia = "empeorando"
    }

    return {
      totalEntradas: entradas.length,
      conteoSentimientos,
      tendencia,
      ultimaEntrada:
        entradas.length > 0
          ? entradas.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())[0]
          : null,
    }
  }
}

// Exportamos una única instancia para mantener el estado
export const db = new Database()

