// Definición de esquemas para la base de datos

// EVENTOS
export interface Event {
  // Campos persistentes (almacenados)
  id: string
  title: string
  date: string
  time: string
  type: "academic" | "cultural" | "sports" | "other"
  description: string
  location: string
  createdBy: string // ID del usuario que creó el evento
  createdAt: string // Fecha de creación

  // Campos opcionales
  endDate?: string
  endTime?: string
  attachments?: string[] // URLs de archivos adjuntos

  // Campos derivados (calculados en consultas)
  // No se almacenan directamente
  status?: "upcoming" | "ongoing" | "past" // Calculado basado en la fecha
  daysRemaining?: number // Calculado basado en la fecha actual
}

// USUARIOS
export interface User {
  // Campos persistentes
  id: string
  name: string
  email: string
  role: "admin" | "directivo" | "profesor" | "psicologo" | "estudiante"
  password: string // Almacenado con hash
  createdAt: string

  // Campos opcionales
  profilePicture?: string
  phone?: string

  // Campos específicos según rol
  classroomId?: string // Para estudiantes
  subjects?: string[] // Para profesores

  // Campos derivados
  isActive?: boolean // Calculado basado en la última actividad
}

// ASIGNACIONES DE PROFESORES
export interface Assignment {
  // Campos persistentes
  id: string
  professorId: string
  classroomId: string
  subjectId: string
  schedule: {
    day: string
    startTime: string
    endTime: string
  }[]
  createdAt: string

  // Campos derivados
  professorName?: string // Obtenido de la relación con User
  classroomName?: string // Obtenido de la relación con Classroom
  subjectName?: string // Obtenido de la relación con Subject
  hoursPerWeek?: number // Calculado basado en el horario
}

// AULAS/CLASES
export interface Classroom {
  // Campos persistentes
  id: string
  name: string
  grade: string
  section: string
  academicYear: string
  capacity: number

  // Campos derivados
  currentStudents?: number // Calculado contando estudiantes
  assignedTeachers?: string[] // IDs de profesores asignados
}

// CUESTIONARIOS/EVALUACIONES
export interface Questionnaire {
  // Campos persistentes
  id: string
  title: string
  type: "academic" | "psychological"
  questions: {
    id: string
    text: string
    type: "multiple_choice" | "text" | "scale"
    options?: string[] // Para preguntas de opción múltiple
    minValue?: number // Para escalas
    maxValue?: number // Para escalas
  }[]
  createdBy: string
  createdAt: string

  // Campos opcionales
  description?: string
  targetAudience?: "students" | "teachers" | "parents"

  // Campos derivados
  responseCount?: number // Número de respuestas recibidas
}

// RESPUESTAS A CUESTIONARIOS
export interface QuestionnaireResponse {
  // Campos persistentes
  id: string
  questionnaireId: string
  respondentId: string
  answers: {
    questionId: string
    value: string | number
  }[]
  submittedAt: string

  // Campos derivados
  score?: number // Calculado para cuestionarios calificables
  completionTime?: number // Tiempo que tomó completar
}

// TEMAS DE CLASE
export interface Topic {
  // Campos persistentes
  id: string
  title: string
  subject: string
  description: string
  content: string
  resources: {
    type: "document" | "video" | "link"
    url: string
    title: string
  }[]
  createdBy: string
  createdAt: string

  // Campos opcionales
  estimatedDuration?: number // En minutos
  prerequisites?: string[] // IDs de otros temas

  // Campos derivados
  completionRate?: number // Porcentaje de estudiantes que completaron
}

// EVALUACIONES PSICOLÓGICAS
export interface PsychologicalRecord {
  // Campos persistentes
  id: string
  studentId: string
  psychologistId: string
  date: string
  observations: string
  recommendations: string
  followUpDate?: string
  tags: string[]
  createdAt: string

  // Campos opcionales
  attachments?: string[] // URLs de documentos adjuntos
  parentNotified?: boolean

  // Campos derivados
  studentName?: string // Obtenido de la relación con User
  psychologistName?: string // Obtenido de la relación con User
  daysUntilFollowUp?: number // Calculado basado en la fecha actual
}

