import type { Evento, CreateEventoInput, UpdateEventoInput } from "@/types/evento"

// Simulación de base de datos en memoria
class EventosDB {
  private eventos: Map<string, Evento>

  constructor() {
    this.eventos = new Map()
    // Inicializar con datos de ejemplo
    this.seedInitialData()
  }

  private seedInitialData() {
    const eventosIniciales: Evento[] = [
      {
        id: "1",
        titulo: "Exposición de Ciencias",
        fecha: "2024-03-15",
        hora: "09:00",
        tipo: "academico",
        estado: "próximo",
        descripcion: "Presentación de proyectos científicos",
        lugar: "Auditorio Principal",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: "sistema",
      },
      {
        id: "2",
        titulo: "Torneo Interescolar de Fútbol",
        fecha: "2024-03-18",
        hora: "15:00",
        tipo: "competencia",
        estado: "próximo",
        descripcion: "Partido semifinal contra Colegio San José",
        lugar: "Campo Deportivo Principal",
        categoria: "Sub-15",
        deporte: "Fútbol",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: "sistema",
      },
    ]

    eventosIniciales.forEach((evento) => {
      this.eventos.set(evento.id, evento)
    })
  }

  async getAll(): Promise<Evento[]> {
    return Array.from(this.eventos.values())
  }

  async getById(id: string): Promise<Evento | null> {
    return this.eventos.get(id) || null
  }

  async create(input: CreateEventoInput): Promise<Evento> {
    const id = Math.random().toString(36).substr(2, 9)
    const now = new Date().toISOString()

    const evento: Evento = {
      ...input,
      id,
      createdAt: now,
      updatedAt: now,
    }

    this.eventos.set(id, evento)
    return evento
  }

  async update(id: string, input: UpdateEventoInput): Promise<Evento | null> {
    const evento = this.eventos.get(id)
    if (!evento) return null

    const updatedEvento: Evento = {
      ...evento,
      ...input,
      updatedAt: new Date().toISOString(),
    }

    this.eventos.set(id, updatedEvento)
    return updatedEvento
  }

  async delete(id: string): Promise<boolean> {
    return this.eventos.delete(id)
  }
}

// Exportar una única instancia para mantener el estado
export const eventosDB = new EventosDB()

