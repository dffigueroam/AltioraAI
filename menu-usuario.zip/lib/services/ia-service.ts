import type { EntradaDiario, SugerenciaIA, Usuario } from "@/lib/db/schema-completo"
import { db } from "@/lib/db/index-completo"

// Servicio para generar sugerencias de IA basadas en datos del usuario
export class IAService {
  // Genera sugerencias para un estudiante basadas en su diario de emociones
  async generarSugerenciasEstudiante(estudianteId: string): Promise<SugerenciaIA[]> {
    try {
      // Obtenemos las entradas del diario del estudiante
      const entradas = await db.getDiarioEmocionesByEstudiante(estudianteId)
      if (entradas.length === 0) {
        return []
      }

      // Obtenemos datos del estudiante
      const estudiante = await db.read<Usuario>("usuarios", estudianteId)
      if (!estudiante) {
        throw new Error("Estudiante no encontrado")
      }

      // Analizamos las entradas para detectar patrones
      const sugerencias: SugerenciaIA[] = []

      // Detectamos patrones emocionales negativos
      const entradasNegativas = entradas.filter((e) => e.sentimiento === "negativo")
      if (entradasNegativas.length >= 3) {
        // Si hay varias entradas negativas, generamos una sugerencia
        const id = crypto.randomUUID()
        const sugerencia: SugerenciaIA = {
          id,
          usuarioId: estudianteId,
          rolUsuario: "estudiante",
          titulo: "Patrón emocional detectado",
          descripcion:
            "Hemos detectado un patrón de emociones negativas en tus últimas entradas del diario. Podría ser útil hablar con alguien sobre cómo te sientes.",
          tipo: "emocional",
          prioridad: "alta",
          accionRecomendada: "Agendar una sesión con el psicólogo escolar",
          enlaceAccion: "/dashboard/estudiante/citas/psicologo",
          fechaGeneracion: new Date().toISOString(),
          estado: "pendiente",
          datosRelacionados: [
            {
              tipo: "diarioEmociones",
              id: entradasNegativas[0].id,
              valor: entradasNegativas[0].titulo,
            },
          ],
        }

        sugerencias.push(sugerencia)
        await db.create("sugerenciasIA", id, sugerencia)
      }

      // Detectamos temas recurrentes
      const temasRecurrentes = this.detectarTemasRecurrentes(entradas)
      for (const tema of temasRecurrentes) {
        const id = crypto.randomUUID()
        const sugerencia: SugerenciaIA = {
          id,
          usuarioId: estudianteId,
          rolUsuario: "estudiante",
          titulo: `Tema recurrente: ${tema.tema}`,
          descripcion: `Hemos notado que mencionas frecuentemente "${tema.tema}" en tu diario. Esto podría ser importante para ti.`,
          tipo: "comportamiento",
          prioridad: "media",
          accionRecomendada: "Explorar recursos relacionados con este tema",
          enlaceAccion: `/dashboard/estudiante/recursos/temas/${tema.tema.toLowerCase().replace(/\s+/g, "-")}`,
          fechaGeneracion: new Date().toISOString(),
          estado: "pendiente",
        }

        sugerencias.push(sugerencia)
        await db.create("sugerenciasIA", id, sugerencia)
      }

      return sugerencias
    } catch (error) {
      console.error("Error al generar sugerencias para estudiante:", error)
      return []
    }
  }

  // Detecta temas recurrentes en las entradas del diario
  private detectarTemasRecurrentes(entradas: EntradaDiario[]): { tema: string; frecuencia: number }[] {
    // Simulación simple de análisis de texto
    // En un sistema real, esto utilizaría NLP más avanzado
    const palabrasClave = [
      "examen",
      "tarea",
      "proyecto",
      "amigos",
      "familia",
      "estrés",
      "ansiedad",
      "felicidad",
      "tristeza",
      "miedo",
      "profesor",
      "clase",
      "deporte",
      "música",
      "arte",
    ]

    const conteo: Record<string, number> = {}

    // Contamos la frecuencia de palabras clave
    for (const entrada of entradas) {
      const texto = `${entrada.titulo} ${entrada.contenido}`.toLowerCase()

      for (const palabra of palabrasClave) {
        if (texto.includes(palabra)) {
          conteo[palabra] = (conteo[palabra] || 0) + 1
        }
      }
    }

    // Convertimos a array y ordenamos por frecuencia
    const temas = Object.entries(conteo)
      .map(([tema, frecuencia]) => ({ tema, frecuencia }))
      .filter((item) => item.frecuencia >= 2) // Solo temas que aparecen al menos 2 veces
      .sort((a, b) => b.frecuencia - a.frecuencia)
      .slice(0, 3) // Tomamos los 3 más frecuentes

    return temas
  }

  // Genera sugerencias para profesores basadas en datos de sus estudiantes
  async generarSugerenciasProfesor(profesorId: string): Promise<SugerenciaIA[]> {
    try {
      // Obtenemos las materias que enseña el profesor
      const profesor = await db.read<Usuario>("usuarios", profesorId)
      if (!profesor || !profesor.materias || profesor.materias.length === 0) {
        return []
      }

      // Obtenemos las asignaciones del profesor
      const asignaciones = await db.query(
        "asignacionesProfesores",
        (asignacion: any) => asignacion.profesorId === profesorId,
      )

      if (asignaciones.length === 0) {
        return []
      }

      // Obtenemos los estudiantes de las aulas asignadas
      const aulasIds = asignaciones.map((a) => a.aulaId)
      const estudiantes = await db.query<Usuario>(
        "usuarios",
        (usuario) => usuario.rol === "estudiante" && aulasIds.includes(usuario.aulaId || ""),
      )

      if (estudiantes.length === 0) {
        return []
      }

      // Analizamos el diario de emociones de los estudiantes
      const sugerencias: SugerenciaIA[] = []

      // Detectamos estudiantes con patrones emocionales negativos
      for (const estudiante of estudiantes) {
        const entradas = await db.getDiarioEmocionesByEstudiante(estudiante.id)
        const entradasNegativas = entradas.filter((e) => e.sentimiento === "negativo")

        if (entradasNegativas.length >= 3) {
          const id = crypto.randomUUID()
          const sugerencia: SugerenciaIA = {
            id,
            usuarioId: profesorId,
            rolUsuario: "profesor",
            titulo: `Estudiante en riesgo: ${estudiante.nombre} ${estudiante.apellido}`,
            descripcion: `El estudiante ha registrado múltiples emociones negativas recientemente. Podría necesitar apoyo adicional.`,
            tipo: "comportamiento",
            prioridad: "alta",
            accionRecomendada: "Programar una reunión con el estudiante",
            enlaceAccion: `/dashboard/profesor/estudiantes/${estudiante.id}`,
            fechaGeneracion: new Date().toISOString(),
            estado: "pendiente",
            datosRelacionados: [
              {
                tipo: "usuario",
                id: estudiante.id,
                valor: `${estudiante.nombre} ${estudiante.apellido}`,
              },
            ],
          }

          sugerencias.push(sugerencia)
          await db.create("sugerenciasIA", id, sugerencia)
        }
      }

      return sugerencias
    } catch (error) {
      console.error("Error al generar sugerencias para profesor:", error)
      return []
    }
  }
}

// Exportamos una instancia del servicio
export const iaService = new IAService()

