import { create } from "zustand"

interface User {
  id: string
  email: string
  role: string
}

interface AuthState {
  user: User | null
  setUser: (user: User | null) => void
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  isLoading: boolean
  error: string | null
}

// Store simple para autenticación
export const useAuth = create<AuthState>((set) => ({
  user: null,
  isLoading: false,
  error: null,
  setUser: (user) => set({ user }),
  login: async (email: string, password: string) => {
    set({ isLoading: true, error: null })
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })

      if (!res.ok) {
        const error = await res.json()
        throw new Error(error.error)
      }

      const { user } = await res.json()
      set({ user, isLoading: false })
    } catch (error) {
      set({ error: error.message, isLoading: false })
    }
  },
  logout: async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      set({ user: null })
    } catch (error) {
      console.error("Logout error:", error)
    }
  },
}))

