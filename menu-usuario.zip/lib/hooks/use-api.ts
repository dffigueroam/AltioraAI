"use client"

import { useState, useCallback } from "react"

interface UseApiOptions {
  onSuccess?: (data: any) => void
  onError?: (error: any) => void
}

export function useApi(endpoint: string, options: UseApiOptions = {}) {
  const [data, setData] = useState<any>(null)
  const [error, setError] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const fetchData = useCallback(
    async (params?: Record<string, string>) => {
      try {
        setIsLoading(true)
        const queryString = params ? `?${new URLSearchParams(params)}` : ""
        const response = await fetch(`/api/${endpoint}${queryString}`)
        const result = await response.json()

        if (!response.ok) throw new Error(result.error)

        setData(result)
        options.onSuccess?.(result)
        return result
      } catch (err) {
        setError(err)
        options.onError?.(err)
        throw err
      } finally {
        setIsLoading(false)
      }
    },
    [endpoint, options],
  )

  const createItem = useCallback(
    async (data: any) => {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/${endpoint}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        })
        const result = await response.json()

        if (!response.ok) throw new Error(result.error)

        options.onSuccess?.(result)
        return result
      } catch (err) {
        setError(err)
        options.onError?.(err)
        throw err
      } finally {
        setIsLoading(false)
      }
    },
    [endpoint, options],
  )

  const updateItem = useCallback(
    async (id: string, data: any) => {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/${endpoint}/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        })
        const result = await response.json()

        if (!response.ok) throw new Error(result.error)

        options.onSuccess?.(result)
        return result
      } catch (err) {
        setError(err)
        options.onError?.(err)
        throw err
      } finally {
        setIsLoading(false)
      }
    },
    [endpoint, options],
  )

  const deleteItem = useCallback(
    async (id: string) => {
      try {
        setIsLoading(true)
        const response = await fetch(`/api/${endpoint}/${id}`, {
          method: "DELETE",
        })
        const result = await response.json()

        if (!response.ok) throw new Error(result.error)

        options.onSuccess?.(result)
        return result
      } catch (err) {
        setError(err)
        options.onError?.(err)
        throw err
      } finally {
        setIsLoading(false)
      }
    },
    [endpoint, options],
  )

  return {
    data,
    error,
    isLoading,
    fetchData,
    createItem,
    updateItem,
    deleteItem,
  }
}

