import type { NextRequest } from "next/server"

// Simulación de autenticación simple para desarrollo
const mockUser = {
  id: "1",
  email: "usuario@ejemplo.com",
  role: "profesor",
  profile: {
    name: "Usuario Ejemplo",
    role: "profesor",
  },
}

export async function getUser(req: NextRequest) {
  const token = req.cookies.get("token")?.value
  if (!token) return null

  // En desarrollo, siempre retornamos el usuario mock si hay un token
  return mockUser
}

