import { create } from "zustand"
import { persist } from "zustand/middleware"

// Tipos
export type UserRole = "estudiante" | "profesor" | "padre" | "directivo" | "admin" | "psicologo"

interface Profile {
  firstName: string
  lastName: string
  documentType: string
  documentNumber: string
  birthDate: string
  gender: string
}

interface User {
  id: string
  email: string
  role: UserRole
  profile: Profile
}

interface AuthState {
  user: User | null
  isLoading: boolean
  error: string | null
  setUser: (user: User | null) => void
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
}

// Usuarios de prueba
const mockUsers = [
  // Mantener los usuarios existentes
  {
    id: "1",
    email: "profesor@altiora.edu",
    password: "profesor123",
    role: "profesor" as UserRole,
    profile: {
      firstName: "Juan",
      lastName: "Pérez",
      documentType: "cedula",
      documentNumber: "1234567891",
      birthDate: "1985-01-01",
      gender: "male",
    },
  },
  {
    id: "2",
    email: "estudiante@altiora.edu",
    password: "estudiante123",
    role: "estudiante" as UserRole,
    profile: {
      firstName: "María",
      lastName: "González",
      documentType: "tarjetaIdentidad",
      documentNumber: "1234567892",
      birthDate: "2008-01-01",
      gender: "female",
    },
  },
  {
    id: "3",
    email: "admin@altiora.edu",
    password: "admin123",
    role: "admin" as UserRole,
    profile: {
      firstName: "Admin",
      lastName: "Sistema",
      documentType: "cedula",
      documentNumber: "1234567890",
      birthDate: "1990-01-01",
      gender: "other",
    },
  },
  {
    id: "4",
    email: "admin@altiora.edu",
    password: "admin123",
    role: "admin" as UserRole,
    profile: {
      firstName: "Admin",
      lastName: "Sistema",
      documentType: "cedula",
      documentNumber: "0000000000",
      birthDate: "1990-01-01",
      gender: "other",
    },
  },
  {
    id: "5",
    email: "incidents@altiora.edu",
    password: "admin123",
    role: "admin" as UserRole,
    profile: {
      firstName: "Admin",
      lastName: "Incidencias",
      documentType: "cedula",
      documentNumber: "1111111111",
      birthDate: "1990-01-01",
      gender: "other",
    },
  },
  // Añadir el usuario psicólogo
  {
    id: "6",
    email: "psicologo@altiora.edu",
    password: "psicologo123",
    role: "psicologo" as UserRole,
    profile: {
      firstName: "Carlos",
      lastName: "Martínez",
      documentType: "cedula",
      documentNumber: "2222222222",
      birthDate: "1988-05-15",
      gender: "male",
    },
  },
]

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,
      error: null,
      setUser: (user) => set({ user }),
      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null })
        try {
          // Simular delay de red
          await new Promise((resolve) => setTimeout(resolve, 1000))

          const user = mockUsers.find((u) => u.email === email && u.password === password)
          if (!user) {
            throw new Error("Credenciales inválidas")
          }

          const { password: _, ...userWithoutPassword } = user
          set({ user: userWithoutPassword, isLoading: false })
        } catch (error) {
          set({ error: error.message, isLoading: false })
        }
      },
      logout: async () => {
        // Simular delay de red
        await new Promise((resolve) => setTimeout(resolve, 500))
        set({ user: null })
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)

