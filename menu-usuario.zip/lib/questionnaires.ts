import type { Questionnaire, QuestionnaireType } from "@/types/questionnaire"

export const questionnaires: Record<QuestionnaireType, Questionnaire> = {
  pre_event_stress: {
    id: "pre-event-stress",
    type: "pre_event_stress",
    category: "event_related",
    title: "Evaluación de Estrés Pre-Evento",
    description:
      "Este cuestionario te ayudará a identificar tu nivel de estrés antes de un evento importante (examen, presentación, etc.) para que podamos ayudarte a manejarlo mejor.",
    estimatedTime: 5,
    required: true,
    eventRelated: true,
    relatedEventTypes: ["exam", "presentation", "project_deadline"],
    daysBeforeEvent: 3,
    questions: [
      {
        id: "pes1",
        text: "Pensando en [nombre_del_evento] que tienes en [fecha_del_evento], ¿qué tan nervioso/a o estresado/a te sientes? Por ejemplo: dificultad para dormir la noche anterior, sensación de nervios en el estómago, preocupación constante, o cuando piensas en el evento tus manos sudan o tu corazón late más rápido.",
        type: "scale",
        scaleRange: {
          min: 0,
          max: 4,
          labels: {
            min: "Estoy tranquilo/a",
            max: "Muy estresado/a",
          },
        },
      },
      {
        id: "pes2",
        text: "¿Qué aspectos específicos de [nombre_del_evento] te preocupan más? Por ejemplo: si es un examen de matemáticas, ¿te preocupa no recordar las fórmulas? Si es una presentación, ¿te preocupa hablar en público?",
        type: "multiple",
        options: [
          "No sentirme preparado/a lo suficiente (ejemplo: no haber estudiado todo el material)",
          "Miedo a quedarme en blanco durante el evento (ejemplo: olvidar lo que estudiaste)",
          "Preocupación por la calificación o resultado (ejemplo: necesitar una nota específica para aprobar)",
          "Comparación con el desempeño de mis compañeros (ejemplo: pensar que otros están mejor preparados)",
          "Presión por las expectativas (ejemplo: tus padres o profesores esperan que saques buena nota)",
        ],
      },
      {
        id: "pes3",
        text: "¿Qué síntomas físicos estás experimentando antes de este evento? Piensa en cómo te sientes físicamente cuando piensas en el evento.",
        type: "multiple",
        options: [
          "Dificultad para dormir la noche anterior (ejemplo: dar vueltas en la cama pensando en el evento)",
          "Dolor de estómago o náuseas (ejemplo: no tener hambre o sentir mariposas en el estómago)",
          "Dolor de cabeza (ejemplo: tensión en la frente o sienes)",
          "Tensión muscular (ejemplo: dolor en el cuello o espalda)",
          "Sudoración en las manos (ejemplo: manos frías y húmedas)",
          "No tengo ningún síntoma físico",
        ],
      },
    ],
  },
  pre_event_anxiety: {
    id: "pre-event-anxiety",
    type: "pre_event_anxiety",
    category: "event_related",
    title: "Evaluación de Ansiedad Pre-Evento",
    description:
      "Este cuestionario te ayudará a identificar y manejar la ansiedad que puedas sentir antes de un evento importante.",
    estimatedTime: 5,
    required: true,
    eventRelated: true,
    relatedEventTypes: ["exam", "presentation", "project_deadline", "competition"],
    daysBeforeEvent: 2,
    questions: [
      {
        id: "pea1",
        text: "En relación con [nombre_del_evento] programado para [fecha_del_evento], ¿qué tan ansioso/a te sientes en este momento? Por ejemplo: si tienes una presentación, ¿sientes que tu corazón late más rápido cuando piensas en pararte frente a la clase?",
        type: "scale",
        scaleRange: {
          min: 0,
          max: 4,
          labels: {
            min: "Me siento tranquilo/a",
            max: "Me siento muy ansioso/a",
          },
        },
      },
      {
        id: "pea2",
        text: "¿Qué pensamientos específicos te generan más ansiedad sobre este evento? Piensa en los pensamientos que aparecen en tu mente cuando piensas en el evento.",
        type: "multiple",
        options: [
          "Pensamientos negativos sobre mi desempeño (ejemplo: 'seguro me equivoco' o 'no lo voy a hacer bien')",
          "Preocupación por lo que otros pensarán (ejemplo: 'mis compañeros se van a reír si me equivoco')",
          "Miedo a cometer errores durante el evento (ejemplo: 'me voy a trabar al hablar' o 'voy a resolver mal los ejercicios')",
          "Pensamientos sobre consecuencias negativas (ejemplo: 'si no apruebo, voy a decepcionar a mis padres')",
          "Comparación con experiencias pasadas difíciles (ejemplo: recordar cuando algo similar no salió bien)",
        ],
      },
    ],
  },
  stress: {
    id: "stress-assessment",
    type: "stress",
    title: "Evaluación de Niveles de Estrés",
    description:
      "Este cuestionario te ayudará a identificar qué tan estresado te sientes y qué situaciones te causan más estrés. Tus respuestas nos ayudarán a brindarte mejor apoyo.",
    estimatedTime: 10,
    required: true,
    questions: [
      {
        id: "s1",
        text: "¿Con qué frecuencia te has sentido nervioso/a o estresado/a en el último mes? Por ejemplo: cuando tienes varios exámenes en la misma semana, cuando debes entregar varios trabajos a la vez, o cuando tienes que exponer frente a la clase.",
        type: "scale",
        scaleRange: {
          min: 0,
          max: 4,
          labels: {
            min: "Nunca me siento así",
            max: "Me siento así casi todos los días",
          },
        },
      },
      {
        id: "s2",
        text: "¿Qué situaciones escolares te generan más estrés? Piensa en momentos específicos del día a día en el colegio que te hacen sentir nervioso/a o preocupado/a.",
        type: "multiple",
        options: [
          "Exámenes (ejemplo: cuando tienes un examen final o uno que vale muchos puntos)",
          "Presentaciones orales (ejemplo: cuando debes exponer un trabajo frente a toda la clase)",
          "Tareas y trabajos (ejemplo: cuando tienes que entregar varios trabajos para el mismo día)",
          "Relaciones con compañeros (ejemplo: cuando debes hacer trabajos en grupo o resolver conflictos)",
          "Presión por calificaciones (ejemplo: cuando necesitas subir tu promedio o recuperar una nota baja)",
        ],
      },
      {
        id: "s3",
        text: "¿Cómo calificarías tu capacidad actual para manejar el estrés? Por ejemplo: cuando te sientes nervioso/a antes de un examen, ¿puedes calmarte respirando profundo? Cuando tienes muchas tareas, ¿logras organizarte y hacerlas sin agobiarte?",
        type: "scale",
        scaleRange: {
          min: 1,
          max: 5,
          labels: {
            min: "Me cuesta mucho manejar el estrés",
            max: "Manejo muy bien el estrés",
          },
        },
      },
    ],
  },
  anxiety: {
    id: "anxiety-assessment",
    type: "anxiety",
    title: "Evaluación de Ansiedad",
    description:
      "Este cuestionario te ayudará a identificar situaciones que te ponen nervioso/a o ansioso/a, para poder ayudarte a manejarlas mejor.",
    estimatedTime: 15,
    frequency: 30,
    required: false,
    questions: [
      {
        id: "a1",
        text: "¿Con qué frecuencia te sientes muy nervioso/a o preocupado/a? Por ejemplo: cuando debes participar en clase, cuando hay un cambio en tu rutina escolar, o cuando tienes que conocer nuevos compañeros.",
        type: "scale",
        scaleRange: {
          min: 0,
          max: 4,
          labels: {
            min: "Casi nunca me siento nervioso/a",
            max: "Me siento nervioso/a casi siempre",
          },
        },
      },
      {
        id: "a2",
        text: "Cuando te sientes ansioso/a, ¿qué síntomas físicos experimentas? Piensa en cómo se siente tu cuerpo cuando estás en una situación que te pone nervioso/a, como antes de un examen importante.",
        type: "multiple",
        options: [
          "Corazón acelerado (ejemplo: sientes que tu corazón late muy rápido o fuerte)",
          "Manos sudorosas o frías (ejemplo: tus manos se ponen húmedas cuando estás nervioso/a)",
          "Dificultad para respirar normalmente (ejemplo: sientes que te falta el aire o respiras muy rápido)",
          "Sensación de mariposas en el estómago (ejemplo: sientes un cosquilleo o movimiento en el estómago)",
          "Tensión en los músculos (ejemplo: sientes el cuello o los hombros rígidos)",
        ],
      },
    ],
  },
  depression: {
    id: "depression-screening",
    type: "depression",
    title: "Evaluación de Estado de Ánimo",
    description: "Cuestionario para evaluar tu estado de ánimo actual.",
    estimatedTime: 15,
    frequency: 60,
    required: false,
    questions: [
      {
        id: "d1",
        text: "¿Has notado cambios en tu nivel de energía o motivación? Por ejemplo: te cuesta más levantarte para ir al colegio, no tienes ganas de hacer actividades que antes disfrutabas, o te sientes cansado/a durante el día aunque hayas dormido bien.",
        type: "scale",
        scaleRange: {
          min: 0,
          max: 4,
          labels: {
            min: "Sin cambios",
            max: "Cambios significativos",
          },
        },
      },
    ],
  },
  emotional_intelligence: {
    id: "ei-assessment",
    type: "emotional_intelligence",
    title: "Evaluación de Inteligencia Emocional",
    description: "Evalúa tu capacidad para reconocer y manejar emociones.",
    estimatedTime: 20,
    frequency: 90,
    required: false,
    questions: [
      {
        id: "ei1",
        text: "¿Qué tan bien puedes identificar tus propias emociones? Por ejemplo: cuando estás molesto/a, ¿puedes distinguir si es por enojo, frustración o tristeza? Cuando algo te alegra, ¿puedes explicar qué exactamente te hace sentir así?",
        type: "scale",
        scaleRange: {
          min: 1,
          max: 5,
          labels: {
            min: "Muy mal",
            max: "Muy bien",
          },
        },
      },
    ],
  },
  social_skills: {
    id: "social-skills",
    type: "social_skills",
    title: "Evaluación de Habilidades Sociales",
    description: "Evalúa tus habilidades de interacción social y comunicación.",
    estimatedTime: 15,
    frequency: 90,
    required: false,
    questions: [
      {
        id: "ss1",
        text: "¿Cómo te sientes al participar en actividades grupales? Por ejemplo: cuando debes hacer un trabajo en equipo, cuando te invitan a jugar durante el recreo, o cuando hay que elegir parejas para una actividad en clase.",
        type: "scale",
        scaleRange: {
          min: 1,
          max: 5,
          labels: {
            min: "Muy incómodo",
            max: "Muy cómodo",
          },
        },
      },
    ],
  },
  learning_style: {
    id: "learning-style",
    type: "learning_style",
    category: "personal_development",
    title: "Evaluación de Estilo de Aprendizaje",
    description:
      "Este cuestionario te ayudará a descubrir cómo aprendes mejor. Conocer tu estilo de aprendizaje te ayudará a estudiar de forma más efectiva y a recordar mejor lo que aprendes.",
    estimatedTime: 15,
    frequency: 180,
    required: true,
    eventRelated: false,
    questions: [
      {
        id: "vark1",
        text: "Cuando necesitas aprender algo nuevo, como por ejemplo el tema de 'La Fotosíntesis' en Ciencias Naturales, ¿qué forma te ayuda más a entenderlo?",
        type: "single",
        options: [
          "Ver imágenes o videos (por ejemplo: un video que muestre paso a paso cómo las plantas procesan la luz solar)",
          "Escuchar explicaciones (por ejemplo: que el profesor explique el proceso y poder hacer preguntas)",
          "Leer y escribir (por ejemplo: leer el capítulo del libro y hacer un resumen con tus propias palabras)",
          "Hacer experimentos (por ejemplo: cultivar una planta y observar su crecimiento)",
        ],
      },
      {
        id: "vark2",
        text: "Si tienes que recordar información importante para un examen de Historia, ¿qué método te funciona mejor?",
        type: "single",
        options: [
          "Usar mapas mentales o líneas de tiempo con dibujos (por ejemplo: dibujar los eventos importantes de la Revolución Industrial)",
          "Grabar las explicaciones en tu celular y escucharlas, o explicárselo a un amigo",
          "Hacer resúmenes escritos y releerlos varias veces (por ejemplo: escribir las fechas y eventos más importantes)",
          "Recrear los eventos históricos con movimientos o actuaciones (por ejemplo: representar una escena histórica)",
        ],
      },
      {
        id: "vark3",
        text: "En la clase de Matemáticas, ¿cómo entiendes mejor un nuevo tema como 'Ecuaciones'?",
        type: "single",
        options: [
          "Cuando el profesor dibuja gráficos o usa diagramas en el tablero (por ejemplo: usar balanzas para explicar ecuaciones)",
          "Cuando el profesor explica paso a paso y puedo hacer preguntas (por ejemplo: resolver ejemplos en voz alta)",
          "Cuando puedo leer ejemplos en el libro y resolver ejercicios por escrito (por ejemplo: practicar con ejercicios similares)",
          "Cuando uso objetos o materiales para representar la ecuación (por ejemplo: usar fichas o bloques para entender los números positivos y negativos)",
        ],
      },
    ],
  },
  motivation: {
    id: "motivation-assessment",
    type: "motivation",
    title: "Evaluación de Motivación Académica",
    description: "Evalúa tus niveles actuales de motivación y compromiso académico.",
    estimatedTime: 15,
    frequency: 60,
    required: false,
    questions: [
      {
        id: "m1",
        text: "¿Qué tan motivado te sientes con tus estudios actuales? Por ejemplo: ¿te interesa aprender los temas nuevos? ¿Te emociona hacer los proyectos o tareas? ¿Te dan ganas de participar en clase?",
        type: "scale",
        scaleRange: {
          min: 1,
          max: 5,
          labels: {
            min: "Nada motivado",
            max: "Muy motivado",
          },
        },
      },
    ],
  },
}

// Definir la interfaz QuestionnaireResponse
interface QuestionnaireResponse {
  questionnaireId: string
  completedAt: Date
  eventId?: string
}

// Función helper para determinar si un cuestionario debe mostrarse
export const shouldShowQuestionnaire = (
  questionnaire: Questionnaire,
  upcomingEvents: any[], // Tipo específico según tu estructura de eventos
  previousResponses: QuestionnaireResponse[],
) => {
  // Si es un cuestionario relacionado con eventos
  if (questionnaire.eventRelated) {
    return upcomingEvents.some((event) => {
      // Verificar si el tipo de evento está relacionado con el cuestionario
      if (!questionnaire.relatedEventTypes?.includes(event.type)) {
        return false
      }

      // Calcular días hasta el evento
      const daysUntilEvent = Math.floor((new Date(event.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))

      // Verificar si estamos en el período correcto antes del evento
      if (daysUntilEvent > (questionnaire.daysBeforeEvent || 0)) {
        return false
      }

      // Verificar si ya se completó un cuestionario para este evento
      const hasCompleted = previousResponses.some((response) => response.eventId === event.id)

      return !hasCompleted
    })
  }

  // Para cuestionarios de desarrollo personal
  if (questionnaire.frequency) {
    const lastResponse = previousResponses
      .filter((response) => response.questionnaireId === questionnaire.id)
      .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime())[0]

    if (!lastResponse) {
      return true
    }

    const daysSinceLastResponse = Math.floor(
      (new Date().getTime() - new Date(lastResponse.completedAt).getTime()) / (1000 * 60 * 60 * 24),
    )

    return daysSinceLastResponse >= questionnaire.frequency
  }

  return true
}

