// Utilidades para procesar datos de API

import type { Event, PsychologicalRecord, Assignment } from "./db/schema"
import type { User } from "./db/schema" // Import User
import type { Classroom } from "./db/schema" // Import Classroom

// Función para calcular campos derivados de eventos
export function processEvent(event: Event): Event {
  const currentDate = new Date()
  const eventDate = new Date(`${event.date}T${event.time}`)

  // Calcular estado del evento
  let status: "upcoming" | "ongoing" | "past"
  if (eventDate > currentDate) {
    status = "upcoming"
  } else if (event.endDate) {
    const endDate = new Date(`${event.endDate}T${event.endTime || "23:59"}`)
    status = endDate < currentDate ? "past" : "ongoing"
  } else {
    status = eventDate.toDateString() === currentDate.toDateString() ? "ongoing" : "past"
  }

  // Calcular días restantes
  const diffTime = eventDate.getTime() - currentDate.getTime()
  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  return {
    ...event,
    status,
    daysRemaining: daysRemaining > 0 ? daysRemaining : 0,
  }
}

// Función para procesar registros psicológicos
export function processPsychologicalRecord(record: PsychologicalRecord, users: Map<string, User>): PsychologicalRecord {
  const student = users.get(record.studentId)
  const psychologist = users.get(record.psychologistId)

  let daysUntilFollowUp: number | undefined
  if (record.followUpDate) {
    const currentDate = new Date()
    const followUpDate = new Date(record.followUpDate)
    const diffTime = followUpDate.getTime() - currentDate.getTime()
    daysUntilFollowUp = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  return {
    ...record,
    studentName: student?.name,
    psychologistName: psychologist?.name,
    daysUntilFollowUp,
  }
}

// Función para procesar asignaciones
export function processAssignment(
  assignment: Assignment,
  users: Map<string, User>,
  classrooms: Map<string, Classroom>,
  subjects: Map<string, { id: string; name: string }>,
): Assignment {
  const professor = users.get(assignment.professorId)
  const classroom = classrooms.get(assignment.classroomId)
  const subject = subjects.get(assignment.subjectId)

  // Calcular horas por semana
  let hoursPerWeek = 0
  assignment.schedule.forEach((slot) => {
    const start = new Date(`1970-01-01T${slot.startTime}:00`)
    const end = new Date(`1970-01-01T${slot.endTime}:00`)
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)
    hoursPerWeek += hours
  })

  return {
    ...assignment,
    professorName: professor?.name,
    classroomName: classroom?.name,
    subjectName: subject?.name,
    hoursPerWeek,
  }
}

