export type UserRole = "estudiante" | "profesor" | "padre" | "directivo" | "admin"

export interface UserProfile {
  firstName: string
  lastName: string
  documentType: string
  documentNumber: string
  birthDate: string
  gender: string
  profilePhoto?: string // URL de la foto de perfil
}

export interface RegistrationResponse {
  status: "pendiente" | "aprobado" | "rechazado"
  message: string
  registrationId: string
  profile?: UserProfile
}

