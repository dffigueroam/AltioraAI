export type IncidentType =
  | "class_deletion"
  | "event_deletion"
  | "teacher_reassignment"
  | "unauthorized_access"
  | "system_error"
  | "data_modification"

export type IncidentStatus = "pending" | "in_review" | "resolved" | "rejected"

export type IncidentPriority = "low" | "medium" | "high" | "critical"

export interface Incident {
  id: string
  type: IncidentType
  title: string
  description: string
  createdAt: string
  createdBy: {
    id: string
    name: string
    role: string
  }
  status: IncidentStatus
  priority: IncidentPriority
  affectedData: {
    type: "class" | "event" | "teacher" | "system"
    id: string
    details: any
  }
  resolution?: {
    resolvedAt: string
    resolvedBy: string
    action: "restore" | "confirm_deletion" | "modify" | "ignore"
    notes: string
  }
}

export interface IncidentLog {
  id: string
  incidentId: string
  timestamp: string
  action: string
  performedBy: string
  details: string
}

