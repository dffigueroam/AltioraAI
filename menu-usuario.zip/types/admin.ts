export interface AdminLog {
  id: string
  timestamp: string
  action: "delete" | "modify" | "reassign" | "report"
  userId: string
  userRole: string
  description: string
  status: "pending" | "resolved" | "in_progress"
  priority: "low" | "medium" | "high"
  affectedArea: "classes" | "teachers" | "students" | "events" | "system"
  details: {
    previousState?: any
    newState?: any
    reason?: string
  }
}

export interface SystemReport {
  id: string
  reportedBy: {
    id: string
    name: string
    role: string
  }
  timestamp: string
  category: "bug" | "security" | "performance" | "feature" | "other"
  title: string
  description: string
  status: "open" | "in_progress" | "resolved" | "closed"
  priority: "low" | "medium" | "high" | "critical"
  assignedTo?: string
  resolution?: string
  attachments?: string[]
}

