export type TeacherRole = "normal" | "director_grupo"

export interface Teacher {
  id: string
  name: string
  role: TeacherRole
  assignedClassroom?: string // Grupo del que es director
  teachingClassrooms: string[] // Grupos a los que da clase
}

