export type EmotionalStateType = "pre_event" | "anxiety" | "learning_style" | "behavioral" | "social"

export type AttentionLevel = "urgent" | "needs_attention" | "normal" | "monitoring"

export interface StudentEmotionalState {
  id: string
  studentName: string
  stateType: EmotionalStateType
  attentionLevel: AttentionLevel
  date: string
  recommendation: string
  assignedTo?: {
    id: string
    name: string
    role: "teacher" | "psychologist"
  }
  status: "pending" | "in_progress" | "completed"
  notes?: {
    id: string
    text: string
    date: string
    author: {
      id: string
      name: string
      role: "teacher" | "psychologist"
    }
  }[]
}

