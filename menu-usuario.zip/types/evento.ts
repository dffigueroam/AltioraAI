export type TipoEvento =
  | "academico"
  | "administrativo"
  | "competencia"
  | "evaluacion"
  | "psicologico"
  | "terapia"
  | "taller"
export type EstadoEvento = "próximo" | "en_curso" | "finalizado" | "cancelado" | "programado"
export type CategoriaDeporte = "Sub-12" | "Sub-15" | "Sub-17" | "Juvenil" | "General"
export type TipoDeporte = "Fútbol" | "Baloncesto" | "Voleibol" | "Natación" | "Atletismo" | "Múltiple"

export interface Evento {
  id: string
  titulo: string
  fecha: string
  hora: string
  tipo: TipoEvento
  estado: EstadoEvento
  descripcion: string
  lugar: string
  categoria?: CategoriaDeporte
  deporte?: TipoDeporte
  createdAt: string
  updatedAt: string
  createdBy: string
}

export type CreateEventoInput = Omit<Evento, "id" | "createdAt" | "updatedAt">
export type UpdateEventoInput = Partial<CreateEventoInput>

