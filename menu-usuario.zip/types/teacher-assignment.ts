export interface TeacherAssignment {
  id: string
  teacherId: string
  classroomId: string
  subjectId: string
  isGroupDirector: boolean
}

export interface Subject {
  id: string
  name: string
  code: string
}

export interface TeacherWithDetails {
  id: string
  name: string
  email: string
  specialties: string[]
  assignedClassrooms: string[]
  directorOf?: string
}

