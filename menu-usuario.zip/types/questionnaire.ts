export type QuestionType = "single" | "multiple" | "scale" | "text"

export type QuestionnaireType =
  | "pre_event_stress"
  | "pre_event_anxiety"
  | "learning_style"
  | "emotional_intelligence"
  | "social_skills"
  | "motivation"

export type QuestionnaireCategory = "event_related" | "personal_development"

export interface Question {
  id: string
  text: string
  type: QuestionType
  options?: string[]
  scaleRange?: {
    min: number
    max: number
    labels: {
      min: string
      max: string
    }
  }
}

export interface Questionnaire {
  id: string
  type: QuestionnaireType
  category: QuestionnaireCategory
  title: string
  description: string
  estimatedTime: number // en minutos
  questions: Question[]
  frequency?: number // en días
  required: boolean
  eventRelated?: boolean
  relatedEventTypes?: string[] // tipos de eventos que disparan este cuestionario
  daysBeforeEvent?: number // días antes del evento que debe completarse
}

export interface QuestionnaireResponse {
  id: string
  questionnaireId: string
  studentId: string
  eventId?: string // ID del evento relacionado si aplica
  answers: {
    questionId: string
    value: string | number | string[]
  }[]
  score?: number
  completedAt: string
  recommendations?: string[]
}

export interface QuestionnaireSchedule {
  id: string
  questionnaireId: string
  studentId: string
  eventId?: string // ID del evento relacionado si aplica
  scheduledFor: string
  completedAt?: string
  status: "pending" | "completed" | "overdue"
  priority: "high" | "medium" | "low"
  dueDate: string
}

