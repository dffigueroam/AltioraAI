export type PsychologistSpecialty = "clinical" | "educational" | "developmental" | "counseling"

export interface Psychologist {
  id: string
  name: string
  specialty: PsychologistSpecialty
  assignedGrades: string[] // Grados escolares asignados
  certifications: string[] // Certificaciones profesionales
  availability: {
    days: string[]
    hours: string
  }
  contactInfo: {
    email: string
    phone: string
    office: string
  }
}

