export interface Tema {
  id: string
  titulo: string
  descripcion: string
  materia: string
  fecha: string
  archivos?: File[]
  tags: string[]
  profesorId: string
  estado: "programado" | "completado" | "cancelado"
}

export interface Tag {
  id: string
  nombre: string
  color: string
}

