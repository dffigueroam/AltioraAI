"use client"

import { useState } from "react"

export default function DiarioBasicoPage() {
  const [sentimiento, setSentimiento] = useState<string>("neutral")
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")

  // Ejemplos de entradas para mostrar
  const ejemplos = [
    "Hoy tuve un día con muchas cosas por hacer y necesité ayuda.",
    "Hoy tuve un altercado con mi papá.",
    "Siento que no he dormido lo suficiente.",
    "Me fue muy bien en el examen de matemáticas.",
    "Estoy preocupado por el proyecto grupal.",
  ]

  const handleGuardarEntrada = () => {
    alert("Entrada guardada: " + titulo)
    setTitulo("")
    setContenido("")
    setSentimiento("neutral")
  }

  return (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "20px" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>Diario De Emociones</h1>

      <div style={{ backgroundColor: "white", padding: "24px", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
        <div style={{ marginBottom: "16px" }}>
          <label htmlFor="titulo" style={{ display: "block", marginBottom: "8px", fontWeight: "500" }}>
            Título de tu entrada
          </label>
          <input
            id="titulo"
            placeholder="Resume en una frase cómo te sientes"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            style={{
              width: "100%",
              padding: "8px 12px",
              border: "1px solid #d1d5db",
              borderRadius: "4px",
            }}
          />
        </div>

        <div style={{ marginBottom: "16px" }}>
          <label htmlFor="contenido" style={{ display: "block", marginBottom: "8px", fontWeight: "500" }}>
            Cuéntanos más
          </label>
          <textarea
            id="contenido"
            placeholder="Describe cómo te sientes, qué ha pasado hoy o cualquier cosa que quieras compartir..."
            value={contenido}
            onChange={(e) => setContenido(e.target.value)}
            rows={6}
            style={{
              width: "100%",
              padding: "8px 12px",
              border: "1px solid #d1d5db",
              borderRadius: "4px",
            }}
          />

          {!contenido && (
            <div style={{ marginTop: "12px" }}>
              <p style={{ fontSize: "14px", color: "#6b7280", marginBottom: "8px" }}>Ejemplos:</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                {ejemplos.map((ejemplo, index) => (
                  <button
                    key={index}
                    style={{
                      padding: "4px 12px",
                      fontSize: "12px",
                      backgroundColor: "#f3f4f6",
                      border: "none",
                      borderRadius: "9999px",
                      cursor: "pointer",
                    }}
                    onClick={() => setContenido(ejemplo)}
                  >
                    {ejemplo}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div style={{ marginBottom: "16px" }}>
          <label style={{ display: "block", marginBottom: "8px", fontWeight: "500" }}>¿Cómo te hace sentir?</label>
          <div style={{ display: "flex", gap: "8px" }}>
            <button
              style={{
                flex: 1,
                padding: "8px 16px",
                borderRadius: "4px",
                border: "none",
                backgroundColor: sentimiento === "positivo" ? "#2563eb" : "#f3f4f6",
                color: sentimiento === "positivo" ? "white" : "#374151",
                cursor: "pointer",
              }}
              onClick={() => setSentimiento("positivo")}
            >
              Bien
            </button>
            <button
              style={{
                flex: 1,
                padding: "8px 16px",
                borderRadius: "4px",
                border: "none",
                backgroundColor: sentimiento === "neutral" ? "#2563eb" : "#f3f4f6",
                color: sentimiento === "neutral" ? "white" : "#374151",
                cursor: "pointer",
              }}
              onClick={() => setSentimiento("neutral")}
            >
              Neutral
            </button>
            <button
              style={{
                flex: 1,
                padding: "8px 16px",
                borderRadius: "4px",
                border: "none",
                backgroundColor: sentimiento === "negativo" ? "#2563eb" : "#f3f4f6",
                color: sentimiento === "negativo" ? "white" : "#374151",
                cursor: "pointer",
              }}
              onClick={() => setSentimiento("negativo")}
            >
              Mal
            </button>
          </div>
        </div>

        <button
          onClick={handleGuardarEntrada}
          disabled={!contenido || !titulo}
          style={{
            width: "100%",
            padding: "8px 16px",
            borderRadius: "4px",
            border: "none",
            backgroundColor: !contenido || !titulo ? "#d1d5db" : "#2563eb",
            color: !contenido || !titulo ? "#6b7280" : "white",
            cursor: !contenido || !titulo ? "not-allowed" : "pointer",
          }}
        >
          Guardar en mi diario
        </button>
      </div>

      {/* Barra de navegación inferior simplificada */}
      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#f9fafb",
          borderTop: "1px solid #e5e7eb",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "flex", overflowX: "auto" }}>
            <button style={{ flex: 1, padding: "12px 8px", fontSize: "14px", textAlign: "center", color: "#6b7280" }}>
              Acciones Pendientes
            </button>
            <button style={{ flex: 1, padding: "12px 8px", fontSize: "14px", textAlign: "center", color: "#6b7280" }}>
              Eventos
            </button>
            <button style={{ flex: 1, padding: "12px 8px", fontSize: "14px", textAlign: "center", color: "#6b7280" }}>
              Enlaces de Interés
            </button>
            <button style={{ flex: 1, padding: "12px 8px", fontSize: "14px", textAlign: "center", color: "#6b7280" }}>
              Deportes
            </button>
            <button
              style={{
                flex: 1,
                padding: "12px 8px",
                fontSize: "14px",
                textAlign: "center",
                color: "#2563eb",
                borderTop: "2px solid #2563eb",
              }}
            >
              Diario De Emociones
            </button>
            <button style={{ flex: 1, padding: "12px 8px", fontSize: "14px", textAlign: "center", color: "#6b7280" }}>
              Gestión sugerida de la IA
            </button>
          </div>
        </div>
      </div>

      {/* Espaciado para la barra de navegación fija */}
      <div style={{ height: "64px" }}></div>
    </div>
  )
}

