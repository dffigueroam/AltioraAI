"use client"

import { useState } from "react"
import Link from "next/link"

export default function DiarioEmocionesPage() {
  const [sentimiento, setSentimiento] = useState<string>("neutral")
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")

  // Ejemplos de entradas para mostrar
  const ejemplos = [
    "Hoy tuve un día con muchas cosas por hacer y necesité ayuda.",
    "Hoy tuve un altercado con mi papá.",
    "Siento que no he dormido lo suficiente.",
    "Me fue muy bien en el examen de matemáticas.",
    "Estoy preocupado por el proyecto grupal.",
  ]

  const handleGuardarEntrada = () => {
    alert("Entrada guardada: " + titulo)
    setTitulo("")
    setContenido("")
    setSentimiento("neutral")
  }

  return (
    <div className="container mx-auto px-4 py-6 pb-20 max-w-3xl">
      <div className="mb-4">
        <Link href="/dashboard/estudiante" className="text-blue-600 hover:underline">
          ← Volver al Dashboard
        </Link>
      </div>

      <h1 className="text-2xl font-bold mb-6">Diario De Emociones</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="mb-4">
          <label htmlFor="titulo" className="block text-sm font-medium text-gray-700 mb-1">
            Título de tu entrada
          </label>
          <input
            type="text"
            id="titulo"
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="Resume en una frase cómo te sientes"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label htmlFor="contenido" className="block text-sm font-medium text-gray-700 mb-1">
            Cuéntanos más
          </label>
          <textarea
            id="contenido"
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="Describe cómo te sientes, qué ha pasado hoy o cualquier cosa que quieras compartir..."
            value={contenido}
            onChange={(e) => setContenido(e.target.value)}
            rows={4}
          />

          {!contenido && (
            <div className="mt-2">
              <p className="text-sm text-gray-500 mb-2">Ejemplos:</p>
              <div className="flex flex-wrap gap-2">
                {ejemplos.map((ejemplo, index) => (
                  <button
                    key={index}
                    className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full"
                    onClick={() => setContenido(ejemplo)}
                  >
                    {ejemplo}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">¿Cómo te hace sentir?</label>
          <div className="flex gap-2">
            <button
              className={`flex-1 py-2 px-4 rounded-md ${
                sentimiento === "positivo" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
              onClick={() => setSentimiento("positivo")}
            >
              Bien
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-md ${
                sentimiento === "neutral" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
              onClick={() => setSentimiento("neutral")}
            >
              Neutral
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-md ${
                sentimiento === "negativo" ? "bg-red-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
              onClick={() => setSentimiento("negativo")}
            >
              Mal
            </button>
          </div>
        </div>

        <button
          onClick={handleGuardarEntrada}
          disabled={!contenido || !titulo}
          className={`w-full py-2 px-4 rounded-md ${
            !contenido || !titulo
              ? "bg-gray-300 text-gray-500 cursor-not-allowed"
              : "bg-blue-600 text-white hover:bg-blue-700"
          }`}
        >
          Guardar en mi diario
        </button>
      </div>

      {/* Barra de navegación inferior */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md">
        <div className="container mx-auto">
          <div className="flex overflow-x-auto">
            <Link href="/dashboard/estudiante" className="flex-1 py-3 px-2 text-sm text-center text-gray-600">
              Inicio
            </Link>
            <Link href="#" className="flex-1 py-3 px-2 text-sm text-center text-gray-600">
              Tareas
            </Link>
            <Link href="#" className="flex-1 py-3 px-2 text-sm text-center text-gray-600">
              Eventos
            </Link>
            <Link
              href="/diario-emociones"
              className="flex-1 py-3 px-2 text-sm text-center text-blue-600 border-t-2 border-blue-600"
            >
              Diario De Emociones
            </Link>
            <Link href="#" className="flex-1 py-3 px-2 text-sm text-center text-gray-600">
              Recursos
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

