"use client"

import { NavegacionInferior } from "@/components/navegacion-inferior"

export default function TestNavegacionPage() {
  return (
    <div className="min-h-screen p-6">
      <h1 className="text-2xl font-bold mb-6">Prueba de Navegación Inferior</h1>
      <p className="mb-4">Esta página muestra la barra de navegación inferior con la opción "Diario De Emociones".</p>

      <div className="mb-20">
        <p>Contenido de la página...</p>
      </div>

      <NavegacionInferior />
    </div>
  )
}

