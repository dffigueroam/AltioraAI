import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center text-[#1E40AF] mb-8">Iniciar Sesión en ALTIORA AI</h1>
        <LoginForm />
      </div>
    </div>
  )
}

