"use client"

import { useState } from "react"
import { ClassroomSelector } from "@/components/classroom-selector"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function PreviewPage() {
  const [selectedClassroom, setSelectedClassroom] = useState("")

  // Datos de prueba
  const mockTeachingClassrooms = ["2A", "3B", "4A", "5B"]
  const mockAssignedClassroom = "3B"

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <Button variant="ghost" className="text-[#1E40AF]" asChild>
          <Link href="/preview">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Preview
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-[#1E40AF]">Vista Previa - Selector de Grupos</CardTitle>
          <CardDescription>
            Este componente permite a los profesores seleccionar entre los grupos que tienen asignados.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600 mb-2">Información de prueba:</p>
              <ul className="list-disc list-inside space-y-1 text-sm text-slate-600">
                <li>Grupos asignados para enseñanza: {mockTeachingClassrooms.join(", ")}</li>
                <li>Director del grupo: {mockAssignedClassroom}</li>
                <li>Grupo seleccionado actualmente: {selectedClassroom || "Ninguno"}</li>
              </ul>
            </div>

            <ClassroomSelector
              onSelectClassroom={setSelectedClassroom}
              assignedClassroom={mockAssignedClassroom}
              teachingClassrooms={mockTeachingClassrooms}
              isDirectorGrupo={true}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

