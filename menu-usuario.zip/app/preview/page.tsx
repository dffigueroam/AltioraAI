"use client"

import { StudentPsychologicalOverview } from "@/components/student-psychological-overview"

export default function PreviewPage() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6 text-[#1E40AF]">Vista Previa del Componente</h1>
      <StudentPsychologicalOverview classroomId="10A" isDirectorGrupo={true} />
    </div>
  )
}

