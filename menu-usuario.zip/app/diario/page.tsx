"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

export default function DiarioPage() {
  const [sentimiento, setSentimiento] = useState<string>("neutral")
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")

  // Ejemplos de entradas para mostrar
  const ejemplos = [
    "Hoy tuve un día con muchas cosas por hacer y necesité ayuda.",
    "Hoy tuve un altercado con mi papá.",
    "Siento que no he dormido lo suficiente.",
    "Me fue muy bien en el examen de matemáticas.",
    "Estoy preocupado por el proyecto grupal.",
  ]

  const handleGuardarEntrada = () => {
    alert("Entrada guardada: " + titulo)
    setTitulo("")
    setContenido("")
    setSentimiento("neutral")
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Diario De Emociones</h1>

      <Card className="w-full">
        <CardContent className="p-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="titulo">Título de tu entrada</Label>
            <Input
              id="titulo"
              placeholder="Resume en una frase cómo te sientes"
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contenido">Cuéntanos más</Label>
            <Textarea
              id="contenido"
              placeholder="Describe cómo te sientes, qué ha pasado hoy o cualquier cosa que quieras compartir..."
              value={contenido}
              onChange={(e) => setContenido(e.target.value)}
              rows={4}
            />

            {!contenido && (
              <div className="mt-2">
                <p className="text-sm text-gray-500 mb-2">Ejemplos:</p>
                <div className="flex flex-wrap gap-2">
                  {ejemplos.map((ejemplo, index) => (
                    <Button key={index} variant="outline" size="sm" onClick={() => setContenido(ejemplo)}>
                      {ejemplo}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>¿Cómo te hace sentir?</Label>
            <div className="flex gap-2">
              <Button
                variant={sentimiento === "positivo" ? "default" : "outline"}
                onClick={() => setSentimiento("positivo")}
                className={`flex-1 ${sentimiento === "positivo" ? "bg-green-600 hover:bg-green-700" : ""}`}
              >
                Bien
              </Button>
              <Button
                variant={sentimiento === "neutral" ? "default" : "outline"}
                onClick={() => setSentimiento("neutral")}
                className={`flex-1 ${sentimiento === "neutral" ? "bg-blue-600 hover:bg-blue-700" : ""}`}
              >
                Neutral
              </Button>
              <Button
                variant={sentimiento === "negativo" ? "default" : "outline"}
                onClick={() => setSentimiento("negativo")}
                className={`flex-1 ${sentimiento === "negativo" ? "bg-red-600 hover:bg-red-700" : ""}`}
              >
                Mal
              </Button>
            </div>
          </div>

          <Button onClick={handleGuardarEntrada} disabled={!contenido || !titulo} className="w-full">
            Guardar en mi diario
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

