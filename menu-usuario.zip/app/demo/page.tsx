"use client"

import { useState, useCallback } from "react"
import { DashboardEducativo } from "@/components/dashboard-educativo"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"
import { Heart } from "lucide-react"
import { Brain } from "lucide-react"

// Actualizar el tipo UserRole para incluir "psicologo"
type UserRole = "estudiante" | "profesor" | "padre" | "directivo" | "admin" | "psicologo"

// Modificar la función DemoPage para incluir la opción de psicólogo en el selector
export default function DemoPage() {
  const [selectedRole, setSelectedRole] = useState<UserRole>("estudiante")

  const handleRoleChange = useCallback((value: string) => {
    setSelectedRole(value as UserRole)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <DemoBanner />

      <div className="container mx-auto px-4 py-6">
        <RoleSelection selectedRole={selectedRole} onRoleChange={handleRoleChange} />

        {selectedRole === "admin" && <AdminAlert />}
        {selectedRole === "estudiante" && <EstudianteInfo />}
        {selectedRole === "psicologo" && <PsicologoInfo />}

        <DashboardEducativo initialRole={selectedRole} isDemo={true} />
      </div>
    </div>
  )
}

/** Banner de demostración */
function DemoBanner() {
  return (
    <div className="bg-[#1E40AF] text-white py-4">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5" />
          <span className="font-medium">Modo Demostración</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/registro">
            <Button variant="secondary">Registrarse</Button>
          </Link>
          <Link href="/login">
            <Button variant="secondary">Iniciar Sesión</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

// Actualizar el componente RoleSelection para incluir la opción de psicólogo
function RoleSelection({
  selectedRole,
  onRoleChange,
}: { selectedRole: UserRole; onRoleChange: (value: string) => void }) {
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Vista Previa de la Plataforma</CardTitle>
        <CardDescription>Selecciona un rol para explorar las diferentes funcionalidades de ALTIORA AI</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="w-full sm:w-64">
            <Select value={selectedRole} onValueChange={onRoleChange}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un rol" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="estudiante">Vista de Estudiante</SelectItem>
                <SelectItem value="profesor">Vista de Profesor</SelectItem>
                <SelectItem value="padre">Vista de Padre/Acudiente</SelectItem>
                <SelectItem value="directivo">Vista de Directivo</SelectItem>
                <SelectItem value="admin">Vista de Administrador</SelectItem>
                <SelectItem value="psicologo">Vista de Psicólogo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Alert className="flex-1">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Modo Demostración</AlertTitle>
            <AlertDescription>
              Esta es una vista previa con datos de ejemplo. Para acceder a todas las funcionalidades, por favor
              regístrate o inicia sesión.
              {selectedRole === "estudiante" && (
                <div className="mt-2 text-blue-600">
                  Como estudiante, puedes acceder al{" "}
                  <Link href="/dashboard/estudiante/diario-emociones" className="font-bold underline">
                    Diario de Emociones
                  </Link>{" "}
                  para registrar y hacer seguimiento a tu bienestar emocional.
                </div>
              )}
              {selectedRole === "psicologo" && (
                <div className="mt-2 text-purple-600">
                  Como psicólogo, puedes acceder a los{" "}
                  <Link href="/dashboard/psicologo/casos-emocionales" className="font-bold underline">
                    Casos Emocionales
                  </Link>{" "}
                  para dar seguimiento al bienestar de los estudiantes.
                </div>
              )}
            </AlertDescription>
          </Alert>
        </div>
      </CardContent>
    </Card>
  )
}

/** Alerta específica para el rol de Administrador */
function AdminAlert() {
  return (
    <Alert className="mb-6 bg-yellow-50 border-yellow-200">
      <AlertCircle className="h-4 w-4 text-yellow-800" />
      <AlertTitle className="text-yellow-800">Vista de Administrador</AlertTitle>
      <AlertDescription className="text-yellow-700">
        Como administrador, podrás gestionar incidencias del sistema, revisar logs de cambios y manejar reportes de
        usuarios. En esta vista de demostración, las acciones están limitadas.
      </AlertDescription>
    </Alert>
  )
}

// Agregar un componente específico para estudiantes que muestre información sobre el diario de emociones
function EstudianteInfo() {
  return (
    <Card className="mb-6 border-blue-200 bg-blue-50">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Heart className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-blue-800 mb-2">Diario de Emociones</h3>
            <p className="text-blue-700 mb-4">
              Como estudiante, tienes acceso a nuestro Diario de Emociones, una herramienta diseñada para ayudarte a
              registrar y comprender tus emociones diarias.
            </p>
            <Link href="/dashboard/estudiante/diario-emociones">
              <Button className="bg-blue-600 hover:bg-blue-700">Acceder al Diario de Emociones</Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Añadir un componente específico para psicólogos
function PsicologoInfo() {
  return (
    <Card className="mb-6 border-purple-200 bg-purple-50">
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <Brain className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-purple-800 mb-2">Seguimiento Emocional</h3>
            <p className="text-purple-700 mb-4">
              Como psicólogo, tienes acceso a nuestro sistema de seguimiento emocional, una herramienta diseñada para
              ayudarte a monitorear y apoyar el bienestar psicológico de los estudiantes.
            </p>
            <Link href="/dashboard/psicologo/casos-emocionales">
              <Button className="bg-purple-600 hover:bg-purple-700">Acceder a Casos Emocionales</Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

