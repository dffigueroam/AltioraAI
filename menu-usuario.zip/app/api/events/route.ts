import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { processEvent } from "@/lib/api-utils"
import * as crypto from "crypto"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")

    let events
    if (type) {
      events = await db.query("events", (event) => event.type === type)
    } else {
      events = await db.readAll("events")
    }

    // Procesar cada evento para añadir campos derivados
    const processedEvents = events.map((event) => processEvent(event))

    return NextResponse.json(processedEvents)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const id = crypto.randomUUID()
    const event = await db.create("events", id, { id, ...data })
    return NextResponse.json(event)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create event" }, { status: 500 })
  }
}

