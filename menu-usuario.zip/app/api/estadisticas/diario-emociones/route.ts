import { NextResponse } from "next/server"

// Mock data for emotional diary statistics
const mockEmotionalDiaryStats = {
  totalEntries: 156,
  weeklyAverage: 4.2,
  monthlyTrend: "+12%",
  emotionBreakdown: {
    happy: 42,
    calm: 38,
    sad: 25,
    angry: 15,
    anxious: 20,
    other: 16,
  },
  recentMoods: [
    { date: "2023-11-01", mood: "happy" },
    { date: "2023-11-02", mood: "calm" },
    { date: "2023-11-03", mood: "anxious" },
    { date: "2023-11-04", mood: "happy" },
    { date: "2023-11-05", mood: "sad" },
  ],
}

export async function GET() {
  // Instead of using request.url which causes dynamic server usage,
  // we'll return a static response

  try {
    // Simulate a delay to mimic a real API call
    await new Promise((resolve) => setTimeout(resolve, 100))

    return NextResponse.json({
      success: true,
      data: mockEmotionalDiaryStats,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch emotional diary statistics" }, { status: 500 })
  }
}

