import { NextResponse } from "next/server"
import { db } from "@/lib/db/index-completo"
import type { SugerenciaIA } from "@/lib/db/schema-completo"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const usuarioId = searchParams.get("usuarioId")
    const rolUsuario = searchParams.get("rolUsuario") as "estudiante" | "profesor" | "admin" | null
    const prioridad = searchParams.get("prioridad") as "alta" | "media" | "baja" | null

    let sugerencias: SugerenciaIA[] = []

    if (usuarioId) {
      sugerencias = await db.getSugerenciasByUsuario(usuarioId)
    } else if (rolUsuario) {
      sugerencias = await db.getSugerenciasByRol(rolUsuario)
    } else if (prioridad) {
      sugerencias = await db.getSugerenciasByPrioridad(prioridad)
    } else {
      sugerencias = await db.readAll("sugerenciasIA")
    }

    return NextResponse.json(sugerencias)
  } catch (error) {
    console.error("Error al obtener sugerencias de IA:", error)
    return NextResponse.json({ error: "Error al obtener sugerencias de IA" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validamos los campos requeridos
    if (
      !data.usuarioId ||
      !data.rolUsuario ||
      !data.titulo ||
      !data.descripcion ||
      !data.tipo ||
      !data.prioridad ||
      !data.accionRecomendada
    ) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 })
    }

    // Generamos un ID único
    const id = crypto.randomUUID()

    // Creamos la sugerencia
    const sugerencia: SugerenciaIA = {
      id,
      usuarioId: data.usuarioId,
      rolUsuario: data.rolUsuario,
      titulo: data.titulo,
      descripcion: data.descripcion,
      tipo: data.tipo,
      prioridad: data.prioridad,
      accionRecomendada: data.accionRecomendada,
      enlaceAccion: data.enlaceAccion,
      fechaGeneracion: new Date().toISOString(),
      estado: "pendiente",
      datosRelacionados: data.datosRelacionados,
    }

    // Guardamos la sugerencia
    await db.create("sugerenciasIA", id, sugerencia)

    return NextResponse.json(sugerencia, { status: 201 })
  } catch (error) {
    console.error("Error al crear sugerencia de IA:", error)
    return NextResponse.json({ error: "Error al crear sugerencia de IA" }, { status: 500 })
  }
}

