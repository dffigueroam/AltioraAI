import { NextResponse } from "next/server"
import { iaService } from "@/lib/services/ia-service"
import { db } from "@/lib/db/index-completo"

export async function POST(request: Request) {
  try {
    const { usuarioId, rol } = await request.json()

    if (!usuarioId || !rol) {
      return NextResponse.json({ error: "Se requiere el ID y rol del usuario" }, { status: 400 })
    }

    // Verificamos que el usuario exista
    const usuario = await db.read("usuarios", usuarioId)
    if (!usuario) {
      return NextResponse.json({ error: "Usuario no encontrado" }, { status: 404 })
    }

    let sugerencias = []

    // Generamos sugerencias según el rol
    if (rol === "estudiante") {
      sugerencias = await iaService.generarSugerenciasEstudiante(usuarioId)
    } else if (rol === "profesor") {
      sugerencias = await iaService.generarSugerenciasProfesor(usuarioId)
    } else {
      return NextResponse.json({ error: "Rol no soportado para generación de sugerencias" }, { status: 400 })
    }

    return NextResponse.json({ sugerencias, count: sugerencias.length })
  } catch (error) {
    console.error("Error al generar sugerencias de IA:", error)
    return NextResponse.json({ error: "Error al generar sugerencias de IA" }, { status: 500 })
  }
}

