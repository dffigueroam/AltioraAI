import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const classroom = searchParams.get("classroom")

    let assignments
    if (classroom) {
      assignments = await db.query("assignments", (assignment) => assignment.classroomId === classroom)
    } else {
      assignments = await db.readAll("assignments")
    }

    return NextResponse.json(assignments)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch assignments" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const id = crypto.randomUUID()
    const assignment = await db.create("assignments", id, { id, ...data })
    return NextResponse.json(assignment)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create assignment" }, { status: 500 })
  }
}

