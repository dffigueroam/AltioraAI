import { NextResponse } from "next/server"
import { db } from "@/lib/db/index-completo"
import type { EntradaDiario } from "@/lib/db/schema-completo"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const entrada = await db.read<EntradaDiario>("diarioEmociones", params.id)

    if (!entrada) {
      return NextResponse.json({ error: "Entrada no encontrada" }, { status: 404 })
    }

    return NextResponse.json(entrada)
  } catch (error) {
    console.error("Error al obtener entrada del diario:", error)
    return NextResponse.json({ error: "Error al obtener entrada del diario" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()

    // Verificamos que la entrada exista
    const entradaExistente = await db.read<EntradaDiario>("diarioEmociones", params.id)
    if (!entradaExistente) {
      return NextResponse.json({ error: "Entrada no encontrada" }, { status: 404 })
    }

    // Actualizamos la entrada
    const entradaActualizada = await db.update<EntradaDiario>("diarioEmociones", params.id, data)

    return NextResponse.json(entradaActualizada)
  } catch (error) {
    console.error("Error al actualizar entrada del diario:", error)
    return NextResponse.json({ error: "Error al actualizar entrada del diario" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    // Verificamos que la entrada exista
    const entradaExistente = await db.read<EntradaDiario>("diarioEmociones", params.id)
    if (!entradaExistente) {
      return NextResponse.json({ error: "Entrada no encontrada" }, { status: 404 })
    }

    // Eliminamos la entrada
    const resultado = await db.delete("diarioEmociones", params.id)

    if (resultado) {
      return NextResponse.json({ success: true })
    } else {
      return NextResponse.json({ error: "Error al eliminar entrada" }, { status: 500 })
    }
  } catch (error) {
    console.error("Error al eliminar entrada del diario:", error)
    return NextResponse.json({ error: "Error al eliminar entrada del diario" }, { status: 500 })
  }
}

