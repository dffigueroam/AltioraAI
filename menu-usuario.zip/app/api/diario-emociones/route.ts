import { NextResponse } from "next/server"
import { db } from "@/lib/db/index-completo"
import type { EntradaDiario } from "@/lib/db/schema-completo"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const estudianteId = searchParams.get("estudianteId")
    const sentimiento = searchParams.get("sentimiento") as "positivo" | "neutral" | "negativo" | null
    const fechaInicio = searchParams.get("fechaInicio")
    const fechaFin = searchParams.get("fechaFin")

    let entradas: EntradaDiario[] = []

    if (estudianteId && sentimiento) {
      entradas = await db.getDiarioEmocionesBySentimiento(estudianteId, sentimiento)
    } else if (estudianteId && fechaInicio && fechaFin) {
      entradas = await db.getDiarioEmocionesByFecha(estudianteId, fechaInicio, fechaFin)
    } else if (estudianteId) {
      entradas = await db.getDiarioEmocionesByEstudiante(estudianteId)
    } else {
      entradas = await db.readAll("diarioEmociones")
    }

    return NextResponse.json(entradas)
  } catch (error) {
    console.error("Error al obtener entradas del diario:", error)
    return NextResponse.json({ error: "Error al obtener entradas del diario" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validamos los campos requeridos
    if (!data.estudianteId || !data.titulo || !data.contenido || !data.sentimiento) {
      return NextResponse.json(
        { error: "Faltan campos requeridos: estudianteId, titulo, contenido, sentimiento" },
        { status: 400 },
      )
    }

    // Generamos un ID único
    const id = crypto.randomUUID()

    // Completamos los campos faltantes
    const fechaActual = new Date()
    const entrada: EntradaDiario = {
      id,
      estudianteId: data.estudianteId,
      titulo: data.titulo,
      contenido: data.contenido,
      sentimiento: data.sentimiento,
      intensidad: data.intensidad || 3, // Valor por defecto
      fecha: data.fecha || fechaActual.toISOString().split("T")[0],
      hora: data.hora || fechaActual.toTimeString().split(" ")[0].substring(0, 5),
      etiquetas: data.etiquetas || [],
      situacion: data.situacion,
      pensamientos: data.pensamientos,
    }

    // Guardamos la entrada
    await db.create("diarioEmociones", id, entrada)

    return NextResponse.json(entrada, { status: 201 })
  } catch (error) {
    console.error("Error al crear entrada del diario:", error)
    return NextResponse.json({ error: "Error al crear entrada del diario" }, { status: 500 })
  }
}

