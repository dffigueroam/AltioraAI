import { NextResponse } from "next/server"
import { eventosDB } from "@/lib/db/eventos"
import type { UpdateEventoInput } from "@/types/evento"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const evento = await eventosDB.getById(params.id)
    if (!evento) {
      return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 })
    }
    return NextResponse.json(evento)
  } catch (error) {
    console.error("Error al obtener evento:", error)
    return NextResponse.json({ error: "Error al obtener evento" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const input: UpdateEventoInput = await request.json()
    const evento = await eventosDB.update(params.id, input)
    if (!evento) {
      return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 })
    }
    return NextResponse.json(evento)
  } catch (error) {
    console.error("Error al actualizar evento:", error)
    return NextResponse.json({ error: "Error al actualizar evento" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const success = await eventosDB.delete(params.id)
    if (!success) {
      return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 })
    }
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error al eliminar evento:", error)
    return NextResponse.json({ error: "Error al eliminar evento" }, { status: 500 })
  }
}

