import { NextResponse } from "next/server"
import { eventosDB } from "@/lib/db/eventos"
import type { CreateEventoInput } from "@/types/evento"

export async function GET() {
  try {
    const eventos = await eventosDB.getAll()
    return NextResponse.json(eventos)
  } catch (error) {
    console.error("Error al obtener eventos:", error)
    return NextResponse.json({ error: "Error al obtener eventos" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const input: CreateEventoInput = await request.json()
    const evento = await eventosDB.create(input)
    return NextResponse.json(evento, { status: 201 })
  } catch (error) {
    console.error("Error al crear evento:", error)
    return NextResponse.json({ error: "Error al crear evento" }, { status: 500 })
  }
}

