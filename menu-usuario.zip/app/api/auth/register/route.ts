import { type NextRequest, NextResponse } from "next/server"

// Simulación de almacenamiento en memoria
const users = new Map()

export async function POST(req: NextRequest) {
  try {
    const data = await req.json()
    const { email, password, role, profile } = data

    // Verificar si el usuario ya existe
    if (users.has(email)) {
      return NextResponse.json({ error: "El correo electrónico ya está registrado" }, { status: 400 })
    }

    // Guardar usuario en memoria (sin hash de contraseña en desarrollo)
    const user = {
      id: Date.now().toString(),
      email,
      password, // En desarrollo guardamos la contraseña sin hash
      role,
      profile,
    }
    users.set(email, user)

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        profile: user.profile,
      },
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 })
  }
}

