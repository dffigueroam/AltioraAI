import { NextResponse } from "next/server"
import { cookies } from "next/headers"

// Simulación de autenticación
const mockUsers = [
  {
    email: "profesor@altiora.edu",
    password: "profesor123",
    role: "profesor",
    id: "1",
  },
  {
    email: "estudiante@altiora.edu",
    password: "estudiante123",
    role: "estudiante",
    id: "2",
  },
]

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    // Simulación de verificación
    const user = mockUsers.find((u) => u.email === email && u.password === password)
    if (!user) {
      return NextResponse.json({ error: "Credenciales inválidas" }, { status: 401 })
    }

    // Token simple para desarrollo
    const mockToken = `dev-token-${Date.now()}`

    // Configurar cookie
    cookies().set("token", mockToken, {
      httpOnly: true,
      secure: false, // En desarrollo no necesitamos HTTPS
      sameSite: "lax",
      maxAge: 60 * 60 * 24, // 24 horas
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 })
  }
}

