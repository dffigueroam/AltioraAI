import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")

    let questionnaires
    if (type) {
      questionnaires = await db.query("questionnaires", (questionnaire) => questionnaire.type === type)
    } else {
      questionnaires = await db.readAll("questionnaires")
    }

    return NextResponse.json(questionnaires)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch questionnaires" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const id = crypto.randomUUID()
    const questionnaire = await db.create("questionnaires", id, { id, ...data })
    return NextResponse.json(questionnaire)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create questionnaire" }, { status: 500 })
  }
}

