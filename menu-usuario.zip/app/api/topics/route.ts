import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const subject = searchParams.get("subject")

    let topics
    if (subject) {
      topics = await db.query("topics", (topic) => topic.subject === subject)
    } else {
      topics = await db.readAll("topics")
    }

    return NextResponse.json(topics)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch topics" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const id = crypto.randomUUID()
    const topic = await db.create("topics", id, { id, ...data })
    return NextResponse.json(topic)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create topic" }, { status: 500 })
  }
}

