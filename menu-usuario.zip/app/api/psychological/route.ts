import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const studentId = searchParams.get("studentId")
    const classroomId = searchParams.get("classroomId")

    let records
    if (studentId) {
      records = await db.query("psychological", (record) => record.studentId === studentId)
    } else if (classroomId) {
      records = await db.query("psychological", (record) => record.classroomId === classroomId)
    } else {
      records = await db.readAll("psychological")
    }

    return NextResponse.json(records)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch psychological records" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const id = crypto.randomUUID()
    const record = await db.create("psychological", id, { id, ...data })
    return NextResponse.json(record)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create psychological record" }, { status: 500 })
  }
}

