"use client"

import { CardFooter } from "@/components/ui/card"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Heart, Save, Plus } from "lucide-react"

export default function DiarioEmocionesPage() {
  const [entries, setEntries] = useState([
    {
      id: 1,
      date: "2023-11-15",
      emotion: "feliz",
      description: "Hoy me fue muy bien en mi examen de matemáticas. Estudié mucho y valió la pena.",
    },
    {
      id: 2,
      date: "2023-11-14",
      emotion: "triste",
      description: "Me sentí un poco solo durante el almuerzo. Extraño a mis amigos que cambiaron de escuela.",
    },
  ])

  const [newEntry, setNewEntry] = useState({
    emotion: "",
    description: "",
  })

  const handleSave = () => {
    if (newEntry.emotion && newEntry.description) {
      const today = new Date().toISOString().split("T")[0]
      setEntries([
        ...entries,
        {
          id: entries.length + 1,
          date: today,
          emotion: newEntry.emotion,
          description: newEntry.description,
        },
      ])
      setNewEntry({ emotion: "", description: "" })
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center mb-6">
        <Heart className="h-6 w-6 text-pink-500 mr-2" />
        <h1 className="text-3xl font-bold">Diario de Emociones</h1>
        <p>Aquí podrás registrar cómo te sientes cada día y reflexionar sobre tus emociones.</p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>¿Cómo te sientes hoy?</CardTitle>
          <CardDescription>Registra tus emociones y experiencias del día</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="emotion">Emoción</Label>
              <Select value={newEntry.emotion} onValueChange={(value) => setNewEntry({ ...newEntry, emotion: value })}>
                <SelectTrigger id="emotion">
                  <SelectValue placeholder="Selecciona una emoción" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="feliz">Feliz</SelectItem>
                  <SelectItem value="triste">Triste</SelectItem>
                  <SelectItem value="enojado">Enojado</SelectItem>
                  <SelectItem value="ansioso">Ansioso</SelectItem>
                  <SelectItem value="tranquilo">Tranquilo</SelectItem>
                  <SelectItem value="confundido">Confundido</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">¿Qué te hizo sentir así?</Label>
              <Textarea
                id="description"
                placeholder="Describe tu experiencia..."
                value={newEntry.description}
                onChange={(e) => setNewEntry({ ...newEntry, description: e.target.value })}
                rows={4}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSave} className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Guardar entrada
          </Button>
        </CardFooter>
      </Card>

      <h2 className="text-xl font-semibold mb-4">Entradas recientes</h2>

      <div className="grid gap-4 md:grid-cols-2">
        {entries.map((entry) => (
          <Card key={entry.id}>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg capitalize">{entry.emotion}</CardTitle>
                <span className="text-sm text-muted-foreground">{entry.date}</span>
              </div>
            </CardHeader>
            <CardContent>
              <p>{entry.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Button className="fixed bottom-6 right-6 rounded-full h-14 w-14 shadow-lg" size="icon">
        <Plus className="h-6 w-6" />
      </Button>
    </div>
  )
}

