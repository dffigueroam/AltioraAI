import type React from "react"
import { StudentNavigation } from "@/components/student/student-navigation"
import { MobileNavigation } from "@/components/student/mobile-navigation"

export default function StudentLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex flex-1">
        <div className="hidden border-r md:block">
          <StudentNavigation className="w-64" />
        </div>
        <main className="flex-1">{children}</main>
      </div>
      <MobileNavigation className="md:hidden" />
    </div>
  )
}

