import { RegistrationForm } from "@/components/registration-form"

export default function RegistroPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center text-[#1E40AF] mb-8">Registro en ALTIORA AI</h1>
        <RegistrationForm />
      </div>
    </div>
  )
}

