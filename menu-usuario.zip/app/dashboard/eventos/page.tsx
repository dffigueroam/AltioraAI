export default function EventosPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Eventos</h1>
      <p>Contenido de Eventos</p>
    </div>
  )
}

