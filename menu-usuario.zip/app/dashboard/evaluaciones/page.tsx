"use client"

import { useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { QuestionnaireCard } from "@/components/questionnaire-card"
import { questionnaires } from "@/lib/questionnaires"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle2, ArrowLeft } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function EvaluacionesPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const completed = searchParams.get("completed")
  const testId = searchParams.get("test")

  useEffect(() => {
    if (testId) {
      router.push(`/dashboard/evaluaciones/${testId}`)
    }
  }, [testId, router])

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" className="text-[#1E40AF]" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-[#1E40AF]">Evaluaciones Psicológicas</h1>
        </div>
      </div>

      {completed && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertTitle className="text-green-800">Evaluación Completada</AlertTitle>
          <AlertDescription className="text-green-700">
            Gracias por completar la evaluación. Tus respuestas han sido registradas.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Evaluaciones Pendientes</CardTitle>
            <CardDescription>
              Estos cuestionarios requieren tu atención. Completa las evaluaciones pendientes para ayudarnos a brindarte
              un mejor apoyo.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.values(questionnaires)
                .filter((q) => q.required)
                .map((questionnaire) => (
                  <QuestionnaireCard
                    key={questionnaire.id}
                    questionnaire={questionnaire}
                    onStart={() => router.push(`/dashboard/evaluaciones/${questionnaire.type}-1`)}
                  />
                ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Evaluaciones Opcionales</CardTitle>
            <CardDescription>
              Estos cuestionarios están disponibles para que los completes cuando lo desees.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.values(questionnaires)
                .filter((q) => !q.required)
                .map((questionnaire) => (
                  <QuestionnaireCard
                    key={questionnaire.id}
                    questionnaire={questionnaire}
                    onStart={() => router.push(`/dashboard/evaluaciones/${questionnaire.type}-1`)}
                  />
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

