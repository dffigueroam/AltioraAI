"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { QuestionnaireForm } from "@/components/questionnaire-form"
import { questionnaires } from "@/lib/questionnaires"
import type { Questionnaire } from "@/types/questionnaire"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface TestPageProps {
  params: {
    testId: string
  }
}

export default function TestPage({ params }: TestPageProps) {
  const router = useRouter()
  const [questionnaire, setQuestionnaire] = useState<Questionnaire | null>(null)

  useEffect(() => {
    // En una implementación real, esto sería una llamada a la API
    const testType = params.testId.split("-")[0]
    const foundQuestionnaire = Object.values(questionnaires).find((q) => q.type === testType)
    if (foundQuestionnaire) {
      setQuestionnaire(foundQuestionnaire)
    }
  }, [params.testId])

  if (!questionnaire) {
    return (
      <div className="container mx-auto py-6">
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-gray-500">Cuestionario no encontrado</p>
            <Button asChild className="mt-4">
              <Link href="/dashboard/evaluaciones">Volver a Evaluaciones</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const handleSubmit = async (response: any) => {
    // Aquí iría la lógica para guardar las respuestas
    console.log("Respuestas:", response)
    router.push("/dashboard/evaluaciones?completed=true")
  }

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <Button variant="ghost" className="text-[#1E40AF]" asChild>
          <Link href="/dashboard/evaluaciones">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Evaluaciones
          </Link>
        </Button>
      </div>

      <QuestionnaireForm
        questionnaire={questionnaire}
        onSubmit={handleSubmit}
        onCancel={() => router.push("/dashboard/evaluaciones")}
      />
    </div>
  )
}

