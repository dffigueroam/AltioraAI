"use client"
import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"

export default function SugerenciasEmocionales() {
  const pathname = usePathname()

  // Datos de ejemplo para las sugerencias
  const sugerencias = [
    {
      id: 1,
      titulo: "Técnicas de respiración para la ansiedad",
      descripcion:
        "Aprende técnicas de respiración que te ayudarán a manejar momentos de ansiedad antes de exámenes o presentaciones.",
      categoria: "Manejo del estrés",
      emociones: ["Ansiedad", "Miedo", "Nerviosismo"],
    },
    {
      id: 2,
      titulo: "Diario de gratitud",
      descripcion:
        "Escribir tres cosas por las que estás agradecido cada día puede aumentar tus emociones positivas y mejorar tu bienestar general.",
      categoria: "Bienestar emocional",
      emociones: ["Tristeza", "Apatía"],
    },
    {
      id: 3,
      titulo: "Actividad física para mejorar el ánimo",
      descripcion:
        "El ejercicio regular libera endorfinas que mejoran tu estado de ánimo. Incluso 15 minutos de actividad pueden marcar la diferencia.",
      categoria: "Salud física y mental",
      emociones: ["Tristeza", "Apatía", "Cansancio"],
    },
    {
      id: 4,
      titulo: "Técnicas de comunicación asertiva",
      descripcion:
        "Aprende a expresar tus sentimientos y necesidades de manera clara y respetuosa para mejorar tus relaciones interpersonales.",
      categoria: "Habilidades sociales",
      emociones: ["Enojo", "Frustración"],
    },
    {
      id: 5,
      titulo: "Mindfulness para principiantes",
      descripcion:
        "La práctica de la atención plena puede ayudarte a estar más presente y reducir pensamientos negativos recurrentes.",
      categoria: "Meditación y mindfulness",
      emociones: ["Ansiedad", "Preocupación", "Confusión"],
    },
    {
      id: 6,
      titulo: "Establecimiento de metas realistas",
      descripcion:
        "Aprende a establecer metas alcanzables y dividirlas en pasos pequeños para evitar la frustración y aumentar la motivación.",
      categoria: "Desarrollo personal",
      emociones: ["Frustración", "Desmotivación"],
    },
  ]

  // Estado para filtros
  const [filtroCategoria, setFiltroCategoria] = useState("Todas")

  // Lista de categorías únicas
  const categorias = ["Todas", ...Array.from(new Set(sugerencias.map((s) => s.categoria)))]

  // Filtrar sugerencias según la categoría seleccionada
  const sugerenciasFiltradas =
    filtroCategoria === "Todas" ? sugerencias : sugerencias.filter((s) => s.categoria === filtroCategoria)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cabecera */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Sugerencias Personalizadas</h1>
              <p className="text-gray-600 mt-1">Recomendaciones basadas en tu historial emocional</p>
            </div>
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className="text-blue-600 hover:text-blue-800 flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z"
                  clipRule="evenodd"
                />
              </svg>
              Volver al Diario
            </Link>
          </div>
        </div>
      </header>

      {/* Navegación entre secciones */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-8">
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Resumen
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/registro"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/registro"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Registrar Emoción
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/historial"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/historial"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Mi Historial
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/sugerencias"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/sugerencias"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Sugerencias
            </Link>
          </nav>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="container mx-auto px-4 py-8">
        {/* Filtros */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Filtrar por categoría</h2>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {categorias.map((categoria) => (
              <button
                key={categoria}
                onClick={() => setFiltroCategoria(categoria)}
                className={`px-3 py-1 rounded-full text-sm ${
                  filtroCategoria === categoria
                    ? "bg-blue-100 text-blue-800 font-medium"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {categoria}
              </button>
            ))}
          </div>
        </div>

        {/* Sugerencias */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sugerenciasFiltradas.map((sugerencia) => (
            <div key={sugerencia.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6">
                <h3 className="font-semibold text-lg mb-2">{sugerencia.titulo}</h3>
                <p className="text-gray-600 text-sm mb-4">{sugerencia.descripcion}</p>

                <div className="mt-4">
                  <span className="text-xs text-gray-500 block mb-1">Categoría:</span>
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    {sugerencia.categoria}
                  </span>
                </div>

                <div className="mt-2">
                  <span className="text-xs text-gray-500 block mb-1">Útil para:</span>
                  <div className="flex flex-wrap gap-1">
                    {sugerencia.emociones.map((emocion, index) => (
                      <span key={index} className="bg-gray-100 text-gray-800 text-xs px-2 py-0.5 rounded">
                        {emocion}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 px-6 py-3">
                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">Leer más →</button>
              </div>
            </div>
          ))}
        </div>

        {sugerenciasFiltradas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No hay sugerencias disponibles para esta categoría.</p>
          </div>
        )}
      </main>
    </div>
  )
}

