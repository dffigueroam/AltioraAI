"use client"
import { useState } from "react"
import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function RegistrarEmocion() {
  const pathname = usePathname()

  // Estado para el registro de una nueva emoción
  const [nuevaEmocion, setNuevaEmocion] = useState({
    emocion: "",
    intensidad: 5,
    notas: "",
    factores: [] as string[],
  })

  // Lista de emociones disponibles
  const emociones = [
    "Alegría",
    "Tristeza",
    "Enojo",
    "Miedo",
    "Sorpresa",
    "Disgusto",
    "Calma",
    "Ansiedad",
    "Entusiasmo",
    "Confusión",
  ]

  // Lista de factores que pueden influir en las emociones
  const factores = [
    "Escuela",
    "Familia",
    "Amigos",
    "Salud",
    "Descanso",
    "Actividades extracurriculares",
    "Redes sociales",
    "Noticias",
  ]

  // Manejar cambios en el formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setNuevaEmocion((prev) => ({
      ...prev,
      [name]: name === "intensidad" ? Number.parseInt(value) : value,
    }))
  }

  // Manejar cambios en los factores (checkboxes)
  const handleFactorChange = (factor: string) => {
    setNuevaEmocion((prev) => {
      const factoresActualizados = prev.factores.includes(factor)
        ? prev.factores.filter((f) => f !== factor)
        : [...prev.factores, factor]

      return {
        ...prev,
        factores: factoresActualizados,
      }
    })
  }

  // Manejar envío del formulario
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert(`Emoción registrada: ${nuevaEmocion.emocion} con intensidad ${nuevaEmocion.intensidad}`)
    // Aquí iría la lógica para guardar en la base de datos
    setNuevaEmocion({
      emocion: "",
      intensidad: 5,
      notas: "",
      factores: [],
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cabecera */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Registrar Emoción</h1>
              <p className="text-gray-600 mt-1">Registra cómo te sientes hoy</p>
            </div>
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className="text-blue-600 hover:text-blue-800 flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z"
                  clipRule="evenodd"
                />
              </svg>
              Volver al Diario
            </Link>
          </div>
        </div>
      </header>

      {/* Navegación entre secciones */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-8">
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Resumen
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/registro"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/registro"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Registrar Emoción
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/historial"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/historial"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Mi Historial
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/sugerencias"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/sugerencias"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Sugerencias
            </Link>
          </nav>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-6">¿Cómo te sientes hoy?</h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="emocion" className="block text-sm font-medium text-gray-700 mb-1">
                  Selecciona tu emoción principal
                </label>
                <select
                  id="emocion"
                  name="emocion"
                  value={nuevaEmocion.emocion}
                  onChange={handleChange}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                >
                  <option value="">Selecciona una emoción</option>
                  {emociones.map((emocion) => (
                    <option key={emocion} value={emocion}>
                      {emocion}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="intensidad" className="block text-sm font-medium text-gray-700 mb-1">
                  Intensidad: {nuevaEmocion.intensidad}
                </label>
                <input
                  type="range"
                  id="intensidad"
                  name="intensidad"
                  min="1"
                  max="10"
                  value={nuevaEmocion.intensidad}
                  onChange={handleChange}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Baja</span>
                  <span>Alta</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ¿Qué factores influyeron en tu emoción? (opcional)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {factores.map((factor) => (
                    <div key={factor} className="flex items-center">
                      <input
                        type="checkbox"
                        id={`factor-${factor}`}
                        checked={nuevaEmocion.factores.includes(factor)}
                        onChange={() => handleFactorChange(factor)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      />
                      <label htmlFor={`factor-${factor}`} className="ml-2 text-sm text-gray-700">
                        {factor}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label htmlFor="notas" className="block text-sm font-medium text-gray-700 mb-1">
                  Notas o reflexiones (opcional)
                </label>
                <textarea
                  id="notas"
                  name="notas"
                  rows={4}
                  value={nuevaEmocion.notas}
                  onChange={handleChange}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="¿Qué te hizo sentir así? ¿Cómo afectó tu día?"
                ></textarea>
              </div>

              <div className="flex justify-end space-x-3">
                <Link
                  href="/dashboard/estudiante/diario-emociones"
                  className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </Link>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Guardar en mi Diario
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  )
}

