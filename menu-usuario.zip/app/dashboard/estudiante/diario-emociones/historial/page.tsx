"use client"
import { useState } from "react"
import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function HistorialEmociones() {
  const pathname = usePathname()

  // Estado para filtros
  const [filtros, setFiltros] = useState({
    emocion: "",
    intensidadMin: 1,
    intensidadMax: 10,
    fechaInicio: "",
    fechaFin: "",
  })

  // Datos de ejemplo para el historial
  const historialEmociones = [
    {
      id: 1,
      fecha: "15/03/2025",
      emocion: "Alegría",
      intensidad: 8,
      notas: "Obtuve una buena calificación en el examen de matemáticas",
      factores: ["Escuela"],
    },
    {
      id: 2,
      fecha: "14/03/2025",
      emocion: "Ansiedad",
      intensidad: 6,
      notas: "Preocupado por el examen de mañana",
      factores: ["Escuela", "Descanso"],
    },
    {
      id: 3,
      fecha: "12/03/2025",
      emocion: "Calma",
      intensidad: 7,
      notas: "Día tranquilo, pude completar todas mis tareas",
      factores: ["Escuela", "Familia"],
    },
    {
      id: 4,
      fecha: "10/03/2025",
      emocion: "Entusiasmo",
      intensidad: 9,
      notas: "Emocionado por el proyecto de ciencias",
      factores: ["Escuela", "Amigos"],
    },
    {
      id: 5,
      fecha: "08/03/2025",
      emocion: "Tristeza",
      intensidad: 5,
      notas: "Me sentí un poco solo hoy",
      factores: ["Amigos"],
    },
    {
      id: 6,
      fecha: "05/03/2025",
      emocion: "Alegría",
      intensidad: 7,
      notas: "Pasé tiempo con mi familia",
      factores: ["Familia"],
    },
    {
      id: 7,
      fecha: "03/03/2025",
      emocion: "Confusión",
      intensidad: 6,
      notas: "No entendí bien el tema nuevo de física",
      factores: ["Escuela"],
    },
    {
      id: 8,
      fecha: "01/03/2025",
      emocion: "Enojo",
      intensidad: 4,
      notas: "Tuve una discusión con un amigo",
      factores: ["Amigos"],
    },
  ]

  // Lista de emociones disponibles
  const emociones = [
    "Todas",
    "Alegría",
    "Tristeza",
    "Enojo",
    "Miedo",
    "Sorpresa",
    "Disgusto",
    "Calma",
    "Ansiedad",
    "Entusiasmo",
    "Confusión",
  ]

  // Manejar cambios en los filtros
  const handleFiltroChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFiltros((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Filtrar el historial según los criterios
  const historialFiltrado = historialEmociones.filter((item) => {
    // Filtro por emoción
    if (filtros.emocion && filtros.emocion !== "Todas" && item.emocion !== filtros.emocion) {
      return false
    }

    // Filtro por intensidad
    if (item.intensidad < filtros.intensidadMin || item.intensidad > filtros.intensidadMax) {
      return false
    }

    // Aquí se podrían agregar más filtros por fecha si se implementa la lógica

    return true
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Cabecera */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Mi Historial Emocional</h1>
              <p className="text-gray-600 mt-1">Revisa y analiza tus emociones registradas</p>
            </div>
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className="text-blue-600 hover:text-blue-800 flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z"
                  clipRule="evenodd"
                />
              </svg>
              Volver al Diario
            </Link>
          </div>
        </div>
      </header>

      {/* Navegación entre secciones */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4">
          <nav className="flex space-x-8">
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Resumen
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/registro"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/registro"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Registrar Emoción
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/historial"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/historial"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Mi Historial
            </Link>
            <Link
              href="/dashboard/estudiante/diario-emociones/sugerencias"
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                pathname === "/dashboard/estudiante/diario-emociones/sugerencias"
                  ? "border-blue-500 text-blue-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Sugerencias
            </Link>
          </nav>
        </div>
      </div>

      {/* Contenido principal */}
      <main className="container mx-auto px-4 py-8">
        {/* Filtros */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Filtros</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="emocion" className="block text-sm font-medium text-gray-700 mb-1">
                Emoción
              </label>
              <select
                id="emocion"
                name="emocion"
                value={filtros.emocion}
                onChange={handleFiltroChange}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                {emociones.map((emocion) => (
                  <option key={emocion} value={emocion}>
                    {emocion}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="intensidadMin" className="block text-sm font-medium text-gray-700 mb-1">
                Intensidad mínima: {filtros.intensidadMin}
              </label>
              <input
                type="range"
                id="intensidadMin"
                name="intensidadMin"
                min="1"
                max="10"
                value={filtros.intensidadMin}
                onChange={handleFiltroChange}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            <div>
              <label htmlFor="intensidadMax" className="block text-sm font-medium text-gray-700 mb-1">
                Intensidad máxima: {filtros.intensidadMax}
              </label>
              <input
                type="range"
                id="intensidadMax"
                name="intensidadMax"
                min="1"
                max="10"
                value={filtros.intensidadMax}
                onChange={handleFiltroChange}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Historial */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Historial de Emociones</h2>
            <span className="text-sm text-gray-500">{historialFiltrado.length} registros</span>
          </div>

          {historialFiltrado.length > 0 ? (
            <div className="space-y-4">
              {historialFiltrado.map((item) => (
                <div key={item.id} className="border rounded-md p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-sm text-gray-500">{item.fecha}</span>
                      <h3 className="font-medium">{item.emocion}</h3>
                    </div>
                    <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                      Intensidad: {item.intensidad}/10
                    </span>
                  </div>

                  {item.notas && <p className="text-gray-600 text-sm mt-2">{item.notas}</p>}

                  {item.factores && item.factores.length > 0 && (
                    <div className="mt-2">
                      <span className="text-xs text-gray-500">Factores:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {item.factores.map((factor, index) => (
                          <span key={index} className="bg-gray-100 text-gray-800 text-xs px-2 py-0.5 rounded">
                            {factor}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 italic text-center py-8">
              No se encontraron registros con los filtros seleccionados.
            </p>
          )}
        </div>
      </main>
    </div>
  )
}

