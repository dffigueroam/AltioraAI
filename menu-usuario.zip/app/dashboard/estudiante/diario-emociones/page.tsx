"use client"
import Link from "next/link"
import type React from "react"

import { useState } from "react"

export default function DiarioEmociones() {
  const [emocion, setEmocion] = useState("")
  const [intensidad, setIntensidad] = useState(3)
  const [notas, setNotas] = useState("")
  const [registroExitoso, setRegistroExitoso] = useState(false)

  // Datos de ejemplo para el historial
  const historialEmociones = [
    { fecha: "2025-03-01", emocion: "Felicidad", intensidad: 4, notas: "Día muy productivo" },
    { fecha: "2025-03-02", emocion: "Ansiedad", intensidad: 3, notas: "Preocupado por el examen" },
    { fecha: "2025-03-03", emocion: "Calma", intensidad: 5, notas: "Sesión de meditación efectiva" },
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Aquí iría la lógica para guardar el registro en la base de datos
    console.log({ emocion, intensidad, notas, fecha: new Date().toISOString().split("T")[0] })

    // Mostrar mensaje de éxito
    setRegistroExitoso(true)
    setTimeout(() => setRegistroExitoso(false), 3000)

    // Limpiar el formulario
    setEmocion("")
    setIntensidad(3)
    setNotas("")
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-10">
      {/* Encabezado */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-bold text-gray-900 flex items-center">
              <span className="mr-2">📓</span> Diario De Emociones
            </h1>
            <Link href="/dashboard/estudiante" className="text-blue-600 hover:text-blue-800">
              Volver al Dashboard
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Mensaje de registro exitoso */}
        {registroExitoso && (
          <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
            ¡Emoción registrada con éxito!
          </div>
        )}

        {/* Secciones principales */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sección de registro rápido */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Registrar emoción de hoy</h2>
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label className="block text-gray-700 mb-2">¿Cómo te sientes hoy?</label>
                  <select
                    value={emocion}
                    onChange={(e) => setEmocion(e.target.value)}
                    className="w-full p-2 border rounded-md"
                    required
                  >
                    <option value="">Selecciona una emoción</option>
                    <option value="Alegría">Alegría</option>
                    <option value="Tristeza">Tristeza</option>
                    <option value="Enojo">Enojo</option>
                    <option value="Miedo">Miedo</option>
                    <option value="Sorpresa">Sorpresa</option>
                    <option value="Asco">Asco</option>
                    <option value="Ansiedad">Ansiedad</option>
                    <option value="Calma">Calma</option>
                    <option value="Entusiasmo">Entusiasmo</option>
                    <option value="Gratitud">Gratitud</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2">Intensidad: {intensidad}</label>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={intensidad}
                    onChange={(e) => setIntensidad(Number.parseInt(e.target.value))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Muy baja</span>
                    <span>Baja</span>
                    <span>Media</span>
                    <span>Alta</span>
                    <span>Muy alta</span>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 mb-2">Notas (opcional)</label>
                  <textarea
                    value={notas}
                    onChange={(e) => setNotas(e.target.value)}
                    className="w-full p-2 border rounded-md"
                    rows={3}
                    placeholder="¿Qué te hizo sentir así? ¿Qué pensamientos tuviste?"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                >
                  Guardar registro
                </button>
              </form>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
              <h2 className="text-lg font-semibold mb-4">Navegación</h2>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/dashboard/estudiante/diario-emociones/registro"
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    <span className="mr-2">➕</span> Registro detallado
                  </Link>
                </li>
                <li>
                  <Link
                    href="/dashboard/estudiante/diario-emociones/historial"
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    <span className="mr-2">📊</span> Ver mi historial completo
                  </Link>
                </li>
                <li>
                  <Link
                    href="/dashboard/estudiante/diario-emociones/sugerencias"
                    className="text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    <span className="mr-2">💡</span> Sugerencias personalizadas
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* Sección de historial reciente y estadísticas */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">Tus emociones recientes</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fecha
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Emoción
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Intensidad
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Notas
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {historialEmociones.map((item, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.fecha}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.emocion}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {Array(item.intensidad).fill("★").join("")}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500 truncate max-w-xs">{item.notas}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 text-right">
                <Link
                  href="/dashboard/estudiante/diario-emociones/historial"
                  className="text-blue-600 hover:text-blue-800"
                >
                  Ver historial completo →
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Estadísticas del mes</h2>
              <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                <p className="text-gray-500">Gráfico de emociones del mes (simulado)</p>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-medium text-blue-800">Emoción más frecuente</h3>
                  <p className="text-2xl font-bold text-blue-900">Calma</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h3 className="font-medium text-purple-800">Intensidad promedio</h3>
                  <p className="text-2xl font-bold text-purple-900">3.5 / 5</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

