"use client"
import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"

export default function DashboardEstudiante() {
  const pathname = usePathname()
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null)

  // Datos de ejemplo para las métricas
  const metricas = [
    { titulo: "Promedio", valor: "8.7", icono: "📊" },
    { titulo: "Asistencia", valor: "95%", icono: "📅" },
    { titulo: "Tareas Completadas", valor: "24/30", icono: "✅" },
    { titulo: "Proyectos Pendientes", valor: "2", icono: "📝" },
  ]

  // Estructura jerárquica de menús y submenús
  const menuItems = [
    {
      href: "/dashboard/estudiante/acciones-pendientes",
      label: "Acciones Pendientes",
      subItems: [
        { href: "/dashboard/estudiante/acciones-pendientes/tareas", label: "Tareas" },
        { href: "/dashboard/estudiante/acciones-pendientes/examenes", label: "Exámenes" },
        { href: "/dashboard/estudiante/acciones-pendientes/proyectos", label: "Proyectos" },
      ],
    },
    {
      href: "/dashboard/estudiante/diario-emociones",
      label: "📓 Diario De Emociones",
      highlighted: true,
      subItems: [
        { href: "/dashboard/estudiante/diario-emociones/registro", label: "Registrar Emoción" },
        { href: "/dashboard/estudiante/diario-emociones/historial", label: "Mi Historial" },
        { href: "/dashboard/estudiante/diario-emociones/sugerencias", label: "Sugerencias" },
      ],
    },
    {
      href: "/dashboard/estudiante/eventos",
      label: "Eventos",
      subItems: [],
    },
    {
      href: "/dashboard/estudiante/enlaces-interes",
      label: "Enlaces de Interés",
      subItems: [],
    },
    {
      href: "/dashboard/estudiante/deportes",
      label: "Deportes",
      subItems: [],
    },
    {
      href: "/dashboard/estudiante/gestion-ia",
      label: "Gestión sugerida de la IA",
      subItems: [],
    },
  ]

  // Función para manejar el clic en un menú
  const handleMenuClick = (href: string) => {
    if (expandedMenu === href) {
      setExpandedMenu(null) // Cierra el submenú si ya está abierto
    } else {
      setExpandedMenu(href) // Abre el submenú
    }
  }

  // Verifica si un menú está activo
  const isMenuActive = (href: string) => {
    return pathname === href || pathname.startsWith(`${href}/`)
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        {/* Barra de navegación principal */}
        <nav className="bg-white border-b">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center h-16">
              <div className="flex space-x-8">
                <Link
                  href="/dashboard/estudiante"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    pathname === "/dashboard/estudiante"
                      ? "border-blue-500 text-gray-900"
                      : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  }`}
                >
                  Inicio
                </Link>
                <Link
                  href="/dashboard/estudiante/tareas"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    pathname === "/dashboard/estudiante/tareas"
                      ? "border-blue-500 text-gray-900"
                      : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  }`}
                >
                  Tareas
                </Link>
                <Link
                  href="/dashboard/estudiante/eventos"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    pathname === "/dashboard/estudiante/eventos"
                      ? "border-blue-500 text-gray-900"
                      : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  }`}
                >
                  Eventos
                </Link>
                <Link
                  href="/dashboard/estudiante/recursos"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    pathname === "/dashboard/estudiante/recursos"
                      ? "border-blue-500 text-gray-900"
                      : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  }`}
                >
                  Recursos
                </Link>
                <Link
                  href="/dashboard/estudiante/diario-emociones"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    pathname === "/dashboard/estudiante/diario-emociones" ||
                    pathname.startsWith("/dashboard/estudiante/diario-emociones/")
                      ? "border-blue-500 text-gray-900"
                      : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                  }`}
                >
                  <span className="mr-1">📓</span> Diario De Emociones
                </Link>
              </div>
            </div>
          </div>
        </nav>

        {/* Contenido del dashboard */}
        <main className="container mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold mb-2">Dashboard de Estudiante</h1>

          {/* Banner destacado para Diario de Emociones */}
          <div className="bg-blue-100 border-l-4 border-blue-500 p-4 mb-6 rounded-lg shadow-sm flex items-center justify-between">
            <div>
              <h2 className="text-blue-800 font-semibold text-lg flex items-center">
                <span className="mr-2">📓</span> Acceso directo a tu Diario de Emociones
              </h2>
              <p className="text-blue-700 mt-1">Registra cómo te sientes hoy y consulta tu historial emocional</p>
            </div>
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg shadow transition-colors duration-200 flex items-center"
            >
              Abrir mi Diario <span className="ml-2">→</span>
            </Link>
          </div>

          {/* Menú de navegación simplificado */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <h2 className="text-lg font-semibold mb-4">Navegación</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {menuItems.map((item) => (
                <div key={item.href} className="border rounded-lg p-4">
                  <h3 className="font-medium text-lg mb-2">
                    <Link
                      href={item.href}
                      className={`${item.highlighted ? "text-blue-600" : "text-gray-700"} hover:underline`}
                    >
                      {item.label}
                    </Link>
                  </h3>

                  {item.subItems.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {item.subItems.map((subItem) => (
                        <li key={subItem.href}>
                          <Link
                            href={subItem.href}
                            className={`text-sm ${
                              pathname === subItem.href
                                ? "text-blue-600 font-medium"
                                : "text-gray-600 hover:text-gray-900"
                            }`}
                          >
                            • {subItem.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Tarjetas de métricas */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {metricas.map((metrica, index) => (
              <div key={index} className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex flex-col items-center">
                  <span className="text-2xl mb-2">{metrica.icono}</span>
                  <h3 className="font-medium text-gray-500">{metrica.titulo}</h3>
                  <p className="text-xl font-bold text-gray-900">{metrica.valor}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Sección Diario de Emociones */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg shadow-sm p-6 mb-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold mb-2 text-blue-700">Diario De Emociones</h2>
                <p className="text-gray-600 mb-4">
                  Registra cómo te sientes hoy y lleva un seguimiento de tus emociones
                </p>
              </div>
              <div className="text-4xl">📓</div>
            </div>
            <Link
              href="/dashboard/estudiante/diario-emociones"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md transition-colors"
            >
              Acceder a mi Diario
            </Link>
          </div>

          {/* Próximas Actividades */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">Próximas Actividades</h2>
            <ul className="space-y-3">
              <li className="p-3 bg-gray-50 rounded-md">Entrega de Proyecto de Ciencias - 15/03/2025</li>
              <li className="p-3 bg-gray-50 rounded-md">Examen de Matemáticas - 20/03/2025</li>
              <li className="p-3 bg-gray-50 rounded-md">Presentación Grupal - 22/03/2025</li>
            </ul>
          </div>
        </main>
      </div>

      {/* Botón flotante para Diario de Emociones */}
      <div className="fixed bottom-4 right-4 z-50">
        <a
          href="/dashboard/estudiante/diario-emociones"
          className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-5 rounded-full shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-105"
        >
          <span className="mr-2">📓</span> Diario De Emociones
        </a>
      </div>
    </>
  )
}

