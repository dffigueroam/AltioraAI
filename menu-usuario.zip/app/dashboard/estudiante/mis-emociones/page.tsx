export default function MisEmocionesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Mis Emociones</h1>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4 text-teal-700">Bienvenido a tu Centro de Emociones</h2>
        <p className="text-gray-600 mb-6">
          Aquí podrás visualizar, analizar y comprender tus patrones emocionales para mejorar tu bienestar. Utiliza las
          opciones del menú para explorar las diferentes funcionalidades.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg mb-2">Estado Actual</h3>
            <p className="text-gray-600 mb-3">Visualiza tu estado emocional actual y tendencias recientes.</p>
            <a
              href="/dashboard/estudiante/mis-emociones/estado-actual"
              className="text-teal-600 hover:text-teal-800 font-medium"
            >
              Ver mi estado →
            </a>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg mb-2">Histórico</h3>
            <p className="text-gray-600 mb-3">Explora el historial completo de tus emociones a lo largo del tiempo.</p>
            <a
              href="/dashboard/estudiante/mis-emociones/historico"
              className="text-teal-600 hover:text-teal-800 font-medium"
            >
              Ver mi histórico →
            </a>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg mb-2">Análisis</h3>
            <p className="text-gray-600 mb-3">Descubre patrones y correlaciones en tus estados emocionales.</p>
            <a
              href="/dashboard/estudiante/mis-emociones/analisis"
              className="text-teal-600 hover:text-teal-800 font-medium"
            >
              Ver mi análisis →
            </a>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <h3 className="font-medium text-lg mb-2">Recomendaciones</h3>
            <p className="text-gray-600 mb-3">Recibe sugerencias personalizadas basadas en tus patrones emocionales.</p>
            <a
              href="/dashboard/estudiante/mis-emociones/recomendaciones"
              className="text-teal-600 hover:text-teal-800 font-medium"
            >
              Ver recomendaciones →
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

