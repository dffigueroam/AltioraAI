export default function EstadoActualPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <a href="/dashboard/estudiante/mis-emociones" className="text-teal-600 hover:text-teal-800 mr-2">
          ← Volver a Mis Emociones
        </a>
        <h1 className="text-2xl font-bold">Estado Emocional Actual</h1>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-teal-700">¿Cómo te sientes hoy?</h2>
          <span className="text-sm text-gray-500">Actualizado: Hoy, 10:30 AM</span>
        </div>

        <div className="flex items-center justify-center p-6 bg-teal-50 rounded-lg mb-6">
          <div className="text-center">
            <div className="text-6xl mb-2">😊</div>
            <div className="text-2xl font-bold text-teal-700">Contento</div>
            <div className="text-gray-600">Nivel de energía: Alto</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-lg mb-3 text-teal-700">Tendencia Semanal</h3>
            <div className="h-40 bg-gray-100 rounded-lg flex items-center justify-center">
              <p className="text-gray-500">Gráfico de tendencia semanal</p>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-3 text-teal-700">Factores Influyentes</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                <span>Descanso adecuado</span>
              </li>
              <li className="flex items-center">
                <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                <span>Buena alimentación</span>
              </li>
              <li className="flex items-center">
                <span className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
                <span>Nivel de estrés moderado</span>
              </li>
              <li className="flex items-center">
                <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                <span>Actividad física regular</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-4 text-teal-700">Recomendaciones Personalizadas</h2>
        <ul className="space-y-3">
          <li className="p-3 bg-teal-50 rounded-md">
            Mantén tu rutina de ejercicio para seguir mejorando tu bienestar
          </li>
          <li className="p-3 bg-teal-50 rounded-md">
            Considera técnicas de respiración para manejar el estrés moderado
          </li>
          <li className="p-3 bg-teal-50 rounded-md">Continúa con tus buenos hábitos de sueño y alimentación</li>
        </ul>
      </div>
    </div>
  )
}

