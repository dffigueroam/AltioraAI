export default function AnalisisEmocionesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Análisis de Emociones</h1>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-semibold mb-6 text-teal-700">Patrones Emocionales</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-50 rounded-lg p-5">
            <h3 className="font-medium text-lg mb-3">Distribución de emociones</h3>
            <div className="h-48 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
              <p className="text-gray-500">Gráfico de distribución de emociones</p>
            </div>
            <div className="flex justify-between text-sm text-gray-600">
              <div className="flex items-center">
                <span className="w-3 h-3 bg-blue-400 rounded-full mr-1"></span>
                <span>Felicidad: 42%</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 bg-green-400 rounded-full mr-1"></span>
                <span>Calma: 23%</span>
              </div>
              <div className="flex items-center">
                <span className="w-3 h-3 bg-yellow-400 rounded-full mr-1"></span>
                <span>Otros: 35%</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-5">
            <h3 className="font-medium text-lg mb-3">Tendencias semanales</h3>
            <div className="h-48 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
              <p className="text-gray-500">Gráfico de tendencias semanales</p>
            </div>
            <p className="text-sm text-gray-600">
              Tus emociones tienden a ser más positivas los fines de semana y más variables durante la semana.
            </p>
          </div>
        </div>

        <h3 className="font-medium text-lg mb-4">Correlaciones detectadas</h3>
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
            <h4 className="font-medium mb-2">Actividad académica y estrés</h4>
            <p className="text-gray-700">
              Se ha detectado un aumento del estrés los días previos a exámenes o entregas importantes.
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Recomendación: Planificar con más anticipación para reducir el estrés.
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
            <h4 className="font-medium mb-2">Actividad física y bienestar</h4>
            <p className="text-gray-700">
              Los días que registras actividad física muestran un 40% más de emociones positivas.
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Recomendación: Mantener la rutina de ejercicio para mejorar el bienestar emocional.
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-500">
            <h4 className="font-medium mb-2">Calidad de sueño</h4>
            <p className="text-gray-700">
              Noches con menos de 7 horas de sueño correlacionan con mayor irritabilidad al día siguiente.
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Recomendación: Priorizar un horario de sueño regular de al menos 8 horas.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

