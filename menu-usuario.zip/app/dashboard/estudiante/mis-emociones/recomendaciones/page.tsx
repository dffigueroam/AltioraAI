export default function RecomendacionesEmocionalesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Recomendaciones Personalizadas</h1>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-teal-700">Sugerencias para tu bienestar</h2>
          <span className="text-3xl">🧠</span>
        </div>

        <p className="text-gray-600 mb-6">
          Basado en el análisis de tus patrones emocionales, hemos generado estas recomendaciones personalizadas para
          ayudarte a mejorar tu bienestar emocional y rendimiento académico.
        </p>

        <div className="space-y-6">
          <div className="bg-blue-50 rounded-lg p-5 border-l-4 border-blue-500">
            <h3 className="font-medium text-lg mb-2 flex items-center">
              <span className="text-2xl mr-2">⏰</span>
              Gestión del tiempo
            </h3>
            <p className="text-gray-700 mb-3">
              Hemos detectado que tu nivel de estrés aumenta significativamente antes de las entregas importantes.
            </p>
            <div className="bg-white rounded-md p-3">
              <h4 className="font-medium text-blue-700 mb-2">Recomendación:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Divide tus proyectos en tareas más pequeñas y manejables</li>
                <li>Comienza a trabajar en las entregas al menos una semana antes</li>
                <li>Utiliza la técnica Pomodoro: 25 minutos de trabajo, 5 de descanso</li>
              </ul>
            </div>
          </div>

          <div className="bg-green-50 rounded-lg p-5 border-l-4 border-green-500">
            <h3 className="font-medium text-lg mb-2 flex items-center">
              <span className="text-2xl mr-2">🏃‍♂️</span>
              Actividad física
            </h3>
            <p className="text-gray-700 mb-3">
              Los datos muestran una clara correlación entre tu actividad física y estados emocionales positivos.
            </p>
            <div className="bg-white rounded-md p-3">
              <h4 className="font-medium text-green-700 mb-2">Recomendación:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Mantén tu rutina de ejercicio de 3 veces por semana</li>
                <li>Considera añadir una caminata corta los días de mayor estrés académico</li>
                <li>Prueba ejercicios de estiramiento o yoga antes de dormir</li>
              </ul>
            </div>
          </div>

          <div className="bg-purple-50 rounded-lg p-5 border-l-4 border-purple-500">
            <h3 className="font-medium text-lg mb-2 flex items-center">
              <span className="text-2xl mr-2">😌</span>
              Técnicas de relajación
            </h3>
            <p className="text-gray-700 mb-3">
              Tus registros muestran que las técnicas de relajación han sido efectivas cuando las has practicado.
            </p>
            <div className="bg-white rounded-md p-3">
              <h4 className="font-medium text-purple-700 mb-2">Recomendación:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Dedica 10 minutos diarios a la meditación o respiración profunda</li>
                <li>Prueba la técnica 4-7-8: inhala por 4 segundos, mantén por 7, exhala por 8</li>
                <li>Escucha música relajante durante tus sesiones de estudio</li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 rounded-lg p-5 border-l-4 border-yellow-500">
            <h3 className="font-medium text-lg mb-2 flex items-center">
              <span className="text-2xl mr-2">💤</span>
              Hábitos de sueño
            </h3>
            <p className="text-gray-700 mb-3">
              La calidad de tu sueño tiene un impacto significativo en tu estado emocional del día siguiente.
            </p>
            <div className="bg-white rounded-md p-3">
              <h4 className="font-medium text-yellow-700 mb-2">Recomendación:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Establece un horario regular para dormir y despertar</li>
                <li>Evita pantallas al menos 1 hora antes de acostarte</li>
                <li>Limita la cafeína después del mediodía</li>
                <li>Crea una rutina relajante antes de dormir</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

