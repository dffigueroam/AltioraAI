import type { ReactNode } from "react"

export default function EstudianteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen pb-16 relative">
      {children}

      {/* Barra de navegación inferior directamente en el layout */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md z-50">
        <div className="container mx-auto">
          <div className="flex overflow-x-auto">
            <a
              href="/dashboard/estudiante"
              className="flex-1 py-3 px-2 text-sm text-center text-gray-600 hover:text-gray-900"
            >
              Inicio
            </a>
            <a
              href="/dashboard/estudiante/tareas"
              className="flex-1 py-3 px-2 text-sm text-center text-gray-600 hover:text-gray-900"
            >
              Tareas
            </a>
            <a
              href="/dashboard/estudiante/eventos"
              className="flex-1 py-3 px-2 text-sm text-center text-gray-600 hover:text-gray-900"
            >
              Eventos
            </a>
            <a
              href="/dashboard/estudiante/diario-emociones"
              className="flex-1 py-3 px-2 text-sm text-center text-blue-600 font-medium"
            >
              Diario De Emociones
            </a>
            <a
              href="/dashboard/estudiante/recursos"
              className="flex-1 py-3 px-2 text-sm text-center text-gray-600 hover:text-gray-900"
            >
              Recursos
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

