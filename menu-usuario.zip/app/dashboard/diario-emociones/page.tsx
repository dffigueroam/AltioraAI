"use client"

import { DiarioEmociones } from "@/components/student/diario-emociones"

export default function DiarioEmocionesPage() {
  return (
    <div className="container py-6">
      <DiarioEmociones />
    </div>
  )
}

