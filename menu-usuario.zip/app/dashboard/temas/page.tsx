import { TemasClase } from "@/components/temas-clase"

export default function TemasPage() {
  return <TemasClase />
}

