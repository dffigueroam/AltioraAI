import type React from "react"
import { ProfesorSidebar } from "@/components/profesor-sidebar"

export default function ProfesorLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <ProfesorSidebar />
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  )
}

