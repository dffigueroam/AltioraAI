import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Calendar, ClipboardList, FileText, Heart, MessageSquare, Users } from "lucide-react"

export default function ProfesorDashboard() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Bienvenido, Profesor</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Clases Hoy</CardTitle>
            <CardDescription>Tienes 3 clases programadas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>Matemáticas - 3A</span>
                <span className="text-sm text-muted-foreground">8:00 - 9:30</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Ciencias - 2B</span>
                <span className="text-sm text-muted-foreground">10:00 - 11:30</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Matemáticas - 4C</span>
                <span className="text-sm text-muted-foreground">13:00 - 14:30</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/profesor/calendario">
                <Calendar className="mr-2 h-4 w-4" />
                Ver Calendario
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Acciones Pendientes</CardTitle>
            <CardDescription>3 acciones requieren tu atención</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>Revisar evaluación - Matemáticas</span>
                <span className="text-xs px-2 py-1 rounded-full bg-red-100 text-red-800">Urgente</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Reunión con padres - Carlos Pérez</span>
                <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-800">Pendiente</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Planificación - Semana 12</span>
                <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">En progreso</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/profesor/acciones-pendientes">
                <ClipboardList className="mr-2 h-4 w-4" />
                Ver Todas
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Estado Emocional</CardTitle>
            <CardDescription>2 estudiantes requieren atención</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>Ana García - 3A</span>
                <span className="text-xs px-2 py-1 rounded-full bg-red-100 text-red-800">Urgente</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Carlos Rodríguez - 3A</span>
                <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-800">Atención</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/dashboard/profesor/estado-emocional">
                <Heart className="mr-2 h-4 w-4" />
                Ver Estados
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="proximas-clases">
        <TabsList className="mb-4">
          <TabsTrigger value="proximas-clases">Próximas Clases</TabsTrigger>
          <TabsTrigger value="evaluaciones">Evaluaciones</TabsTrigger>
          <TabsTrigger value="mensajes">Mensajes</TabsTrigger>
        </TabsList>

        <TabsContent value="proximas-clases">
          <Card>
            <CardHeader>
              <CardTitle>Próximas Clases</CardTitle>
              <CardDescription>Clases programadas para esta semana</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Contenido de próximas clases */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Matemáticas - 3A</h3>
                        <p className="text-sm text-muted-foreground">Martes, 8:00 - 9:30</p>
                        <p className="text-sm mt-2">Tema: Ecuaciones de segundo grado</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Detalles
                      </Button>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Ciencias - 2B</h3>
                        <p className="text-sm text-muted-foreground">Martes, 10:00 - 11:30</p>
                        <p className="text-sm mt-2">Tema: Sistema solar</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Detalles
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/dashboard/profesor/clases">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Ver Todas las Clases
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="evaluaciones">
          <Card>
            <CardHeader>
              <CardTitle>Evaluaciones Pendientes</CardTitle>
              <CardDescription>Evaluaciones por revisar y calificar</CardDescription>
            </CardHeader>
            <CardContent>{/* Contenido de evaluaciones */}</CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/dashboard/profesor/evaluaciones">
                  <FileText className="mr-2 h-4 w-4" />
                  Ver Todas las Evaluaciones
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="mensajes">
          <Card>
            <CardHeader>
              <CardTitle>Mensajes Recientes</CardTitle>
              <CardDescription>Comunicaciones de padres y colegas</CardDescription>
            </CardHeader>
            <CardContent>{/* Contenido de mensajes */}</CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/dashboard/profesor/mensajes">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Ver Todos los Mensajes
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-4">Acciones Rápidas</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button variant="outline" className="h-24 flex flex-col items-center justify-center" asChild>
            <Link href="/dashboard/profesor/estudiantes">
              <Users className="h-6 w-6 mb-2" />
              <span>Estudiantes</span>
            </Link>
          </Button>

          <Button variant="outline" className="h-24 flex flex-col items-center justify-center" asChild>
            <Link href="/dashboard/profesor/evaluaciones/nueva">
              <FileText className="h-6 w-6 mb-2" />
              <span>Nueva Evaluación</span>
            </Link>
          </Button>

          <Button variant="outline" className="h-24 flex flex-col items-center justify-center" asChild>
            <Link href="/dashboard/profesor/estado-emocional">
              <Heart className="h-6 w-6 mb-2" />
              <span>Estado Emocional</span>
            </Link>
          </Button>

          <Button variant="outline" className="h-24 flex flex-col items-center justify-center" asChild>
            <Link href="/dashboard/profesor/mensajes/nuevo">
              <MessageSquare className="h-6 w-6 mb-2" />
              <span>Nuevo Mensaje</span>
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

