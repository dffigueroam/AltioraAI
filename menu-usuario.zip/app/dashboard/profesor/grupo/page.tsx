import { TableroGrupo } from "@/components/tablero-grupo"

export default function GrupoPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Tablero de Grupo</h1>
      <TableroGrupo />
    </div>
  )
}

