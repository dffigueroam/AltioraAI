import { GestionCasosProfesor } from "@/components/gestion-casos-profesor"

export default function GestionCasosPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Gestión de Casos de Estudiantes</h1>
      <GestionCasosProfesor />
    </div>
  )
}

