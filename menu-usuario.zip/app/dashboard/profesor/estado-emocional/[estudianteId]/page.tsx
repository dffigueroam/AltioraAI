import { EstadoEmocionalEstudiante } from "@/components/estado-emocional-estudiante"

export default function EstadoEmocionalEstudiantePage({ params }: { params: { estudianteId: string } }) {
  return (
    <div className="container mx-auto py-6">
      <EstadoEmocionalEstudiante estudianteId={params.estudianteId} userName="María González" />
    </div>
  )
}

