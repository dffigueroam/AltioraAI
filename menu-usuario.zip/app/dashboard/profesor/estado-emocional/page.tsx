import { EstadoEmocionalProfesor } from "@/components/estado-emocional-profesor"

export default function EstadoEmocionalPage() {
  return (
    <div className="container mx-auto py-6">
      <EstadoEmocionalProfesor groupId="3A" userName="María González" />
    </div>
  )
}

