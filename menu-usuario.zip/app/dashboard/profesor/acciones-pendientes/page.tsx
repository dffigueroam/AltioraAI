import { AccionesPendientesGestion } from "@/components/acciones-pendientes-gestion"

export default function AccionesPendientesPage() {
  return (
    <div className="container mx-auto py-6">
      <AccionesPendientesGestion />
    </div>
  )
}

