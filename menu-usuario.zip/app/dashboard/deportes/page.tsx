export default function DeportesPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Deportes</h1>
      <p>Contenido de Deportes</p>
    </div>
  )
}

