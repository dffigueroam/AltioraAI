import { PerfilPsicologo } from "@/components/perfil-psicologo"

// Datos de ejemplo para un psicólogo
const psychologistData = {
  id: "psy123",
  name: "Dra. Ana Martínez",
  specialty: "educational" as const,
  assignedGrades: ["1° Primaria", "2° Primaria", "3° Primaria", "4° Primaria"],
  certifications: [
    "Maestría en Psicología Educativa",
    "Especialización en Trastornos del Aprendizaje",
    "Certificación en Terapia Cognitivo-Conductual",
    "Diplomado en Atención a la Diversidad en el Aula",
  ],
  availability: {
    days: ["Lunes", "Martes", "Jueves", "Viernes"],
    hours: "8:00 AM - 3:00 PM",
  },
  contactInfo: {
    email: "ana.martinez@colegio.edu",
    phone: "(+57) 300 123 4567",
    office: "Edificio B, Oficina 205",
  },
}

export default function PerfilPsicologoPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Mi Perfil</h1>
      <PerfilPsicologo psychologist={psychologistData} editable={true} />
    </div>
  )
}

