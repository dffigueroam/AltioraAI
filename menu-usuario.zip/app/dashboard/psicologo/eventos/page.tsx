import { EventosPsicologicos } from "@/components/events/eventos-psicologicos"

export default function EventosPsicologoPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Eventos Psicológicos</h2>
        <p className="text-muted-foreground">
          Gestiona tus sesiones, talleres, evaluaciones y reuniones desde un solo lugar.
        </p>
      </div>
      <EventosPsicologicos />
    </div>
  )
}

