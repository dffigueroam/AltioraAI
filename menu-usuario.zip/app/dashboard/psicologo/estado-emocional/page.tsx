import { EstadoEmocionalGestion } from "@/components/estado-emocional-gestion"

export default function EstadoEmocionalPsicologoPage() {
  return (
    <div className="container mx-auto py-6">
      <EstadoEmocionalGestion groupId="3A" userRole="psychologist" userId="psych123" userName="Laura Sánchez" />
    </div>
  )
}

