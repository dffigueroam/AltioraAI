import { EventosPsicologicos } from "@/components/events/eventos-psicologicos"

export default function AgendaPsicologoPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Agenda Psicológica</h2>
        <p className="text-muted-foreground">Gestione sus sesiones terapéuticas, talleres y reuniones.</p>
      </div>

      <EventosPsicologicos />
    </div>
  )
}

