import type React from "react"
import { PsicologoSidebar } from "@/components/psicologo-sidebar"
import { Toaster } from "@/components/ui/toaster"

export default function PsicologoLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <PsicologoSidebar />
      <div className="flex-1 p-8">
        {children}
        <Toaster />
      </div>
    </div>
  )
}

