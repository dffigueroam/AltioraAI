import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, Search, Plus, Filter } from "lucide-react"
import Link from "next/link"

export default function CasosEmocionales() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Casos Emocionales</h2>
          <p className="text-muted-foreground">Gestiona los casos emocionales de los estudiantes</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/psicologo/casos-emocionales/nuevo">
            <Plus className="mr-2 h-4 w-4" />
            Nuevo Caso
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Resumen de Casos</CardTitle>
              <CardDescription>Estado actual de los casos emocionales</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-pink-50 text-pink-700">
                <Heart className="mr-1 h-3 w-3 fill-pink-500 text-pink-500" />
                12 Casos Activos
              </Badge>
              <Badge variant="outline" className="bg-red-50 text-red-700">
                3 Urgentes
              </Badge>
              <Badge variant="outline" className="bg-green-50 text-green-700">
                5 En Seguimiento
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Buscar por nombre, curso o problema..." className="pl-8" />
        </div>
        <Select defaultValue="all">
          <SelectTrigger className="w-[180px]">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Filtrar por estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            <SelectItem value="urgent">Urgentes</SelectItem>
            <SelectItem value="new">Nuevos</SelectItem>
            <SelectItem value="follow">En seguimiento</SelectItem>
            <SelectItem value="closed">Cerrados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Todos</TabsTrigger>
          <TabsTrigger value="urgent">Urgentes</TabsTrigger>
          <TabsTrigger value="new">Nuevos</TabsTrigger>
          <TabsTrigger value="follow">En seguimiento</TabsTrigger>
          <TabsTrigger value="closed">Cerrados</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          {[
            {
              id: 1,
              student: "Ana Martínez",
              grade: "3º ESO B",
              status: "Urgente",
              date: "Hoy, 09:15",
              derivedBy: "Prof. García",
              issue: "Ansiedad por exámenes",
              notes:
                "Presenta síntomas de ansiedad severa antes de los exámenes. Necesita estrategias de manejo de estrés.",
            },
            {
              id: 2,
              student: "Carlos Gómez",
              grade: "4º ESO A",
              status: "Programado",
              date: "Hoy, 10:30",
              derivedBy: "Prof. Rodríguez",
              issue: "Dificultades de concentración",
              notes: "Dificultad para mantener la atención en clase. Posible evaluación para TDAH.",
            },
            {
              id: 3,
              student: "Laura Sánchez",
              grade: "2º ESO C",
              status: "Pendiente",
              date: "Ayer, 14:20",
              derivedBy: "Prof. López",
              issue: "Conflictos con compañeros",
              notes: "Reporta acoso por parte de algunos compañeros. Situación a investigar con urgencia.",
            },
            {
              id: 4,
              student: "Miguel Fernández",
              grade: "1º ESO A",
              status: "Pendiente",
              date: "Ayer, 11:45",
              derivedBy: "Prof. Martín",
              issue: "Cambios de comportamiento",
              notes:
                "Cambios notables en su comportamiento durante las últimas semanas. Más retraído y menos participativo.",
            },
            {
              id: 5,
              student: "Elena Ruiz",
              grade: "2º ESO B",
              status: "En seguimiento",
              date: "15/03/2024",
              derivedBy: "Iniciativa propia",
              issue: "Problemas familiares",
              notes: "Segunda sesión programada para hoy. Avances en la comunicación con sus padres.",
            },
            {
              id: 6,
              student: "Javier Torres",
              grade: "1º ESO C",
              status: "En seguimiento",
              date: "10/03/2024",
              derivedBy: "Prof. Sánchez",
              issue: "Baja autoestima",
              notes: "Trabajando en ejercicios de autoafirmación. Muestra ligera mejoría.",
            },
          ].map((caso) => (
            <Card key={caso.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{caso.student}</h3>
                      <span className="text-sm text-muted-foreground">{caso.grade}</span>
                      <Badge
                        variant={
                          caso.status === "Urgente"
                            ? "destructive"
                            : caso.status === "Programado"
                              ? "outline"
                              : caso.status === "En seguimiento"
                                ? "secondary"
                                : "secondary"
                        }
                      >
                        {caso.status}
                      </Badge>
                    </div>
                    <p className="font-medium">{caso.issue}</p>
                    <p className="text-sm text-muted-foreground">{caso.notes}</p>
                    <div className="flex items-center gap-2 pt-2 text-xs text-muted-foreground">
                      <span>Derivado por: {caso.derivedBy}</span>
                      <span>•</span>
                      <span>Fecha: {caso.date}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/dashboard/psicologo/casos-emocionales/${caso.id}/notas`}>Añadir nota</Link>
                    </Button>
                    <Button size="sm" asChild>
                      <Link href={`/dashboard/psicologo/casos-emocionales/${caso.id}`}>Gestionar</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="urgent" className="space-y-4">
          {/* Contenido similar filtrado por urgentes */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">Ana Martínez</h3>
                    <span className="text-sm text-muted-foreground">3º ESO B</span>
                    <Badge variant="destructive">Urgente</Badge>
                  </div>
                  <p className="font-medium">Ansiedad por exámenes</p>
                  <p className="text-sm text-muted-foreground">
                    Presenta síntomas de ansiedad severa antes de los exámenes. Necesita estrategias de manejo de
                    estrés.
                  </p>
                  <div className="flex items-center gap-2 pt-2 text-xs text-muted-foreground">
                    <span>Derivado por: Prof. García</span>
                    <span>•</span>
                    <span>Fecha: Hoy, 09:15</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" asChild>
                    <Link href="/dashboard/psicologo/casos-emocionales/1/notas">Añadir nota</Link>
                  </Button>
                  <Button size="sm" asChild>
                    <Link href="/dashboard/psicologo/casos-emocionales/1">Gestionar</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          {/* Más casos urgentes... */}
        </TabsContent>
        {/* Contenido similar para otras pestañas */}
      </Tabs>
    </div>
  )
}

