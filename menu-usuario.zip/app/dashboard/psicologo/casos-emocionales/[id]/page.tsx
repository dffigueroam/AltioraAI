import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Calendar, FileText, MessageSquare, Phone } from "lucide-react"
import Link from "next/link"

export default function CasoDetalle({ params }: { params: { id: string } }) {
  // En una aplicación real, obtendríamos los datos del caso desde una API o base de datos
  const caso = {
    id: params.id,
    student: "Ana Martínez",
    grade: "3º ESO B",
    status: "Urgente",
    date: "22/03/2024, 09:15",
    derivedBy: "Prof. García",
    issue: "Ansiedad por exámenes",
    notes: "Presenta síntomas de ansiedad severa antes de los exámenes. Necesita estrategias de manejo de estrés.",
    history: [
      {
        date: "22/03/2024",
        action: "Caso creado",
        user: "Prof. García",
        notes: "Derivación por ansiedad severa ante exámenes. La estudiante ha tenido episodios de llanto y bloqueo.",
      },
      {
        date: "22/03/2024",
        action: "Asignado",
        user: "Sistema",
        notes: "Caso asignado automáticamente a Dra. María Pérez",
      },
    ],
    studentInfo: {
      age: 14,
      birthdate: "12/05/2009",
      address: "Calle Principal 123",
      phone: "600123456",
      email: "ana.martinez@estudiante.edu",
      parents: "Manuel Martínez y Laura Gómez",
      parentsPhone: "600789012",
      parentsEmail: "manuel.martinez@email.com",
      academicRecord:
        "Buen rendimiento general. Notas altas en Lengua y Ciencias Sociales. Dificultades en Matemáticas.",
    },
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/psicologo/casos-emocionales">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h2 className="text-3xl font-bold tracking-tight">Caso: {caso.student}</h2>
        <Badge
          variant={caso.status === "Urgente" ? "destructive" : caso.status === "Programado" ? "outline" : "secondary"}
        >
          {caso.status}
        </Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-7">
        <div className="space-y-6 md:col-span-5">
          <Card>
            <CardHeader>
              <CardTitle>Información del Caso</CardTitle>
              <CardDescription>Detalles del caso emocional</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Estudiante</h4>
                    <p className="font-medium">{caso.student}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Curso</h4>
                    <p className="font-medium">{caso.grade}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Fecha de creación</h4>
                    <p className="font-medium">{caso.date}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Derivado por</h4>
                    <p className="font-medium">{caso.derivedBy}</p>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Problema</h4>
                  <p className="font-medium">{caso.issue}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Notas</h4>
                  <p>{caso.notes}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="seguimiento" className="space-y-4">
            <TabsList>
              <TabsTrigger value="seguimiento">Seguimiento</TabsTrigger>
              <TabsTrigger value="historial">Historial</TabsTrigger>
              <TabsTrigger value="informes">Informes</TabsTrigger>
            </TabsList>
            <TabsContent value="seguimiento" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Añadir Nota de Seguimiento</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <Textarea
                      placeholder="Escribe aquí tus observaciones, avances o plan de acción..."
                      className="min-h-32"
                    />
                    <div className="flex justify-end gap-2">
                      <Button variant="outline">Guardar como borrador</Button>
                      <Button>Añadir nota</Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Notas de Seguimiento</CardTitle>
                  <CardDescription>Historial de seguimiento del caso</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-center text-sm text-muted-foreground">
                      No hay notas de seguimiento aún. Añade la primera nota.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="historial" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Historial del Caso</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {caso.history.map((entry, index) => (
                      <div key={index} className="border-l-2 border-muted pl-4">
                        <div className="text-sm font-medium">
                          {entry.date} - {entry.action}
                        </div>
                        <div className="text-sm text-muted-foreground">Por: {entry.user}</div>
                        <div className="mt-1">{entry.notes}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="informes" className="space-y-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Informes</CardTitle>
                    <CardDescription>Informes generados para este caso</CardDescription>
                  </div>
                  <Button asChild>
                    <Link href={`/dashboard/psicologo/informes/nuevo?caso=${params.id}`}>
                      <FileText className="mr-2 h-4 w-4" />
                      Crear Informe
                    </Link>
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-center text-sm text-muted-foreground">
                      No hay informes generados para este caso.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6 md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Información del Estudiante</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center space-y-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src="/placeholder.svg?height=80&width=80" />
                  <AvatarFallback>AM</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h3 className="font-semibold">{caso.student}</h3>
                  <p className="text-sm text-muted-foreground">{caso.grade}</p>
                </div>
                <div className="w-full space-y-2 pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Edad:</span>
                    <span className="text-sm">{caso.studentInfo.age} años</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Fecha de nacimiento:</span>
                    <span className="text-sm">{caso.studentInfo.birthdate}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">Padres:</span>
                    <span className="text-sm">{caso.studentInfo.parents}</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full" asChild>
                  <Link href={`/dashboard/psicologo/estudiantes/${params.id}`}>Ver perfil completo</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Acciones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button className="w-full justify-start" asChild>
                  <Link href={`/dashboard/psicologo/citas/agendar?estudiante=${params.id}`}>
                    <Calendar className="mr-2 h-4 w-4" />
                    Agendar cita
                  </Link>
                </Button>
                <Button className="w-full justify-start" variant="outline" asChild>
                  <Link
                    href={`/dashboard/psicologo/mensajes/nuevo?destinatario=profesor&id=${caso.derivedBy.split(" ")[1]}`}
                  >
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Contactar profesor
                  </Link>
                </Button>
                <Button className="w-full justify-start" variant="outline" asChild>
                  <a href={`tel:${caso.studentInfo.parentsPhone}`}>
                    <Phone className="mr-2 h-4 w-4" />
                    Llamar a padres
                  </a>
                </Button>
                <Button className="w-full justify-start" variant="outline" asChild>
                  <Link href={`/dashboard/psicologo/casos-emocionales/${params.id}/cambiar-estado`}>
                    Cambiar estado
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

