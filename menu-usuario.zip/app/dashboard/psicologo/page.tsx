import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BarChart3, Calendar, Heart, MessageSquare, Users, FileText, ClipboardList } from "lucide-react"
import Link from "next/link"

export default function PsicologoDashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Bienvenida, Dra. María</h2>
        <p className="text-muted-foreground">Aquí tienes un resumen de tu actividad y casos pendientes.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Casos Activos</CardTitle>
            <Heart className="h-4 w-4 text-pink-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">+2 nuevos casos esta semana</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Citas Hoy</CardTitle>
            <Calendar className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Próxima: 10:30 AM - Carlos Gómez</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estudiantes</CardTitle>
            <Users className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">248</div>
            <p className="text-xs text-muted-foreground">En seguimiento: 42 estudiantes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mensajes</CardTitle>
            <MessageSquare className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">3 sin leer de profesores</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Casos Emocionales Recientes</CardTitle>
            <CardDescription>Casos derivados que requieren tu atención</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  id: 1,
                  student: "Ana Martínez",
                  grade: "3º ESO B",
                  status: "Urgente",
                  date: "Hoy, 09:15",
                  derivedBy: "Prof. García",
                  issue: "Ansiedad por exámenes",
                },
                {
                  id: 2,
                  student: "Carlos Gómez",
                  grade: "4º ESO A",
                  status: "Programado",
                  date: "Hoy, 10:30",
                  derivedBy: "Prof. Rodríguez",
                  issue: "Dificultades de concentración",
                },
                {
                  id: 3,
                  student: "Laura Sánchez",
                  grade: "2º ESO C",
                  status: "Pendiente",
                  date: "Ayer, 14:20",
                  derivedBy: "Prof. López",
                  issue: "Conflictos con compañeros",
                },
                {
                  id: 4,
                  student: "Miguel Fernández",
                  grade: "1º ESO A",
                  status: "Pendiente",
                  date: "Ayer, 11:45",
                  derivedBy: "Prof. Martín",
                  issue: "Cambios de comportamiento",
                },
              ].map((caso) => (
                <div key={caso.id} className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{caso.student}</span>
                      <span className="text-sm text-muted-foreground">{caso.grade}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {caso.issue} • Derivado por {caso.derivedBy}
                    </div>
                    <div className="text-xs text-muted-foreground">{caso.date}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        caso.status === "Urgente"
                          ? "destructive"
                          : caso.status === "Programado"
                            ? "outline"
                            : "secondary"
                      }
                    >
                      {caso.status}
                    </Badge>
                    <Button size="sm" asChild>
                      <Link href={`/dashboard/psicologo/casos-emocionales/${caso.id}`}>Ver</Link>
                    </Button>
                  </div>
                </div>
              ))}
              <Button className="w-full" variant="outline" asChild>
                <Link href="/dashboard/psicologo/casos-emocionales">Ver todos los casos</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Citas de Hoy</CardTitle>
            <CardDescription>Agenda del día {new Date().toLocaleDateString()}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  id: 1,
                  time: "10:30 - 11:15",
                  student: "Carlos Gómez",
                  grade: "4º ESO A",
                  type: "Seguimiento",
                },
                {
                  id: 2,
                  time: "12:00 - 12:45",
                  student: "Elena Ruiz",
                  grade: "2º ESO B",
                  type: "Primera evaluación",
                },
                {
                  id: 3,
                  time: "13:30 - 14:15",
                  student: "Javier Torres",
                  grade: "1º ESO C",
                  type: "Seguimiento",
                },
              ].map((cita) => (
                <div key={cita.id} className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-1">
                    <div className="font-medium">{cita.time}</div>
                    <div className="text-sm">
                      {cita.student} • {cita.grade}
                    </div>
                    <div className="text-xs text-muted-foreground">{cita.type}</div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/dashboard/psicologo/citas/${cita.id}`}>Detalles</Link>
                    </Button>
                  </div>
                </div>
              ))}
              <Button className="w-full" variant="outline" asChild>
                <Link href="/dashboard/psicologo/citas">Ver agenda completa</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Estadísticas Mensuales</CardTitle>
              <CardDescription>Resumen de actividad de Marzo 2024</CardDescription>
            </div>
            <BarChart3 className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Casos nuevos</p>
                  <p className="text-2xl font-bold">24</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Casos cerrados</p>
                  <p className="text-2xl font-bold">18</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Sesiones</p>
                  <p className="text-2xl font-bold">42</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Informes</p>
                  <p className="text-2xl font-bold">15</p>
                </div>
              </div>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/dashboard/psicologo/estadisticas">Ver estadísticas completas</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
            <CardDescription>Accesos directos a funciones frecuentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              <Button className="h-auto flex-col gap-2 p-4" asChild>
                <Link href="/dashboard/psicologo/casos-emocionales/nuevo">
                  <Heart className="h-5 w-5" />
                  <span>Nuevo Caso</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/citas/agendar">
                  <Calendar className="h-5 w-5" />
                  <span>Agendar Cita</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/eventos">
                  <Calendar className="h-5 w-5" />
                  <span>Eventos</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/informes/nuevo">
                  <FileText className="h-5 w-5" />
                  <span>Crear Informe</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/mensajes/nuevo">
                  <MessageSquare className="h-5 w-5" />
                  <span>Nuevo Mensaje</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/estudiantes">
                  <Users className="h-5 w-5" />
                  <span>Buscar Estudiante</span>
                </Link>
              </Button>
              <Button className="h-auto flex-col gap-2 p-4" variant="outline" asChild>
                <Link href="/dashboard/psicologo/seguimiento">
                  <ClipboardList className="h-5 w-5" />
                  <span>Seguimiento</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

