"use client"

import { useAuth } from "@/hooks/useAuth"
import { DashboardEducativo } from "@/components/dashboard-educativo"
import { DashboardEstudiante } from "@/components/dashboard-estudiante"

export default function DashboardPage() {
  const { user } = useAuth()

  // Si el usuario es un estudiante, mostrar el dashboard de estudiante
  if (user?.role === "estudiante") {
    return <DashboardEstudiante />
  }

  // Para otros roles (profesor, directivo), mostrar el dashboard educativo
  return <DashboardEducativo />
}

