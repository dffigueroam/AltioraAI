"use client"

import { useRouter } from "next/navigation"
import { BookHeart } from "lucide-react"

export function FloatingDiaryButton() {
  const router = useRouter()

  return (
    <button
      onClick={() => router.push("/dashboard/student/diario-emociones")}
      className="fixed bottom-20 right-6 z-50 flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 px-6 py-3 text-white shadow-lg hover:from-pink-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
      aria-label="Abrir Diario de Emociones"
    >
      <BookHeart className="h-6 w-6" />
      <span className="text-lg font-bold">Diario de Emociones</span>
    </button>
  )
}

