"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BookOpen, Home, Smile, User } from "lucide-react"

export function BottomNav() {
  const pathname = usePathname()

  const navItems = [
    {
      href: "/dashboard/student",
      icon: Home,
      label: "Inicio",
    },
    {
      href: "/dashboard/student/diario-emociones",
      icon: Smile,
      label: "Emociones",
    },
    {
      href: "/dashboard/student/cursos",
      icon: BookOpen,
      label: "Cursos",
    },
    {
      href: "/dashboard/student/perfil",
      icon: User,
      label: "Perfil",
    },
  ]

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full border-t bg-background md:hidden">
      <div className="grid h-16 grid-cols-4">
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/")

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center gap-1",
                isActive ? "text-primary" : "text-muted-foreground",
              )}
            >
              <item.icon className={cn("h-5 w-5", isActive && "fill-primary")} />
              <span className="text-xs">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}

