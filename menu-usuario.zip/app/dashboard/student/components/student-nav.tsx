"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BookOpen, Calendar, CheckSquare, Home, Settings, Smile, User } from "lucide-react"

interface StudentNavProps extends React.HTMLAttributes<HTMLElement> {
  isCollapsed: boolean
}

export function StudentNav({ className, isCollapsed, ...props }: StudentNavProps) {
  const pathname = usePathname()

  const routes = [
    {
      href: "/dashboard/student",
      icon: Home,
      title: "Inicio",
    },
    {
      href: "/dashboard/student/perfil",
      icon: User,
      title: "Perfil",
    },
    {
      href: "/dashboard/student/cursos",
      icon: BookOpen,
      title: "Mis Cursos",
    },
    {
      href: "/dashboard/student/calendario",
      icon: Calendar,
      title: "Calendario",
    },
    {
      href: "/dashboard/student/acciones-pendientes",
      icon: CheckSquare,
      title: "Acciones Pendientes",
      subItems: [
        {
          href: "/dashboard/student/acciones-pendientes/tareas",
          title: "Tareas",
        },
        {
          href: "/dashboard/student/acciones-pendientes/examenes",
          title: "Exámenes",
        },
        {
          href: "/dashboard/student/acciones-pendientes/proyectos",
          title: "Proyectos",
        },
      ],
    },
    {
      href: "/dashboard/student/diario-emociones",
      icon: Smile,
      title: "Diario de Emociones",
      subItems: [
        {
          href: "/dashboard/student/diario-emociones/registro",
          title: "Registrar Emoción",
        },
        {
          href: "/dashboard/student/diario-emociones/historial",
          title: "Mi Historial",
        },
        {
          href: "/dashboard/student/diario-emociones/sugerencias",
          title: "Sugerencias",
        },
      ],
    },
    {
      href: "/dashboard/student/configuracion",
      icon: Settings,
      title: "Configuración",
    },
  ]

  return (
    <nav className={cn("flex flex-col gap-2", className)} {...props}>
      {routes.map((route) => {
        const isActive = pathname === route.href || pathname.startsWith(route.href + "/")

        return (
          <div key={route.href} className="flex flex-col">
            <Link
              href={route.href}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-accent hover:text-accent-foreground",
                isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                isCollapsed && "justify-center",
              )}
            >
              <route.icon className="h-5 w-5" />
              {!isCollapsed && <span>{route.title}</span>}
            </Link>

            {!isCollapsed && route.subItems && isActive && (
              <div className="ml-8 mt-1 flex flex-col gap-1">
                {route.subItems.map((subItem) => {
                  const isSubActive = pathname === subItem.href

                  return (
                    <Link
                      key={subItem.href}
                      href={subItem.href}
                      className={cn(
                        "rounded-md px-3 py-1.5 text-sm transition-all hover:bg-accent hover:text-accent-foreground",
                        isSubActive ? "bg-accent/50 font-medium text-accent-foreground" : "text-muted-foreground",
                      )}
                    >
                      {subItem.title}
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        )
      })}
    </nav>
  )
}

