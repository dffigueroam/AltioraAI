import type { ReactNode } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Smile } from "lucide-react"

interface AccionesPendientesLayoutProps {
  children: ReactNode
}

export default function AccionesPendientesLayout({ children }: AccionesPendientesLayoutProps) {
  return (
    <div className="relative">
      {/* Contenido principal */}
      {children}

      {/* Botón flotante de Diario de Emociones */}
      <div className="fixed bottom-20 right-4 z-50 md:bottom-8">
        <Link href="/dashboard/student/diario-emociones">
          <Button
            size="lg"
            className="flex items-center gap-2 rounded-full bg-purple-600 px-4 py-6 shadow-lg hover:bg-purple-700 dark:bg-purple-700 dark:hover:bg-purple-800"
          >
            <Smile className="h-5 w-5" />
            <span>Diario de Emociones</span>
          </Button>
        </Link>
      </div>
    </div>
  )
}

