import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Smile } from "lucide-react"

export const metadata: Metadata = {
  title: "Tareas Pendientes",
  description: "Gestiona tus tareas pendientes",
}

export default function TareasPendientesPage() {
  // Añadimos un console.log para verificar que la página se está renderizando
  console.log("Renderizando página de Tareas Pendientes")

  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Tareas Pendientes</h1>
        <p className="text-muted-foreground">Revisa y completa tus tareas pendientes</p>
      </div>

      {/* DIARIO DE EMOCIONES - EXTREMADAMENTE VISIBLE */}
      <div className="sticky top-4 z-10 mb-6 rounded-lg border-4 border-purple-500 bg-purple-100 p-4 dark:bg-purple-900/30">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-3">
            <Smile className="h-10 w-10 text-purple-600 dark:text-purple-400" />
            <div>
              <h3 className="font-bold text-purple-800 dark:text-purple-300">¿Cómo te sientes con tus tareas?</h3>
              <p className="text-sm text-purple-700 dark:text-purple-400">Registra tus emociones mientras trabajas</p>
            </div>
          </div>
          <Link href="/dashboard/student/diario-emociones">
            <Button className="w-full bg-purple-600 hover:bg-purple-700 dark:bg-purple-700 dark:hover:bg-purple-800 sm:w-auto">
              IR AL DIARIO DE EMOCIONES
            </Button>
          </Link>
        </div>
      </div>

      {/* Lista de tareas (simplificada para este ejemplo) */}
      <div className="space-y-4">
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Tarea de Matemáticas</h3>
          <p className="text-sm text-muted-foreground">Entregar antes del 15 de noviembre</p>
        </div>
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Ensayo de Literatura</h3>
          <p className="text-sm text-muted-foreground">Entregar antes del 20 de noviembre</p>
        </div>
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Proyecto de Ciencias</h3>
          <p className="text-sm text-muted-foreground">Entregar antes del 25 de noviembre</p>
        </div>
      </div>
    </div>
  )
}

