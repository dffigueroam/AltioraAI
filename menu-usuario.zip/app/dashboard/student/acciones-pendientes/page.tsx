import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Smile } from "lucide-react"

export const metadata: Metadata = {
  title: "Acciones Pendientes",
  description: "Gestiona tus tareas, exámenes y proyectos pendientes",
}

export default function AccionesPendientesPage() {
  // Añadimos un console.log para verificar que la página se está renderizando
  console.log("Renderizando página de Acciones Pendientes")

  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Acciones Pendientes</h1>
        <p className="text-muted-foreground">Gestiona tus tareas, exámenes y proyectos pendientes</p>
      </div>

      {/* DIARIO DE EMOCIONES - EXTREMADAMENTE VISIBLE */}
      <div className="my-8 rounded-lg border-4 border-purple-500 bg-purple-100 p-6 text-center dark:bg-purple-900/30">
        <Smile className="mx-auto mb-4 h-16 w-16 text-purple-600 dark:text-purple-400" />
        <h2 className="mb-2 text-2xl font-bold text-purple-800 dark:text-purple-300">Diario de Emociones</h2>
        <p className="mb-6 text-lg text-purple-700 dark:text-purple-300">
          Registra cómo te sientes hoy y mejora tu bienestar emocional
        </p>
        <Link href="/dashboard/student/diario-emociones">
          <Button
            size="lg"
            className="bg-purple-600 px-8 py-6 text-lg hover:bg-purple-700 dark:bg-purple-700 dark:hover:bg-purple-800"
          >
            ACCEDER AL DIARIO DE EMOCIONES
          </Button>
        </Link>
      </div>

      {/* Contenido original de Acciones Pendientes */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-xl font-semibold">Tareas Pendientes</h3>
          <p className="mb-4 text-muted-foreground">Revisa y completa tus tareas pendientes</p>
          <Link href="/dashboard/student/acciones-pendientes/tareas">
            <Button variant="outline" className="w-full">
              Ver Tareas
            </Button>
          </Link>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-xl font-semibold">Exámenes Próximos</h3>
          <p className="mb-4 text-muted-foreground">Prepárate para tus próximos exámenes</p>
          <Link href="/dashboard/student/acciones-pendientes/examenes">
            <Button variant="outline" className="w-full">
              Ver Exámenes
            </Button>
          </Link>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-xl font-semibold">Proyectos Activos</h3>
          <p className="mb-4 text-muted-foreground">Trabaja en tus proyectos pendientes</p>
          <Link href="/dashboard/student/acciones-pendientes/proyectos">
            <Button variant="outline" className="w-full">
              Ver Proyectos
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

