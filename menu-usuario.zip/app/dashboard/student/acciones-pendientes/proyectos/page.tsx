import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Smile } from "lucide-react"

export const metadata: Metadata = {
  title: "Proyectos Pendientes",
  description: "Gestiona tus proyectos pendientes",
}

export default function ProyectosPendientesPage() {
  // Añadimos un console.log para verificar que la página se está renderizando
  console.log("Renderizando página de Proyectos Pendientes")

  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Proyectos Pendientes</h1>
        <p className="text-muted-foreground">Trabaja en tus proyectos pendientes</p>
      </div>

      {/* DIARIO DE EMOCIONES - EXTREMADAMENTE VISIBLE */}
      <div className="sticky top-4 z-10 mb-6 rounded-lg border-4 border-purple-500 bg-purple-100 p-4 dark:bg-purple-900/30">
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <div className="flex items-center gap-3">
            <Smile className="h-10 w-10 text-purple-600 dark:text-purple-400" />
            <div>
              <h3 className="font-bold text-purple-800 dark:text-purple-300">¿Cómo te sientes con tus proyectos?</h3>
              <p className="text-sm text-purple-700 dark:text-purple-400">
                Registra tus emociones durante el desarrollo
              </p>
            </div>
          </div>
          <Link href="/dashboard/student/diario-emociones">
            <Button className="w-full bg-purple-600 hover:bg-purple-700 dark:bg-purple-700 dark:hover:bg-purple-800 sm:w-auto">
              IR AL DIARIO DE EMOCIONES
            </Button>
          </Link>
        </div>
      </div>

      {/* Lista de proyectos (simplificada para este ejemplo) */}
      <div className="space-y-4">
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Proyecto de Investigación</h3>
          <p className="text-sm text-muted-foreground">Entregar antes del 30 de noviembre</p>
        </div>
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Presentación Grupal</h3>
          <p className="text-sm text-muted-foreground">Presentar el 5 de diciembre</p>
        </div>
        <div className="rounded-lg border bg-card p-4 shadow-sm">
          <h3 className="font-semibold">Proyecto Final</h3>
          <p className="text-sm text-muted-foreground">Entregar antes del 15 de diciembre</p>
        </div>
      </div>
    </div>
  )
}

