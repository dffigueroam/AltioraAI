import type { Metadata } from "next"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RegistroEmociones } from "./components/registro-emociones"
import { HistorialEmociones } from "./components/historial-emociones"
import { SugerenciasEmociones } from "./components/sugerencias-emociones"

export const metadata: Metadata = {
  title: "Diario de Emociones",
  description: "Registra y gestiona tus emociones diarias",
}

export default function DiarioEmocionesPage() {
  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Diario de Emociones</h1>
        <p className="text-muted-foreground">Registra tus emociones diarias y aprende a gestionarlas mejor</p>
      </div>

      <Tabs defaultValue="registro" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="registro">Registrar Emoción</TabsTrigger>
          <TabsTrigger value="historial">Mi Historial</TabsTrigger>
          <TabsTrigger value="sugerencias">Sugerencias</TabsTrigger>
        </TabsList>
        <TabsContent value="registro" className="mt-4">
          <RegistroEmociones />
        </TabsContent>
        <TabsContent value="historial" className="mt-4">
          <HistorialEmociones />
        </TabsContent>
        <TabsContent value="sugerencias" className="mt-4">
          <SugerenciasEmociones />
        </TabsContent>
      </Tabs>
    </div>
  )
}

