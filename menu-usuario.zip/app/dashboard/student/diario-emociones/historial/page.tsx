import type { Metadata } from "next"
import { HistorialEmociones } from "../components/historial-emociones"

export const metadata: Metadata = {
  title: "Historial de Emociones",
  description: "Revisa tu historial de emociones registradas",
}

export default function HistorialEmocionesPage() {
  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Mi Historial de Emociones</h1>
        <p className="text-muted-foreground">Revisa cómo han evolucionado tus emociones a lo largo del tiempo</p>
      </div>

      <HistorialEmociones />
    </div>
  )
}

