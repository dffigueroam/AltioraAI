"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Datos de ejemplo para el historial
const historialEmociones = [
  {
    fecha: "2023-11-20",
    emocion: "Feliz",
    intensidad: 4,
    notas: "Hoy fue un gran día, aprobé mi examen de matemáticas.",
  },
  { fecha: "2023-11-19", emocion: "Ansioso", intensidad: 3, notas: "Nervioso por el examen de mañana." },
  { fecha: "2023-11-18", emocion: "Tranquilo", intensidad: 4, notas: "Día tranquilo estudiando en casa." },
  { fecha: "2023-11-17", emocion: "Frustrado", intensidad: 5, notas: "No entiendo algunos temas para el examen." },
  { fecha: "2023-11-16", emocion: "Feliz", intensidad: 4, notas: "Salí con mis amigos después de clases." },
  { fecha: "2023-11-15", emocion: "Confundido", intensidad: 3, notas: "La clase de hoy fue complicada." },
  { fecha: "2023-11-14", emocion: "Emocionado", intensidad: 5, notas: "Anunciaron una excursión para el próximo mes." },
]

// Función para obtener el emoji según la emoción
function getEmojiForEmotion(emocion: string) {
  const emojis: Record<string, string> = {
    Feliz: "😊",
    Triste: "😢",
    Enojado: "😠",
    Ansioso: "😰",
    Tranquilo: "😌",
    Emocionado: "😃",
    Frustrado: "😤",
    Confundido: "😕",
  }
  return emojis[emocion] || "😐"
}

// Función para formatear la fecha
function formatDate(dateString: string) {
  const options: Intl.DateTimeFormatOptions = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
  return new Date(dateString).toLocaleDateString("es-ES", options)
}

export function HistorialEmociones() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Historial de Emociones</CardTitle>
        <CardDescription>Revisa cómo te has sentido en los últimos días</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="lista" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="lista">Vista de Lista</TabsTrigger>
            <TabsTrigger value="calendario">Vista de Calendario</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-4 space-y-4">
            {historialEmociones.map((registro, index) => (
              <div
                key={index}
                className="flex items-start space-x-4 rounded-lg border p-4 transition-all hover:bg-accent/50"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-2xl">
                  {getEmojiForEmotion(registro.emocion)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{registro.emocion}</h4>
                    <span className="text-sm text-muted-foreground">{formatDate(registro.fecha)}</span>
                  </div>
                  <div className="mt-1 flex items-center">
                    <span className="text-sm text-muted-foreground">Intensidad: {registro.intensidad}/5</span>
                  </div>
                  {registro.notas && <p className="mt-2 text-sm">{registro.notas}</p>}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="calendario" className="mt-4">
            <div className="rounded-md border p-4">
              <p className="text-center text-muted-foreground">Vista de calendario en desarrollo...</p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

