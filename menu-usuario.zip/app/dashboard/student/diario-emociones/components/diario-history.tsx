"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Datos de ejemplo para el historial
const SAMPLE_HISTORY = [
  {
    id: "1",
    date: "2023-11-15",
    emotion: "happy",
    emotionLabel: "Feliz",
    emoji: "😊",
    intensity: 4,
    notes: "Hoy me fue muy bien en el examen de matemáticas. Estoy orgulloso de mi esfuerzo.",
  },
  {
    id: "2",
    date: "2023-11-14",
    emotion: "anxious",
    emotionLabel: "Ansioso",
    emoji: "😰",
    intensity: 3,
    notes: "Estaba nervioso por la presentación, pero al final salió bien.",
  },
  {
    id: "3",
    date: "2023-11-13",
    emotion: "frustrated",
    emotionLabel: "Frustrado",
    emoji: "😤",
    intensity: 4,
    notes: "No entendí bien el tema de ciencias. Necesito pedir ayuda.",
  },
  {
    id: "4",
    date: "2023-11-12",
    emotion: "proud",
    emotionLabel: "Orgulloso",
    emoji: "😎",
    intensity: 5,
    notes: "Ayudé a un compañero con su tarea y me sentí muy bien.",
  },
  {
    id: "5",
    date: "2023-11-11",
    emotion: "calm",
    emotionLabel: "Tranquilo",
    emoji: "😌",
    intensity: 2,
    notes: "Día normal, sin muchas novedades.",
  },
]

export function DiarioHistory() {
  const [entries, setEntries] = useState(SAMPLE_HISTORY)
  const [view, setView] = useState("list")

  // Simulamos la carga de datos
  useEffect(() => {
    // En una implementación real, aquí cargaríamos los datos de la API
  }, [])

  function formatDate(dateStr: string) {
    const date = new Date(dateStr)
    return new Intl.DateTimeFormat("es-ES", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="list" onValueChange={setView}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="list">Lista</TabsTrigger>
          <TabsTrigger value="calendar">Calendario</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          {entries.length > 0 ? (
            entries.map((entry) => (
              <Card key={entry.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{formatDate(entry.date)}</div>
                    <div className="text-2xl">{entry.emoji}</div>
                  </div>
                  <div className="mt-2">
                    <span className="font-medium">{entry.emotionLabel}</span>
                    <span className="ml-2 text-sm text-muted-foreground">(Intensidad: {entry.intensity}/5)</span>
                  </div>
                  {entry.notes && <p className="mt-2 text-sm text-muted-foreground">{entry.notes}</p>}
                </CardContent>
              </Card>
            ))
          ) : (
            <p className="text-center text-muted-foreground">No hay entradas en tu diario todavía.</p>
          )}
        </TabsContent>

        <TabsContent value="calendar">
          <div className="rounded-md border p-4">
            <p className="text-center">Vista de calendario próximamente...</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

