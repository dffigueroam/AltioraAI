import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Coffee, HeartHandshake, Music, Smile, Sparkles } from "lucide-react"

// Datos de ejemplo para las sugerencias
const sugerencias = [
  {
    id: 1,
    titulo: "Técnicas de respiración",
    descripcion: "Practica respiración profunda durante 5 minutos cuando te sientas ansioso.",
    icono: Smile,
    categoria: "Bienestar",
  },
  {
    id: 2,
    titulo: "Descansos regulares",
    descripcion: "Toma un descanso de 10 minutos cada hora de estudio para mantener la concentración.",
    icono: Coffee,
    categoria: "Productividad",
  },
  {
    id: 3,
    titulo: "Música relajante",
    descripcion: "Escucha música instrumental mientras estudias para reducir el estrés.",
    icono: Music,
    categoria: "Relajación",
  },
  {
    id: 4,
    titulo: "Lectura antes de dormir",
    descripcion: "Lee algo positivo durante 15 minutos antes de dormir para mejorar tu estado de ánimo.",
    icono: BookOpen,
    categoria: "Hábitos",
  },
  {
    id: 5,
    titulo: "Habla con un amigo",
    descripcion: "Comparte tus preocupaciones con alguien de confianza cuando te sientas abrumado.",
    icono: HeartHandshake,
    categoria: "Social",
  },
]

export function SugerenciasEmociones() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Sugerencias Personalizadas</CardTitle>
          <CardDescription>Basadas en tu historial emocional reciente</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sugerencias.map((sugerencia) => (
              <div
                key={sugerencia.id}
                className="flex items-start space-x-4 rounded-lg border p-4 transition-all hover:bg-accent/50"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <sugerencia.icono className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{sugerencia.titulo}</h4>
                    <span className="rounded-full bg-secondary px-2 py-1 text-xs font-medium">
                      {sugerencia.categoria}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{sugerencia.descripcion}</p>
                  <div className="mt-3 flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      Guardar
                    </Button>
                    <Button variant="ghost" size="sm">
                      Ya lo intenté
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg">Tendencias Emocionales</CardTitle>
          <Sparkles className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            En las últimas dos semanas, has experimentado principalmente emociones positivas. Tus niveles de ansiedad
            han disminuido un 20% comparado con el mes anterior.
          </p>
          <div className="mt-4 h-32 rounded-md border bg-accent/20 p-2">
            <div className="flex h-full items-center justify-center">
              <p className="text-sm text-muted-foreground">Gráfico de tendencias en desarrollo...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

