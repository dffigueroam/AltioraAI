"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { toast } from "@/components/ui/use-toast"

const emociones = [
  { nombre: "Feliz", emoji: "😊" },
  { nombre: "Triste", emoji: "😢" },
  { nombre: "Enojado", emoji: "😠" },
  { nombre: "Ansioso", emoji: "😰" },
  { nombre: "Tranquilo", emoji: "😌" },
  { nombre: "Emocionado", emoji: "😃" },
  { nombre: "Frustrado", emoji: "😤" },
  { nombre: "Confundido", emoji: "😕" },
]

export function RegistroEmociones() {
  const [emocionSeleccionada, setEmocionSeleccionada] = useState<string | null>(null)
  const [intensidad, setIntensidad] = useState([3])
  const [notas, setNotas] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!emocionSeleccionada) {
      toast({
        title: "Error",
        description: "Por favor selecciona una emoción",
        variant: "destructive",
      })
      return
    }

    // Aquí iría la lógica para guardar la emoción
    console.log({
      emocion: emocionSeleccionada,
      intensidad: intensidad[0],
      notas,
      fecha: new Date().toISOString(),
    })

    toast({
      title: "Emoción registrada",
      description: "Tu emoción ha sido registrada correctamente",
    })

    // Resetear el formulario
    setEmocionSeleccionada(null)
    setIntensidad([3])
    setNotas("")
  }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>¿Cómo te sientes hoy?</CardTitle>
          <CardDescription>Selecciona la emoción que mejor describe cómo te sientes en este momento</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-4 gap-4">
            {emociones.map((emocion) => (
              <Button
                key={emocion.nombre}
                type="button"
                variant={emocionSeleccionada === emocion.nombre ? "default" : "outline"}
                className="h-20 flex-col space-y-2"
                onClick={() => setEmocionSeleccionada(emocion.nombre)}
              >
                <span className="text-2xl">{emocion.emoji}</span>
                <span>{emocion.nombre}</span>
              </Button>
            ))}
          </div>

          <div className="space-y-2">
            <Label htmlFor="intensidad">Intensidad: {intensidad[0]}/5</Label>
            <Slider id="intensidad" min={1} max={5} step={1} value={intensidad} onValueChange={setIntensidad} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notas">¿Quieres compartir algo más sobre cómo te sientes?</Label>
            <Textarea
              id="notas"
              placeholder="Escribe aquí tus pensamientos..."
              value={notas}
              onChange={(e) => setNotas(e.target.value)}
              rows={4}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            Guardar Registro
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}

