"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

const EMOTIONS = [
  { id: "happy", label: "Feliz", emoji: "😊" },
  { id: "sad", label: "Triste", emoji: "😢" },
  { id: "angry", label: "Enojado", emoji: "😠" },
  { id: "anxious", label: "Ansioso", emoji: "😰" },
  { id: "calm", label: "Tranquilo", emoji: "😌" },
  { id: "excited", label: "Emocionado", emoji: "🤩" },
  { id: "frustrated", label: "Frustrado", emoji: "😤" },
  { id: "proud", label: "Orgulloso", emoji: "😎" },
]

export function DiarioForm() {
  const [selectedEmotion, setSelectedEmotion] = useState("")
  const [intensity, setIntensity] = useState(3)
  const [notes, setNotes] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulamos el envío a la API
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Entrada guardada",
      description: "Tu registro de emociones ha sido guardado correctamente.",
    })

    setIsSubmitting(false)
    setSelectedEmotion("")
    setIntensity(3)
    setNotes("")
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <Label htmlFor="emotion">¿Qué emoción predomina hoy?</Label>
        <div className="grid grid-cols-4 gap-2">
          {EMOTIONS.map((emotion) => (
            <Card
              key={emotion.id}
              className={`cursor-pointer p-3 text-center hover:bg-muted ${
                selectedEmotion === emotion.id ? "border-2 border-primary bg-primary/10" : ""
              }`}
              onClick={() => setSelectedEmotion(emotion.id)}
            >
              <div className="text-2xl">{emotion.emoji}</div>
              <div className="mt-1 text-sm">{emotion.label}</div>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="intensity">Intensidad ({intensity})</Label>
          <input
            id="intensity"
            type="range"
            min="1"
            max="5"
            value={intensity}
            onChange={(e) => setIntensity(Number.parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs">
            <span>Muy leve</span>
            <span>Moderada</span>
            <span>Muy intensa</span>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">¿Quieres compartir algo más?</Label>
        <Textarea
          id="notes"
          placeholder="Escribe aquí lo que quieras compartir sobre tus emociones hoy..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={4}
        />
      </div>

      <Button type="submit" className="w-full" disabled={!selectedEmotion || isSubmitting}>
        {isSubmitting ? "Guardando..." : "Guardar entrada"}
      </Button>
    </form>
  )
}

