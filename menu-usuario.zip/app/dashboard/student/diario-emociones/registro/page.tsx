import type { Metadata } from "next"
import { RegistroEmociones } from "../components/registro-emociones"

export const metadata: Metadata = {
  title: "Registrar Emoción",
  description: "Registra tu emoción del día",
}

export default function RegistrarEmocionPage() {
  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Registrar Emoción</h1>
        <p className="text-muted-foreground">¿Cómo te sientes hoy? Registra tu emoción y reflexiona sobre ella</p>
      </div>

      <RegistroEmociones />
    </div>
  )
}

