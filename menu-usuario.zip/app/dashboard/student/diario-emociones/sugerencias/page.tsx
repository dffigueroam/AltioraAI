import type { Metadata } from "next"
import { SugerenciasEmociones } from "../components/sugerencias-emociones"

export const metadata: Metadata = {
  title: "Sugerencias para Emociones",
  description: "Sugerencias personalizadas basadas en tus emociones",
}

export default function SugerenciasEmocionesPage() {
  return (
    <div className="flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Sugerencias Personalizadas</h1>
        <p className="text-muted-foreground">
          Recomendaciones basadas en tu historial emocional para mejorar tu bienestar
        </p>
      </div>

      <SugerenciasEmociones />
    </div>
  )
}

