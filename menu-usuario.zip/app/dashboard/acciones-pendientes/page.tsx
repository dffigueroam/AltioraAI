export default function AccionesPendientesPage() {
  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Acciones Pendientes</h1>
      <p>Contenido de Acciones Pendientes</p>
    </div>
  )
}

