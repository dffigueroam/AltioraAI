import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Users, Brain, BarChart, Upload, Search, GraduationCap, Scale, Heart, Star, Plus } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-white text-slate-900">
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-[#1E40AF] via-[#3B82F6] to-[#EC4899] text-white py-12">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">Transformando la Educación</h1>
            <p className="text-lg md:text-xl mb-6 text-white/90">
              Una plataforma integral para estudiantes, profesores, directivos y familias.
            </p>
            <p className="text-xl md:text-2xl font-semibold mb-6">Un aprendizaje en lo más alto</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#EC4899] text-white hover:bg-[#EC4899]/90 w-full sm:w-auto" asChild>
                <Link href="/registro">Registrarse Gratis</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-[#1E40AF] hover:bg-white/90 w-full sm:w-auto"
                asChild
              >
                <Link href="/demo">Ver Demostración</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Search Section */}
        <section className="py-8 bg-white border-b">
          <div className="container mx-auto px-4">
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full max-w-2xl mx-auto flex items-center justify-between bg-white border-[#3B82F6] hover:border-[#1E40AF] transition-colors"
                >
                  <div className="flex items-center">
                    <Search className="h-4 w-4 mr-2 text-gray-500" />
                    <span className="text-gray-500">Buscar recursos, cursos o información...</span>
                  </div>
                  <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-slate-100 px-1.5 font-mono text-[10px] font-medium opacity-100">
                    <span className="text-xs">⌘</span>K
                  </kbd>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[850px]">
                <DialogHeader>
                  <DialogTitle>Búsqueda</DialogTitle>
                  <DialogDescription>Busca contenido, recursos y respuestas a tus preguntas</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="flex items-center gap-2 border rounded-md px-3 py-2">
                    <Search className="h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Escribe para buscar..."
                      className="flex-1 border-0 focus:outline-none focus:ring-0 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-slate-500">Resultados Sugeridos</p>
                    <div className="space-y-2">
                      <Link
                        href="/dashboard"
                        className="flex items-center gap-2 p-2 hover:bg-slate-100 rounded-md transition-colors"
                      >
                        <GraduationCap className="h-4 w-4 text-[#1E40AF]" />
                        <div>
                          <p className="text-sm font-medium">Dashboard Educativo</p>
                          <p className="text-xs text-slate-500">Accede a tu panel personalizado</p>
                        </div>
                      </Link>
                      <Link
                        href="/dashboard/evaluaciones"
                        className="flex items-center gap-2 p-2 hover:bg-slate-100 rounded-md transition-colors"
                      >
                        <Brain className="h-4 w-4 text-[#1E40AF]" />
                        <div>
                          <p className="text-sm font-medium">Evaluaciones</p>
                          <p className="text-xs text-slate-500">Gestiona tus evaluaciones y cuestionarios</p>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-[#F1F5F9]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-[#1E40AF]">Características Principales</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: <BookOpen className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "Consulta temas de clases",
                  description: "Organiza y accede a todos los cursos desde un solo lugar.",
                  link: "/registro?feature=cursos",
                },
                {
                  icon: <Users className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "Colaboración Educativa",
                  description: "Facilita la comunicación entre estudiantes, profesores y padres.",
                  link: "/registro?feature=colaboracion",
                },
                {
                  icon: <Brain className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "IA Personalizada",
                  description: "Recomendaciones de aprendizaje basadas en IA.",
                  link: "/registro?feature=ia",
                },
                {
                  icon: <BarChart className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "Seguimiento de Progreso",
                  description: "Monitorea el rendimiento académico y emocional.",
                  link: "/registro?feature=seguimiento",
                },
                {
                  icon: <Upload className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "Carga de Documentos",
                  description: "Analiza documentos con IA para obtener insights valiosos.",
                  link: "/registro?feature=documentos",
                },
                {
                  icon: <Scale className="h-10 w-10 mb-4 text-[#1E40AF]" />,
                  title: "Toma de Decisiones Multipol",
                  description: "Sistema avanzado de apoyo a toma de  decisiones",
                  link: "/registro?feature=multipol",
                },
              ].map((feature, index) => (
                <Card
                  key={index}
                  className="text-center bg-white border-[#3B82F6] border hover:border-[#1E40AF] transition-colors duration-300"
                >
                  <CardHeader>
                    <div className="flex justify-center">{feature.icon}</div>
                    <CardTitle className="text-[#1E40AF]">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-slate-600 mb-4">{feature.description}</CardDescription>
                    <Button
                      variant="outline"
                      className="w-full border-[#1E40AF] text-[#1E40AF] hover:bg-[#1E40AF] hover:text-white"
                      asChild
                    >
                      <Link href={feature.link}>Comenzar Ahora</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Dosis de Bienestar */}
        <div className="mt-16 mb-20">
          <h3 className="text-2xl font-bold text-center mb-8 text-[#1E40AF]">Tu Dosis de Bienestar</h3>
          <Card className="max-w-4xl mx-auto bg-gradient-to-r from-[#EFF6FF] to-[#F0F7FF] border-[#3B82F6]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#1E40AF]">
                <Heart className="h-6 w-6 text-[#EC4899]" />
                Mensaje del Día
              </CardTitle>
              <CardDescription>Pequeñas dosis de inspiración para nutrir tu bienestar emocional</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-white/80 rounded-lg p-6 shadow-sm">
                  <blockquote className="text-lg text-slate-700 italic">
                    "El aprendizaje es un tesoro que seguirá a su dueño a todas partes"
                  </blockquote>
                  <p className="text-sm text-slate-500 mt-2">- Proverbio Chino</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-white/80">
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm flex items-center gap-2 text-[#1E40AF]">
                        <Brain className="h-4 w-4 text-[#EC4899]" />
                        Tip Mental
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-slate-600">
                        Toma descansos de 5 minutos cada 25 minutos de estudio para mantener tu mente fresca y enfocada.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white/80">
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm flex items-center gap-2 text-[#1E40AF]">
                        <Heart className="h-4 w-4 text-[#EC4899]" />
                        Tip Emocional
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-slate-600">
                        Celebra tus pequeños logros diarios. Cada paso adelante, por pequeño que sea, es un progreso.
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white/80">
                    <CardHeader className="p-4">
                      <CardTitle className="text-sm flex items-center gap-2 text-[#1E40AF]">
                        <Star className="h-4 w-4 text-[#EC4899]" />
                        Recordatorio
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-slate-600">
                        Eres capaz de más de lo que crees. Tu potencial es ilimitado cuando crees en ti mismo.
                      </p>
                    </CardContent>
                  </Card>
                </div>
                <div className="flex justify-center">
                  <Button
                    variant="outline"
                    className="text-[#1E40AF] border-[#3B82F6] hover:bg-[#1E40AF] hover:text-white"
                    asChild
                  >
                    <Link href="/registro">
                      <Plus className="mr-2 h-4 w-4" />
                      Recibe tu dosis diaria de bienestar
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-[#1E40AF]">Preguntas Frecuentes</h2>
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                <AccordionItem value="item-1">
                  <AccordionTrigger>¿Qué es Altiora AI y cómo funciona?</AccordionTrigger>
                  <AccordionContent>
                    Altiora AI es una plataforma educativa innovadora que utiliza inteligencia artificial para
                    personalizar y mejorar la experiencia de aprendizaje. La plataforma analiza el rendimiento
                    académico, el bienestar emocional y los patrones de aprendizaje para proporcionar recomendaciones
                    personalizadas a estudiantes, profesores y padres.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>¿Cómo se protege la privacidad de los estudiantes?</AccordionTrigger>
                  <AccordionContent>
                    La privacidad y seguridad de los datos son nuestra prioridad. Implementamos encriptación de datos,
                    cumplimos con regulaciones de protección de datos educativos, y solo recopilamos información
                    necesaria para mejorar la experiencia educativa. Los padres tienen control total sobre la
                    información de sus hijos.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>¿Qué tipos de evaluaciones incluye la plataforma?</AccordionTrigger>
                  <AccordionContent>
                    La plataforma incluye evaluaciones académicas tradicionales, así como evaluaciones de bienestar
                    emocional, estilos de aprendizaje y habilidades sociales. Estas evaluaciones ayudan a crear un
                    perfil completo del estudiante y permiten una educación más personalizada y efectiva.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>¿Cómo pueden los padres monitorear el progreso de sus hijos?</AccordionTrigger>
                  <AccordionContent>
                    Los padres tienen acceso a un dashboard personalizado donde pueden ver el progreso académico, el
                    bienestar emocional y las recomendaciones de la IA para sus hijos. También pueden comunicarse
                    directamente con los profesores y recibir notificaciones sobre eventos importantes y evaluaciones
                    pendientes.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>¿Qué soporte se ofrece a los profesores?</AccordionTrigger>
                  <AccordionContent>
                    Los profesores reciben herramientas para gestionar sus clases, monitorear el progreso de los
                    estudiantes y recibir recomendaciones de la IA sobre estrategias de enseñanza. También tienen acceso
                    a recursos educativos, capacitación continua y soporte técnico.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-6">
                  <AccordionTrigger>¿Cómo se implementa la IA en la plataforma?</AccordionTrigger>
                  <AccordionContent>
                    La IA analiza datos académicos, patrones de comportamiento y resultados de evaluaciones para
                    proporcionar recomendaciones personalizadas. Esto incluye sugerencias de estudio, alertas tempranas
                    sobre dificultades académicas o emocionales, y estrategias de enseñanza adaptadas para cada
                    estudiante.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-7">
                  <AccordionTrigger>¿Qué dispositivos son compatibles con la plataforma?</AccordionTrigger>
                  <AccordionContent>
                    La plataforma es accesible desde cualquier dispositivo con conexión a internet a través de un
                    navegador web moderno. Esto incluye computadoras, tablets y smartphones, permitiendo un acceso
                    flexible y conveniente para todos los usuarios.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-8">
                  <AccordionTrigger>¿Qué es el método MULTIPOL y cómo se utiliza en la plataforma?</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2">
                      <p>
                        MULTIPOL (Multicriterio y Política) es un método de análisis multicriterio diseñado para evaluar
                        y comparar diferentes acciones o soluciones en función de múltiples criterios y políticas. En el
                        contexto educativo, nuestra plataforma implementa este método para:
                      </p>
                      <ul className="list-disc list-inside space-y-1 ml-4">
                        <li>Evaluar y seleccionar estrategias pedagógicas óptimas</li>
                        <li>Tomar decisiones sobre intervenciones académicas y de bienestar estudiantil</li>
                        <li>Analizar políticas educativas y su impacto en diferentes escenarios</li>
                        <li>Priorizar recursos y acciones basándose en múltiples criterios</li>
                      </ul>
                      <p className="mt-2">
                        El método permite a directivos y profesores tomar decisiones más informadas y objetivas al
                        considerar simultáneamente múltiples factores como rendimiento académico, bienestar emocional,
                        recursos disponibles y objetivos institucionales.
                      </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-8">
                  <AccordionTrigger>¿Cómo se manejan las necesidades especiales de aprendizaje?</AccordionTrigger>
                  <AccordionContent>
                    La plataforma está diseñada para ser inclusiva y adaptable a diferentes necesidades de aprendizaje.
                    Incluye opciones de accesibilidad, contenido adaptativo y recomendaciones personalizadas que
                    consideran las necesidades específicas de cada estudiante.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-[#1E40AF]">Lo que dicen nuestros usuarios</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  name: "María González",
                  role: "Estudiante",
                  quote:
                    "AltiorAI ha transformado mi experiencia de aprendizaje. Las recomendaciones personalizadas son increíbles.",
                },
                {
                  name: "Carlos Rodríguez",
                  role: "Profesor",
                  quote:
                    "Esta plataforma ha simplificado enormemente la gestión de mis cursos y la comunicación con los padres.",
                },
                {
                  name: "Ana Martínez",
                  role: "Madre",
                  quote:
                    "Ahora puedo seguir fácilmente el progreso de mi hija y comunicarme directamente con sus profesores.",
                },
              ].map((testimonial, index) => (
                <Card key={index} className="bg-[#F8FAFC] border-[#3B82F6] border">
                  <CardHeader>
                    <CardTitle className="text-[#1E40AF]">{testimonial.name}</CardTitle>
                    <CardDescription className="text-[#EC4899]">{testimonial.role}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="italic text-slate-600">"{testimonial.quote}"</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-[#1E40AF] text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Únete a la Revolución Educativa</h2>
            <p className="text-xl mb-8">Regístrate hoy y comienza a transformar la experiencia educativa.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#EC4899] text-white hover:bg-[#EC4899]/90 w-full sm:w-auto" asChild>
                <Link href="/registro">Registrarse Gratis</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-[#1E40AF] hover:bg-white/90 w-full sm:w-auto"
                asChild
              >
                <Link href="/demo">Explorar la Plataforma</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#1E40AF] text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold mb-4">AltiorAI</h3>
              <p className="text-sm">Transformando la educación a través de la tecnología y la colaboración.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Enlaces Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-sm hover:text-[#EC4899] transition-colors">
                    Acerca de
                  </Link>
                </li>
                <li>
                  <Link href="/features" className="text-sm hover:text-[#EC4899] transition-colors">
                    Características
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="text-sm hover:text-[#EC4899] transition-colors">
                    Precios
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-sm hover:text-[#EC4899] transition-colors">
                    Contacto
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/terms" className="text-sm hover:text-[#EC4899] transition-colors">
                    Términos de Servicio
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm hover:text-[#EC4899] transition-colors">
                    Política de Privacidad
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Síguenos</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-white hover:text-[#EC4899] transition-colors">
                  <span className="sr-only">Facebook</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
                <a href="#" className="text-white hover:text-[#EC4899] transition-colors">
                  <span className="sr-only">Twitter</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-white hover:text-[#EC4899] transition-colors">
                  <span className="sr-only">GitHub</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>
          <div className="text-center mt-8 text-white/80">
            &copy; {new Date().getFullYear()} AltiorAI. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  )
}

