"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"

// Tipo para los elementos de navegación
type NavItem = {
  href: string
  label: string
  roles: string[]
}

export default function Navigation() {
  const pathname = usePathname()

  // Lista de elementos de navegación con control de roles
  const navItems: NavItem[] = [
    { href: "/dashboard/estudiante", label: "Dashboard Estudiante", roles: ["estudiante"] },
    { href: "/dashboard/profesor", label: "Dashboard Profesor", roles: ["profesor"] },
    { href: "/dashboard/admin", label: "Dashboard Admin", roles: ["admin"] },
    { href: "/dashboard/estudiante/diario-emociones", label: "Diario De Emociones", roles: ["estudiante"] },
    // Otros elementos de navegación
  ]

  // Simulamos un rol de usuario (en una aplicación real, esto vendría de un contexto de autenticación)
  const userRole = "estudiante" // Cambia esto según el rol que quieras probar

  // Filtramos los elementos de navegación según el rol del usuario
  const filteredNavItems = navItems.filter((item) => item.roles.includes(userRole))

  return (
    <nav className="bg-white border-b">
      <div className="container mx-auto px-4">
        <div className="flex space-x-8 h-16 items-center">
          {filteredNavItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                pathname === item.href || pathname.startsWith(`${item.href}/`)
                  ? "border-blue-500 text-gray-900"
                  : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
              }`}
            >
              {item.label === "Diario De Emociones" && <span className="mr-1">📓</span>}
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  )
}

