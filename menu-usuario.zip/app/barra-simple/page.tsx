import { BarraNavegacionSimple } from "@/components/barra-navegacion-simple"

export default function BarraSimplePage() {
  return (
    <div className="min-h-screen p-6">
      <h1 className="text-2xl font-bold mb-6">Barra de Navegación Simple</h1>
      <p className="mb-4">Esta página muestra una barra de navegación simple con "Diario De Emociones".</p>

      <div className="mb-20">
        <p>Contenido de la página...</p>
      </div>

      <BarraNavegacionSimple />
    </div>
  )
}

